from __future__ import annotations

import base64
import json
import re
from dataclasses import dataclass, field

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QFont, QPixmap
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QFrame, QPlainTextEdit, QTextEdit, QSizePolicy,
    QTextBrowser
)

from services.kernel_service import KernelService


# --------- helpers ---------

_ansi_re = re.compile(r"\x1b\[[0-9;]*m")


def strip_ansi(s: str) -> str:
    return _ansi_re.sub("", s or "")


def has_webengine() -> bool:
    try:
        from PySide6.QtWebEngineWidgets import QWebEngineView  # noqa
        return True
    except Exception:
        return False


# --------- model ---------

@dataclass
class NotebookCell:
    """Lekki model komórki notebooka.

    Uwaga: zapisujemy też outputs/execution_count, aby:
    - poprawnie wyświetlić istniejący notebook (.ipynb) "jak w VS Code"
    - móc zapisać notebook z zachowaniem wyników (opcjonalnie)
    """

    cell_type: str  # "code" | "markdown" | "raw"
    source: str
    execution_count: int | None = None
    outputs: list[dict] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)


@dataclass
class NotebookDoc:
    cells: list[NotebookCell] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)

    def widget_state(self) -> dict | None:
        """Zwraca zapisany widget-state, jeśli notebook go posiada.

        Klasycznie jest to w metadata.widgets['application/vnd.jupyter.widget-state+json'].
        """
        md = self.metadata or {}
        w = md.get("widgets") or {}
        if isinstance(w, dict):
            state = w.get("application/vnd.jupyter.widget-state+json")
            if isinstance(state, dict):
                return state
        return None


# --------- UI widgets ---------

class AutoGrowPlainText(QPlainTextEdit):
    """
    Krótki edytor rosnący wraz z zawartością.
    """
    def __init__(self, min_lines=2, max_lines=28):
        super().__init__()
        self._min_lines = min_lines
        self._max_lines = max_lines
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.textChanged.connect(self._recompute_height)
        QTimer.singleShot(0, self._recompute_height)

    def _recompute_height(self):
        line_h = self.fontMetrics().height()
        blocks = max(1, self.document().blockCount())
        blocks = min(self._max_lines, blocks)
        blocks = max(self._min_lines, blocks)
        h = blocks * line_h + 18
        self.setFixedHeight(h)


class OutputArea(QWidget):
    """
    Renderuje listę outputów jak w notebooku:
    - text/plain -> QPlainTextEdit-like (QTextBrowser)
    - text/html  -> WebEngine jeśli dostępny, inaczej QTextBrowser (bez JS)
    - image/png  -> QLabel pixmap
    - plotly json -> WebEngine (JS) jeśli dostępny, inaczej fallback tekst
    - ipywidgets -> render z zapisanego widget-state (jeśli jest w notebooku),
                   w przeciwnym wypadku placeholder.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._collapsed = False

        self.btn_collapse = QPushButton("Collapse")
        self.btn_collapse.setCursor(Qt.PointingHandCursor)
        self.btn_clear = QPushButton("Clear")
        self.btn_clear.setCursor(Qt.PointingHandCursor)

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.addWidget(QLabel("Output"))
        top.addStretch(1)
        top.addWidget(self.btn_clear)
        top.addWidget(self.btn_collapse)

        self.body = QWidget()
        self.v = QVBoxLayout(self.body)
        self.v.setContentsMargins(0, 0, 0, 0)
        self.v.setSpacing(8)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)
        root.addLayout(top)
        root.addWidget(self.body)

        self.btn_collapse.clicked.connect(self.toggle)
        self.btn_clear.clicked.connect(self.clear)

        self._update_visibility()

    def toggle(self):
        self._collapsed = not self._collapsed
        self.btn_collapse.setText("Expand" if self._collapsed else "Collapse")
        self._update_visibility()

    def _update_visibility(self):
        self.body.setVisible(not self._collapsed)

    def clear(self):
        while self.v.count():
            it = self.v.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)

    def append_stream_text(self, text: str):
        w = QTextBrowser()
        w.setOpenExternalLinks(False)
        w.setFont(QFont("Consolas", 10))
        w.setPlainText(text)
        w.setMinimumHeight(60)
        self.v.addWidget(w)

    def append_error(self, traceback_text: str):
        w = QTextBrowser()
        w.setFont(QFont("Consolas", 10))
        w.setPlainText(strip_ansi(traceback_text))
        w.setMinimumHeight(80)
        w.setStyleSheet("border: 1px solid #5a1e2a;")
        self.v.addWidget(w)

    def append_text_plain(self, text: str):
        w = QTextBrowser()
        w.setFont(QFont("Consolas", 10))
        w.setPlainText(text)
        w.setMinimumHeight(60)
        self.v.addWidget(w)

    def append_html(self, html: str):
        if has_webengine():
            from PySide6.QtWebEngineWidgets import QWebEngineView
            view = QWebEngineView()
            view.setHtml(html)
            view.setMinimumHeight(220)
            self.v.addWidget(view)
        else:
            # fallback bez JS
            w = QTextBrowser()
            w.setHtml(html)
            w.setMinimumHeight(160)
            self.v.addWidget(w)

    def append_png(self, b64_png: str):
        raw = base64.b64decode(b64_png)
        pix = QPixmap()
        pix.loadFromData(raw, "PNG")
        lbl = QLabel()
        lbl.setPixmap(pix)
        lbl.setScaledContents(True)
        lbl.setMinimumHeight(220)
        self.v.addWidget(lbl)

    def append_plotly(self, plotly_json_obj):
        # plotly wymaga JS -> sensownie tylko z WebEngine
        if not has_webengine():
            self.append_text_plain("Plotly: WebEngine not available. Cannot render interactive chart.")
            return

        try:
            import plotly.io as pio
            import plotly.graph_objects as go  # noqa
            fig = pio.from_json(json.dumps(plotly_json_obj))
            html = pio.to_html(fig, include_plotlyjs="cdn", full_html=False)
            self.append_html(html)
        except Exception as e:
            self.append_text_plain(f"Plotly render error: {e}")

    def append_widget_placeholder(self, payload):
        self.append_text_plain("ipywidgets output detected, but full widget frontend is not implemented yet.\n"
                               f"payload: {payload}")

    def append_widget_from_state(self, view_json: dict, widget_state: dict | None):
        """Renderuje ipywidgets bez live-kernela, o ile notebook ma zapisany widget state.

        W praktyce:
        - output ma mime: application/vnd.jupyter.widget-view+json (zwykle model_id)
        - notebook metadata może zawierać widgets/application/vnd.jupyter.widget-state+json

        Jeśli state istnieje -> generujemy HTML z @jupyter-widgets/html-manager.
        Jeśli nie -> placeholder.
        """
        if not has_webengine():
            self.append_text_plain("ipywidgets: WebEngine not available. Cannot render interactive widgets.")
            return

        if not widget_state or not isinstance(widget_state, dict):
            self.append_widget_placeholder(view_json)
            return

        model_id = None
        if isinstance(view_json, dict):
            model_id = view_json.get("model_id") or view_json.get("modelId")

        if not model_id:
            self.append_widget_placeholder(view_json)
            return

        # Minimalny embed wg idei "widget state + view spec".
        # CDN: requirejs + html-manager. Działa offline tylko jeśli CDN dostępne.
        html = f"""
<!doctype html>
<html>
<head>
  <meta charset='utf-8'/>
  <style>body{{margin:0;padding:0;background:transparent;}}</style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js"></script>
</head>
<body>
  <div id="widget"></div>
  <script>
    window._WIDGET_STATE = {json.dumps(widget_state)};
    window._WIDGET_VIEW = {json.dumps({'version_major': 2, 'version_minor': 0, 'model_id': model_id})};

    require.config({{
      paths: {{
        'jquery': 'https://code.jquery.com/jquery-3.6.0.min',
        '@jupyter-widgets/base': 'https://unpkg.com/@jupyter-widgets/base@5.0.0/dist/index',
        '@jupyter-widgets/controls': 'https://unpkg.com/@jupyter-widgets/controls@7.0.0/dist/index',
        '@jupyter-widgets/html-manager': 'https://unpkg.com/@jupyter-widgets/html-manager@1.0.0/dist/index'
      }}
    }});

    require(['@jupyter-widgets/html-manager'], function(htmlManager) {{
      const manager = new htmlManager.HTMLManager();
      manager.set_state(window._WIDGET_STATE).then(function() {{
        return manager.renderWidget(window._WIDGET_VIEW, document.getElementById('widget'));
      }}).catch(function(err) {{
        document.getElementById('widget').innerText = 'Widget render error: ' + err;
      }});
    }});
  </script>
</body>
</html>
"""
        self.append_html(html)

    def render_outputs(self, outputs: list[dict], widget_state: dict | None = None):
        """Renderuje outputs z notebooka (z pliku) - bez wykonywania."""
        self.clear()
        if not outputs:
            return

        for out in outputs:
            otype = out.get("output_type")
            if otype == "stream":
                txt = out.get("text", "")
                if isinstance(txt, list):
                    txt = "".join(txt)
                if txt:
                    self.append_stream_text(txt)
                continue

            if otype in ("execute_result", "display_data"):
                data = out.get("data") or {}
                if not isinstance(data, dict):
                    continue

                if "application/vnd.jupyter.widget-view+json" in data:
                    self.append_widget_from_state(data.get("application/vnd.jupyter.widget-view+json") or {}, widget_state)
                    continue

                if "application/vnd.plotly.v1+json" in data:
                    self.append_plotly(data.get("application/vnd.plotly.v1+json"))
                    continue

                if "text/html" in data:
                    self.append_html(data.get("text/html") or "")
                    continue

                if "image/png" in data:
                    self.append_png(data.get("image/png") or "")
                    continue

                if "text/plain" in data:
                    tp = data.get("text/plain")
                    if isinstance(tp, list):
                        tp = "".join(tp)
                    self.append_text_plain(str(tp or ""))
                    continue

                self.append_text_plain("Unsupported mime bundle:\n" + json.dumps(list(data.keys()), indent=2))
                continue

            if otype == "error":
                tb = out.get("traceback") or []
                if isinstance(tb, list):
                    tb = "\n".join(tb)
                self.append_error(tb)
                continue

            # fallback
            self.append_text_plain(json.dumps(out, indent=2))

    # ---------- public API ----------

    def set_current_path(self, path: str | None):
        self._current_path = path

    def current_path(self) -> str | None:
        return self._current_path

    def is_modified(self) -> bool:
        return bool(self._modified)

    def set_modified(self, modified: bool):
        modified = bool(modified)
        if self._modified == modified:
            return
        self._modified = modified
        self.modificationChanged.emit(self._modified)

    def _mark_modified(self):
        self.set_modified(True)


class NotebookCellWidget(QFrame):
    changed = Signal()

    def __init__(
        self,
        kernel_service: KernelService,
        index: int,
        cell: NotebookCell,
        widget_state: dict | None = None,
        parent=None,
    ):
        super().__init__(parent)
        self.kernel_service = kernel_service

        self._current_path: str | None = None
        self._modified: bool = False
        self.index = index
        self.cell = cell
        self._widget_state = widget_state
        self._running = False

        self.setObjectName("NotebookCellWidget")
        self.setStyleSheet("""
            QFrame#NotebookCellWidget {
                border: 1px solid #1b2a4a;
                border-radius: 14px;
                background: #070b14;
            }
        """)

        self.lbl = QLabel()
        self.lbl.setStyleSheet("color: #b7c7dd; padding: 2px;")

        self.exec_lbl = QLabel()
        self.exec_lbl.setStyleSheet("color: #89a7c9; padding: 2px;")

        self.btn_run = QPushButton("Run")
        self.btn_run.setCursor(Qt.PointingHandCursor)

        self.btn_type = QPushButton("Code" if cell.cell_type == "code" else "Markdown")
        self.btn_type.setCursor(Qt.PointingHandCursor)

        top = QHBoxLayout()
        top.setContentsMargins(12, 10, 12, 0)
        top.addWidget(self.lbl)
        top.addWidget(self.exec_lbl)
        top.addStretch(1)
        top.addWidget(self.btn_type)
        top.addWidget(self.btn_run)

        self.editor = AutoGrowPlainText(min_lines=2, max_lines=28)
        self.editor.setFont(QFont("Consolas", 11))
        self.editor.setPlainText(cell.source or "")

        self.md_preview = QTextEdit()
        self.md_preview.setReadOnly(True)
        self.md_preview.setVisible(cell.cell_type == "markdown")

        self.output = OutputArea()
        self.output.setVisible(cell.cell_type == "code")

        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 10)
        lay.setSpacing(8)
        lay.addLayout(top)
        lay.addWidget(self.editor)

        if cell.cell_type == "markdown":
            lay.addWidget(self.md_preview)

        lay.addWidget(self.output)

        self.btn_run.clicked.connect(self.run_cell)
        self.btn_type.clicked.connect(self.toggle_type)
        self.editor.textChanged.connect(self._on_text_change)

        self._refresh_header()
        try:
            self.changed.emit()
        except Exception:
            pass
        if cell.cell_type == "markdown":
            self._render_markdown()
        else:
            # pokaż istniejące outputs z pliku
            try:
                self.output.render_outputs(self.cell.outputs or [], widget_state=self._widget_state)
            except Exception:
                pass

    def _refresh_header(self):
        ctype = (self.cell.cell_type or "code").upper()
        self.lbl.setText(f"{ctype} [{self.index}]")
        if self.cell.cell_type == "code":
            self.exec_lbl.setText(f"In [{self.cell.execution_count if self.cell.execution_count is not None else ' '}] ")
        else:
            self.exec_lbl.setText("")
        self.btn_run.setEnabled(self.cell.cell_type == "code" and not self._running)

    def _on_text_change(self):
        # zaznacz zmiany w notebooku
        try:
            self.changed.emit()
        except Exception:
            pass

        if self.cell.cell_type == "markdown":
            self._render_markdown()

    def _render_markdown(self):
        txt = self.editor.toPlainText()
        self.md_preview.document().setMarkdown(txt)

    def toggle_type(self):
        if self._running:
            return

        if self.cell.cell_type == "code":
            self.cell = NotebookCell("markdown", self.editor.toPlainText())
            self.btn_type.setText("Markdown")
            self.output.setVisible(False)
            self.md_preview.setVisible(True)
            self._render_markdown()
        else:
            self.cell = NotebookCell("code", self.editor.toPlainText())
            self.btn_type.setText("Code")
            self.md_preview.setVisible(False)
            self.output.setVisible(True)

        self._refresh_header()

    def run_cell(self):
        if self.cell.cell_type != "code" or self._running:
            return

        code = self.editor.toPlainText().rstrip()
        if not code:
            return

        self._running = True
        self._refresh_header()
        try:
            self.changed.emit()
        except Exception:
            pass
        self.output.clear()
        self.output.append_text_plain("▶ running...")

        collected: list[dict] = []

        def on_item(item: dict):
            itype = item.get("type")
            if itype == "stream":
                txt = item.get("text", "")
                if txt.strip():
                    self.output.append_stream_text(txt)
                collected.append({"output_type": "stream", "name": item.get("name", "stdout"), "text": txt})

            elif itype == "error":
                self.output.append_error(item.get("traceback", ""))
                tb = item.get("traceback", "")
                if isinstance(tb, str):
                    tb_list = tb.splitlines()
                else:
                    tb_list = tb or []
                collected.append({
                    "output_type": "error",
                    "ename": item.get("ename", "Error"),
                    "evalue": item.get("evalue", ""),
                    "traceback": tb_list,
                })

            elif itype == "display":
                data = item.get("data") or {}

                # priorytety renderowania
                if "application/vnd.jupyter.widget-view+json" in data:
                    view = data.get("application/vnd.jupyter.widget-view+json")
                    self.output.append_widget_from_state(view or {}, self._widget_state)
                    collected.append({"output_type": "display_data", "data": data, "metadata": {}})
                    return

                if "application/vnd.plotly.v1+json" in data:
                    self.output.append_plotly(data.get("application/vnd.plotly.v1+json"))
                    collected.append({"output_type": "display_data", "data": data, "metadata": {}})
                    return

                if "text/html" in data:
                    self.output.append_html(data.get("text/html", ""))
                    collected.append({"output_type": "display_data", "data": data, "metadata": {}})
                    return

                if "image/png" in data:
                    self.output.append_png(data.get("image/png", ""))
                    collected.append({"output_type": "display_data", "data": data, "metadata": {}})
                    return

                if "text/plain" in data:
                    self.output.append_text_plain(str(data.get("text/plain", "")))
                    collected.append({"output_type": "execute_result", "data": data, "metadata": {}, "execution_count": None})
                    return

                # fallback
                self.output.append_text_plain("Unsupported mime bundle:\n" + json.dumps(list(data.keys()), indent=2))

        def on_done():
            self.output.append_text_plain("■ done")
            # zachowaj outputs w modelu komórki
            self.cell.outputs = collected
            self._running = False
            self._refresh_header()

        self.kernel_service.execute_notebook_cell(code, on_item=on_item, on_done=on_done)

    def to_cell(self) -> NotebookCell:
        # zachowaj outputs/execution_count/metadata (ważne przy zapisie .ipynb)
        return NotebookCell(
            cell_type=self.cell.cell_type,
            source=self.editor.toPlainText(),
            execution_count=self.cell.execution_count,
            outputs=self.cell.outputs or [],
            metadata=self.cell.metadata or {},
        )


class NotebookEditor(QWidget):
    modificationChanged = Signal(bool)

    def __init__(self, kernel_service: KernelService, parent=None):
        super().__init__(parent)
        self.kernel_service = kernel_service

        self._current_path: str | None = None
        self._modified: bool = False

        header = QHBoxLayout()
        self.info = QLabel("Notebook mode")
        self.info.setStyleSheet("color: #e6f1ff; padding: 6px;")

        self.btn_add_code = QPushButton("+ Code")
        self.btn_add_md = QPushButton("+ Markdown")

        header.addWidget(self.info)
        header.addStretch(1)
        header.addWidget(self.btn_add_code)
        header.addWidget(self.btn_add_md)

        self.container = QWidget()
        self.vbox = QVBoxLayout(self.container)
        self.vbox.setContentsMargins(6, 6, 6, 6)
        self.vbox.setSpacing(10)
        self.vbox.addStretch(1)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setWidget(self.container)
        self.scroll.setFrameShape(QFrame.NoFrame)

        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(8)
        root.addLayout(header)
        root.addWidget(self.scroll, 1)

        self._cells: list[NotebookCellWidget] = []
        self._doc_metadata: dict = {}
        self._widget_state: dict | None = None

        self.btn_add_code.clicked.connect(lambda: self.add_cell(NotebookCell("code", "")))
        self.btn_add_md.clicked.connect(lambda: self.add_cell(NotebookCell("markdown", "")))

    def clear(self):
        for cw in self._cells:
            cw.setParent(None)
        self._cells.clear()

    def load_doc(self, doc: NotebookDoc):
        """Ładuje notebook z pliku (wraz z outputami/metadata)."""
        self.clear()
        if not isinstance(doc, NotebookDoc):
            doc = NotebookDoc(cells=[], metadata={})

        self._doc_metadata = doc.metadata or {}
        self._widget_state = doc.widget_state()

        cells = doc.cells or []
        if not cells:
            # VS Code/Colab startują zwykle od jednej komórki kodu
            cells = [NotebookCell("code", "")]
        for c in cells:
            self.add_cell(c)
        self.set_modified(False)

    def add_cell(self, cell: NotebookCell):
        w = NotebookCellWidget(
            self.kernel_service,
            index=len(self._cells),
            cell=cell,
            widget_state=self._widget_state,
        )
        self.vbox.insertWidget(self.vbox.count() - 1, w)
        self._cells.append(w)
        # zmiana w komórce => notebook jest zmodyfikowany
        try:
            w.changed.connect(self._mark_modified)
        except Exception:
            pass
        try:
            w.btn_type.clicked.connect(self._mark_modified)
        except Exception:
            pass
        self._reindex()

    def _reindex(self):
        for i, cw in enumerate(self._cells):
            cw.index = i
            cw._refresh_header()

    def doc(self) -> NotebookDoc:
        return NotebookDoc(cells=[cw.to_cell() for cw in self._cells], metadata=self._doc_metadata)

    # kompatybilność wsteczna (starszy kod)
    def cells(self) -> list[NotebookCell]:
        return self.doc().cells

    # -------- file/dirty API (spójne z CodeEditor) --------

    def set_current_path(self, path: str | None):
        self._current_path = path

    def current_path(self) -> str | None:
        return self._current_path

    def is_modified(self) -> bool:
        return bool(self._modified)

    def set_modified(self, modified: bool):
        modified = bool(modified)
        if self._modified == modified:
            return
        self._modified = modified
        self.modificationChanged.emit(self._modified)

    def _mark_modified(self):
        self.set_modified(True)
