from __future__ import annotations

import re
from typing import Iterable

from PySide6.QtCore import Qt, QTimer, QPoint
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import QPlainTextEdit

from ui.editors.completion_popup import CompletionPopup


_SQL_KEYWORDS = [
    # common
    "SELECT","FROM","WHERE","GROUP","BY","ORDER","HAVING","LIMIT","FETCH","FIRST","ROWS","ONLY",
    "INSERT","INTO","VALUES","UPDATE","SET","DELETE",
    "CREATE","ALTER","DROP","TRUNCATE",
    "TABLE","VIEW","INDEX","SEQUENCE",
    "JOIN","LEFT","RIGHT","FULL","INNER","OUTER","CROSS","ON",
    "UNION","ALL","DISTINCT",
    "AND","OR","NOT","IN","EXISTS","BETWEEN","LIKE","IS","NULL",
    "CASE","WHEN","THEN","ELSE","END",
    "AS","WITH",
    "COUNT","SUM","MIN","MAX","AVG",
    "TRUE","FALSE",
    # ddl helpers
    "PRIMARY","KEY","FOREIGN","REFERENCES","DEFAULT","CHECK","UNIQUE",
    # misc
    "DESC","DESCRIBE","SHOW",
]


_word_re = re.compile(r"([A-Za-z_][\w$]*)(?:\.([A-Za-z_][\w$]*))?$")


class SqlEditor(QPlainTextEdit):
    """SQL editor with lightweight autocompletion.

    - Ctrl+Space: show completions
    - typing letters/underscore/dot: shows filtered popup
    - suggestions: SQL keywords + cached object names (schema.table / table)
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setUndoRedoEnabled(True)

        self._popup = CompletionPopup(self)
        self._popup.accepted.connect(self._insert_completion)
        self._compl_prefix = ""
        self._all_items: list[str] = []

        self._show_timer = QTimer(self)
        self._show_timer.setSingleShot(True)
        self._show_timer.setInterval(60)
        self._show_timer.timeout.connect(self._maybe_show_completions)

        self._force_popup = False

        # start with keywords
        self.set_catalog_items([])

    # ---------- public API ----------

    def set_catalog_items(self, items: Iterable[str]):
        # De-dup, keep stable order: keywords first, then items
        seen = set()
        merged: list[str] = []
        for k in _SQL_KEYWORDS:
            ku = k.upper()
            if ku not in seen:
                seen.add(ku)
                merged.append(ku)
        for it in items:
            s = str(it)
            if not s:
                continue
            if s not in seen:
                seen.add(s)
                merged.append(s)
        self._all_items = merged

    # ---------- internals ----------

    def _cursor_global_pos_for_popup(self) -> QPoint:
        r = self.cursorRect()
        p = self.mapToGlobal(r.bottomLeft())
        # a small offset so it doesn't overlap the caret line
        return QPoint(p.x(), p.y() + 6)
    def _current_prefix(self) -> str:
        tc = self.textCursor()
        block_text = tc.block().text()
        pos = tc.positionInBlock()
        start = pos
        while start > 0:
            ch = block_text[start - 1]
            if ch.isspace() or ch in "(){}[];,+-*/=%<>\"'":
                break
            start -= 1
        return block_text[start:pos]

    def _filter_items(self, prefix: str) -> list[str]:
        p = (prefix or "")
        if not p:
            return self._all_items[:]
        up = p.upper()
        # If user types lower-case, show keyword matches too
        out = []
        for it in self._all_items:
            if it.upper().startswith(up):
                out.append(it)
        return out

    def _maybe_show_completions(self):
        prefix = self._current_prefix()
        self._compl_prefix = prefix
        items = self._filter_items(prefix)

        # Don't show popup for 0/1 char unless Ctrl+Space
        if len(prefix) < 2 and not self._force_popup:
            self._popup.hide()
            return

        if not items:
            self._popup.hide()
            return

        self._popup.show_items(items, self._cursor_global_pos_for_popup())
    def _insert_completion(self, text: str):
        tc = self.textCursor()
        prefix = self._current_prefix()
        if prefix:
            tc.movePosition(QTextCursor.Left, QTextCursor.KeepAnchor, len(prefix))
            tc.removeSelectedText()
        tc.insertText(text)
        self.setTextCursor(tc)

    # ---------- key handling ----------

    def keyPressEvent(self, e):
        # Ctrl+Space forces popup
        if e.key() == Qt.Key_Space and (e.modifiers() & Qt.ControlModifier):
            # Do not insert an actual space; just force the popup.
            self._force_popup = True
            self._show_timer.stop()
            self._show_timer.start(0)
            return

        # If popup is open, allow navigation keys to go to popup
        if self._popup.isVisible() and e.key() in (
            Qt.Key_Up, Qt.Key_Down, Qt.Key_PageUp, Qt.Key_PageDown, Qt.Key_Home, Qt.Key_End
        ):
            self._popup.keyPressEvent(e)
            return

        # Accept completion with Enter/Tab when popup visible
        if self._popup.isVisible() and e.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Tab):
            it = self._popup.currentItem()
            if it:
                self._insert_completion(it.text())
            self._popup.hide()
            return

        self._force_popup = False
        super().keyPressEvent(e)

        # after typing, decide whether to show/update popup
        ch = e.text() or ""
        if ch and (ch.isalnum() or ch in "_.$"):
            self._show_timer.stop()
            self._show_timer.start()
        else:
            # on separators, hide
            if ch and ch.strip() == "":
                self._popup.hide()
            if e.key() == Qt.Key_Escape:
                self._popup.hide()
