from __future__ import annotations

from PySide6.QtCore import Qt, Signal, QPoint
from PySide6.QtWidgets import QListWidget, QListWidgetItem


class CompletionPopup(QListWidget):
    accepted = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowFlags(
            Qt.ToolTip
            | Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
        )
        self.setFocusPolicy(Qt.NoFocus)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setMaximumHeight(240)
        self.setMinimumWidth(360)

        self.itemClicked.connect(self._on_click)

        # lekki styl (pasuje do Twojego QSS)
        self.setStyleSheet("""
            QListWidget {
                background: #070b14;
                color: #e6f1ff;
                border: 1px solid #1b2a4a;
                border-radius: 10px;
                padding: 6px;
            }
            QListWidget::item {
                padding: 6px;
                border-radius: 8px;
            }
            QListWidget::item:selected {
                background: #132042;
                border: 1px solid #2b5cff;
            }
        """)

    def show_items(self, items: list[str], global_pos: QPoint):
        self.clear()
        for it in items[:300]:
            QListWidgetItem(it, self)

        if self.count() == 0:
            self.hide()
            return

        self.setCurrentRow(0)
        self.move(global_pos)
        self.show()
        self.raise_()

    def _on_click(self, item: QListWidgetItem):
        self.accepted.emit(item.text())
        self.hide()

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key_Return, Qt.Key_Enter):
            it = self.currentItem()
            if it:
                self.accepted.emit(it.text())
            self.hide()
            return

        if e.key() == Qt.Key_Escape:
            self.hide()
            return

        if e.key() in (Qt.Key_Up, Qt.Key_Down, Qt.Key_PageUp, Qt.Key_PageDown, Qt.Key_Home, Qt.Key_End):
            super().keyPressEvent(e)
            return

        # inne klawisze -> zamknij i pozwól edytorowi pisać dalej
        self.hide()
        e.ignore()
