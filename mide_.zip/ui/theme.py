# ui/theme.py

FUTURE_QSS = """
/* ---------- global ---------- */
QWidget {
    background: #050812;
    color: #e6f1ff;
    selection-background-color: #132042;
    selection-color: #e6f1ff;
    font-family: Segoe UI, Inter, Arial;
    font-size: 10pt;
}

/* ---------- menubar / menu ---------- */
QMenuBar {
    background: #070b14;
    color: #e6f1ff;
    border-bottom: 1px solid #1b2a4a;
    padding: 4px;
}
QMenuBar::item {
    background: transparent;
    padding: 6px 10px;
    border-radius: 8px;
}
QMenuBar::item:selected {
    background: #132042;
    border: 1px solid #2b5cff;
}
QMenu {
    background: #070b14;
    color: #e6f1ff;
    border: 1px solid #1b2a4a;
    border-radius: 10px;
    padding: 6px;
}
QMenu::item {
    padding: 8px 18px;
    border-radius: 8px;
}
QMenu::item:selected {
    background: #132042;
    border: 1px solid #2b5cff;
}
QMenu::separator {
    height: 1px;
    background: #1b2a4a;
    margin: 6px 6px;
}

/* ---------- toolbar ---------- */
QToolBar {
    background: #070b14;
    border-bottom: 1px solid #1b2a4a;
    spacing: 6px;
    padding: 4px;
}
QToolButton {
    background: #070b14;
    color: #e6f1ff;
    border: 1px solid #1b2a4a;
    border-radius: 10px;
    padding: 6px 10px;
}
QToolButton:hover {
    background: #0b1224;
    border: 1px solid #2b5cff;
}

/* ---------- docks ---------- */
QDockWidget {
    titlebar-close-icon: none;
    titlebar-normal-icon: none;
}
QDockWidget::title {
    background: #070b14;
    color: #b7c7dd;
    padding: 6px;
    border: 1px solid #1b2a4a;
    border-radius: 8px;
    margin: 4px;
}
QDockWidget QWidget {
    background: #050812;
}

/* ---------- tabs ---------- */
QTabWidget::pane {
    border: 1px solid #1b2a4a;
    border-radius: 10px;
}
QTabBar::tab {
    background: #070b14;
    color: #b7c7dd;
    padding: 8px 12px;
    border: 1px solid #1b2a4a;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    margin-right: 4px;
}
QTabBar::tab:selected {
    color: #e6f1ff;
    background: #0b1224;
    border: 1px solid #2b5cff;
}

/* ---------- inputs ---------- */
QLineEdit, QTextEdit, QPlainTextEdit {
    background: #070b14;
    color: #e6f1ff;
    border: 1px solid #1b2a4a;
    border-radius: 10px;
    padding: 8px;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border: 1px solid #2b5cff;
}
QCheckBox {
    spacing: 8px;
}
QCheckBox::indicator {
    width: 16px;
    height: 16px;
}
QCheckBox::indicator:unchecked {
    border: 1px solid #1b2a4a;
    border-radius: 4px;
    background: #070b14;
}
QCheckBox::indicator:checked {
    border: 1px solid #2b5cff;
    border-radius: 4px;
    background: #132042;
}

/* ---------- buttons ---------- */
QPushButton {
    background: #070b14;
    color: #e6f1ff;
    border: 1px solid #1b2a4a;
    border-radius: 10px;
    padding: 8px 12px;
}
QPushButton:hover {
    background: #0b1224;
    border: 1px solid #2b5cff;
}
QPushButton:disabled {
    color: #5c6b86;
    border: 1px solid #1b2a4a;
}

/* ---------- statusbar ---------- */
QStatusBar {
    background: #070b14;
    border-top: 1px solid #1b2a4a;
    color: #b7c7dd;
}
"""
