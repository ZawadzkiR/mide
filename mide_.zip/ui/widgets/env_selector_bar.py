from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Dict, Any, Union

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel, QComboBox


@dataclass(frozen=True)
class EnvironmentItem:
    """Pojedyncza pozycja środowiska w comboboxie."""

    key: str
    kind: str  # 'python' | 'r' | 'python-kernel' | 'python-pseudo' | 'jupyterhub'
    name: str
    path: str
    libs_path: str = ""
    # JupyterHub (remote)
    hub_url: str = ""
    hub_user: str = ""


class EnvironmentSelectorBar(QWidget):
    """Pasek z wyborem środowiska uruchomieniowego (prawy górny róg nad edytorem)."""

    environmentChanged = Signal(str)  # key

    def __init__(self, parent=None):
        super().__init__(parent)

        self._items: List[EnvironmentItem] = []

        self.lbl = QLabel("Environment:")
        self.lbl.setStyleSheet("color:#b7c7dd; padding: 0 6px;")

        self.combo = QComboBox()
        self.combo.setMinimumWidth(260)
        self.combo.setStyleSheet(
            "QComboBox { background:#060914; color:#e6f1ff; border:1px solid #1b2a4a; border-radius:10px; padding:6px 10px; }"
            "QComboBox QAbstractItemView { background:#060914; color:#e6f1ff; selection-background-color:#17325c; border:1px solid #1b2a4a; }"
        )
        self.combo.currentIndexChanged.connect(self._emit_changed)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 6, 8, 6)
        lay.setSpacing(6)
        lay.addStretch(1)
        lay.addWidget(self.lbl)
        lay.addWidget(self.combo)

        self.setStyleSheet("background: transparent;")

    def set_items(self, envs: List[Union[Dict, 'EnvironmentItem', Any]], selected_key: Optional[str] = None):
        self._items = []
        self.combo.blockSignals(True)
        self.combo.clear()

        for e in (envs or []):
            # wspieraj zarówno dict (z SettingsService), jak i EnvironmentItem (budowane w MainWindow)
            if isinstance(e, EnvironmentItem):
                key = str(e.key or "")
                kind = str(e.kind or "")
                name = str(e.name or key)
                path = str(e.path or "")
                libs = str(e.libs_path or "")
                hub_url = str(e.hub_url or "")
                hub_user = str(e.hub_user or "")
            else:
                e = e or {}
                # dict może zawierać "libs" albo "libs_path" (historycznie)
                key = str(getattr(e, "get", lambda _k, _d=None: "")("key") or "")
                kind = str(getattr(e, "get", lambda _k, _d=None: "")("kind") or "")
                name = str(getattr(e, "get", lambda _k, _d=None: "")("name") or key)
                path = str(getattr(e, "get", lambda _k, _d=None: "")("path") or "")
                libs = str(
                    (getattr(e, "get", lambda _k, _d=None: "")("libs") or "")
                    or (getattr(e, "get", lambda _k, _d=None: "")("libs_path") or "")
                )
                hub_url = str(getattr(e, "get", lambda _k, _d=None: "")("hub_url") or "")
                hub_user = str(getattr(e, "get", lambda _k, _d=None: "")("hub_user") or "")

            # spójne etykiety
            if key == "python:kernel" or kind == "python-kernel":
                label = f"{name}"
            elif kind == "python-pseudo":
                label = f"{name} (Pseudo-Venv)"
            elif kind == "jupyterhub":
                # pokazuj user@hub dla czytelności
                tail = ""
                if hub_user and hub_url:
                    tail = f" ({hub_user}@{hub_url})"
                elif hub_url:
                    tail = f" ({hub_url})"
                label = f"{name} (JupyterHub){tail}"
            elif kind == "r":
                label = f"{name} (R)"
            else:
                label = f"{name} (Python)"

            item = EnvironmentItem(
                key=key,
                kind=kind,
                name=name,
                path=path,
                libs_path=libs,
                hub_url=hub_url,
                hub_user=hub_user,
            )
            self._items.append(item)
            self.combo.addItem(label, key)

        # wybór
        if selected_key:
            idx = self.combo.findData(selected_key)
            if idx >= 0:
                self.combo.setCurrentIndex(idx)

        self.combo.blockSignals(False)

    def current_key(self) -> Optional[str]:
        return self.combo.currentData()

    def current_item(self) -> Optional[EnvironmentItem]:
        key = self.current_key()
        if not key:
            return None
        for it in self._items:
            if it.key == key:
                return it
        return None

    def select_key(self, key: str):
        idx = self.combo.findData(key)
        if idx >= 0:
            self.combo.setCurrentIndex(idx)

    def _emit_changed(self):
        key = self.current_key()
        if key:
            self.environmentChanged.emit(str(key))
