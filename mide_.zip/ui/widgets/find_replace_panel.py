# ui/widgets/find_replace_panel.py
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QLineEdit,
    QPushButton, QCheckBox
)


class FindReplacePanel(QWidget):
    """
    Panel find/replace (dock):
    - Find next/prev
    - Replace / Replace all
    - Match case
    - Regex
    """
    find_next = Signal(str, bool, bool)   # text, match_case, regex
    find_prev = Signal(str, bool, bool)
    replace_one = Signal(str, str, bool, bool)
    replace_all = Signal(str, str, bool, bool)
    close_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)

        self.lbl_find = QLabel("Find")
        self.txt_find = QLineEdit()
        self.btn_next = QPushButton("Next")
        self.btn_prev = QPushButton("Prev")

        self.lbl_replace = QLabel("Replace")
        self.txt_replace = QLineEdit()
        self.btn_replace = QPushButton("Replace")
        self.btn_replace_all = QPushButton("All")

        self.cb_case = QCheckBox("Match case")
        self.cb_regex = QCheckBox("Regex")

        self.btn_close = QPushButton("×")
        self.btn_close.setFixedWidth(36)

        row1 = QHBoxLayout()
        row1.addWidget(self.lbl_find)
        row1.addWidget(self.txt_find, 1)
        row1.addWidget(self.btn_prev)
        row1.addWidget(self.btn_next)
        row1.addWidget(self.cb_case)
        row1.addWidget(self.cb_regex)
        row1.addWidget(self.btn_close)

        row2 = QHBoxLayout()
        row2.addWidget(self.lbl_replace)
        row2.addWidget(self.txt_replace, 1)
        row2.addWidget(self.btn_replace)
        row2.addWidget(self.btn_replace_all)

        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)
        root.addLayout(row1)
        root.addLayout(row2)

        self.btn_next.clicked.connect(self._emit_next)
        self.btn_prev.clicked.connect(self._emit_prev)
        self.btn_replace.clicked.connect(self._emit_replace_one)
        self.btn_replace_all.clicked.connect(self._emit_replace_all)
        self.btn_close.clicked.connect(self.close_requested.emit)

        self.txt_find.returnPressed.connect(self._emit_next)

    def focus_find(self):
        self.txt_find.setFocus()
        self.txt_find.selectAll()

    def focus_replace(self):
        self.txt_replace.setFocus()
        self.txt_replace.selectAll()

    def _emit_next(self):
        self.find_next.emit(self.txt_find.text(), self.cb_case.isChecked(), self.cb_regex.isChecked())

    def _emit_prev(self):
        self.find_prev.emit(self.txt_find.text(), self.cb_case.isChecked(), self.cb_regex.isChecked())

    def _emit_replace_one(self):
        self.replace_one.emit(
            self.txt_find.text(),
            self.txt_replace.text(),
            self.cb_case.isChecked(),
            self.cb_regex.isChecked()
        )

    def _emit_replace_all(self):
        self.replace_all.emit(
            self.txt_find.text(),
            self.txt_replace.text(),
            self.cb_case.isChecked(),
            self.cb_regex.isChecked()
        )
