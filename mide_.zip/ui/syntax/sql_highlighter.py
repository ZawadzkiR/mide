from __future__ import annotations

import re
from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor, QFont


def _fmt(color_hex: str, bold: bool = False, italic: bool = False) -> QTextCharFormat:
    f = QTextCharFormat()
    f.setForeground(QColor(color_hex))
    if bold:
        f.setFontWeight(QFont.Bold)
    if italic:
        f.setFontItalic(True)
    return f


class SqlHighlighter(QSyntaxHighlighter):
    """Minimal SQL syntax highlighter.

    This is not a full parser; it's a pragmatic highlighter that covers:
    - keywords
    - common functions
    - strings, numbers
    - comments (-- and /* */)
    """

    def __init__(self, doc):
        super().__init__(doc)

        self.f_keyword = _fmt("#6cb6ff", bold=True)
        self.f_function = _fmt("#7ee787", bold=True)
        self.f_string = _fmt("#f2cc60")
        self.f_number = _fmt("#ffab70")
        self.f_comment = _fmt("#8b949e", italic=True)
        self.f_operator = _fmt("#c9d1d9")

        keywords = [
            "SELECT", "FROM", "WHERE", "GROUP", "BY", "ORDER", "HAVING",
            "LIMIT", "FETCH", "FIRST", "ROWS", "ONLY", "OFFSET",
            "INSERT", "INTO", "VALUES", "UPDATE", "SET", "DELETE",
            "CREATE", "ALTER", "DROP", "TRUNCATE",
            "TABLE", "VIEW", "INDEX", "SEQUENCE", "FUNCTION", "PROCEDURE",
            "WITH", "AS", "DISTINCT", "ALL", "UNION", "INTERSECT", "MINUS",
            "JOIN", "INNER", "LEFT", "RIGHT", "FULL", "OUTER", "CROSS", "ON",
            "AND", "OR", "NOT", "IN", "EXISTS", "BETWEEN", "LIKE", "IS", "NULL",
            "CASE", "WHEN", "THEN", "ELSE", "END",
        ]

        functions = [
            "COUNT", "SUM", "AVG", "MIN", "MAX",
            "COALESCE", "NVL", "NULLIF",
            "SUBSTR", "SUBSTRING", "LENGTH", "LOWER", "UPPER", "TRIM",
            "ROUND", "FLOOR", "CEIL",
            "TO_DATE", "TO_TIMESTAMP", "SYSDATE", "CURRENT_DATE", "CURRENT_TIMESTAMP",
        ]

        self.rx_keywords = re.compile(r"\b(" + "|".join(keywords) + r")\b", re.IGNORECASE)
        self.rx_functions = re.compile(r"\b(" + "|".join(functions) + r")\b(?=\s*\()", re.IGNORECASE)
        self.rx_number = re.compile(r"\b\d+(?:\.\d+)?\b")
        self.rx_string1 = re.compile(r"'(?:''|[^'])*'")
        self.rx_string2 = re.compile(r'"(?:""|[^"])*"')
        self.rx_line_comment = re.compile(r"--.*$")

        # Multiline block comments handled by states
        self.rx_block_start = re.compile(r"/\*")
        self.rx_block_end = re.compile(r"\*/")

    def highlightBlock(self, text: str):
        # block comments
        self.setCurrentBlockState(0)
        start = 0
        if self.previousBlockState() == 1:
            end_m = self.rx_block_end.search(text)
            if not end_m:
                self.setFormat(0, len(text), self.f_comment)
                self.setCurrentBlockState(1)
                return
            end = end_m.end()
            self.setFormat(0, end, self.f_comment)
            start = end

        while True:
            m = self.rx_block_start.search(text, start)
            if not m:
                break
            m_end = self.rx_block_end.search(text, m.end())
            if not m_end:
                self.setFormat(m.start(), len(text) - m.start(), self.f_comment)
                self.setCurrentBlockState(1)
                return
            self.setFormat(m.start(), m_end.end() - m.start(), self.f_comment)
            start = m_end.end()

        # line comments
        for m in self.rx_line_comment.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), self.f_comment)

        # strings
        for m in self.rx_string1.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), self.f_string)
        for m in self.rx_string2.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), self.f_string)

        # numbers
        for m in self.rx_number.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), self.f_number)

        # functions
        for m in self.rx_functions.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), self.f_function)

        # keywords
        for m in self.rx_keywords.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), self.f_keyword)
