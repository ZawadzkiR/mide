import os
import json
from typing import Optional, Dict, Any, List

from PySide6.QtCore import Signal, Qt, QThread
from PySide6.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTreeWidget,
    QTreeWidgetItem, QMenu, QInputDialog, QMessageBox, QFileDialog
)

from services.jupyterhub_client import JupyterHubClient, JupyterHubEnv


class _ListWorker(QThread):
    resultReady = Signal(object, object)  # (err, data)

    def __init__(self, client: JupyterHubClient, path: str):
        super().__init__()
        self.client = client
        self.path = path

    def run(self):
        try:
            data = self.client.contents_get(self.path, content=True)
            self.resultReady.emit(None, data)
        except Exception as e:
            self.resultReady.emit(e, None)


class JupyterHubFilesDock(QDockWidget):
    """Minimalny browser plików JupyterHub przez /api/contents."""

    file_open_requested = Signal(str)  # local cached path
    remote_mapping_ready = Signal(str, str)  # local_path, remote_path

    def __init__(self, parent=None):
        super().__init__("JupyterHub Files", parent)
        self.setObjectName("dock.jupyterhub_files")

        self._client: Optional[JupyterHubClient] = None
        self._root_path: str = ""  # remote
        self._cache_dir: str = os.path.join(os.path.expanduser("~"), ".mIDE_jupyterhub_cache")
        os.makedirs(self._cache_dir, exist_ok=True)

        self.btn_refresh = QPushButton("Refresh")
        self.btn_root = QPushButton("Set root")

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemDoubleClicked.connect(self._on_double)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._ctx)

        top = QHBoxLayout()
        top.addWidget(self.btn_refresh)
        top.addWidget(self.btn_root)
        top.addStretch(1)

        wrap = QWidget()
        lay = QVBoxLayout(wrap)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.addLayout(top)
        lay.addWidget(self.tree, 1)
        self.setWidget(wrap)

        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_root.clicked.connect(self._set_root_dialog)

        self._list_worker: Optional[_ListWorker] = None

    def set_env(self, hub_url: str, hub_user: str, hub_token: str):
        hub_url = (hub_url or "").strip()
        hub_user = (hub_user or "").strip()
        hub_token = (hub_token or "").strip()
        if not hub_url or not hub_user or not hub_token:
            self._client = None
            self.tree.clear()
            return
        self._client = JupyterHubClient(JupyterHubEnv(hub_url=hub_url, user=hub_user, token=hub_token))

    def set_root(self, remote_path: str):
        self._root_path = (remote_path or "").strip().strip("/")
        self.refresh()

    def refresh(self):
        if not self._client:
            self.tree.clear()
            self.tree.addTopLevelItem(QTreeWidgetItem(["(Select JupyterHub environment)"]))
            return
        # start server (best-effort)
        try:
            self._client.start_user_server()
        except Exception:
            pass

        # async list
        if self._list_worker and self._list_worker.isRunning():
            return
        self.tree.clear()
        self.tree.addTopLevelItem(QTreeWidgetItem(["Loading..."]))
        w = _ListWorker(self._client, self._root_path)
        self._list_worker = w
        w.resultReady.connect(self._on_list)
        w.start()

    def _on_list(self, err, data):
        self.tree.clear()
        if err is not None:
            self.tree.addTopLevelItem(QTreeWidgetItem([f"Error: {err}"]))
            return
        # directory listing
        items = data.get("content") or []
        # sort: dirs first
        items = sorted(items, key=lambda x: (0 if x.get("type") == "directory" else 1, x.get("name") or ""))
        root_label = self._root_path or "/"
        root = QTreeWidgetItem([root_label])
        root.setData(0, Qt.UserRole, {"path": self._root_path, "type": "directory"})
        self.tree.addTopLevelItem(root)
        root.setExpanded(True)
        for it in items:
            self._add_item(root, it)

    def _add_item(self, parent: QTreeWidgetItem, it: Dict[str, Any]):
        name = str(it.get("name") or it.get("path") or "")
        t = str(it.get("type") or "")
        node = QTreeWidgetItem([name])
        node.setData(0, Qt.UserRole, {"path": str(it.get("path") or ""), "type": t})
        parent.addChild(node)

    def _on_double(self, item: QTreeWidgetItem, _col: int):
        meta = item.data(0, Qt.UserRole) or {}
        if meta.get("type") == "directory":
            # enter directory as root for now
            self.set_root(str(meta.get("path") or "").lstrip("/"))
            return
        self._open_file(str(meta.get("path") or ""))

    def _open_file(self, remote_path: str):
        if not self._client:
            return
        try:
            info = self._client.contents_get(remote_path, content=True)
            content = info.get("content")
            fmt = info.get("format")
            if fmt != "text":
                QMessageBox.information(self, "Open", "Ten typ pliku nie jest tekstowy (format != text).")
                return
            text = content if isinstance(content, str) else ""

            safe = remote_path.strip("/").replace("/", "__")
            local_path = os.path.join(self._cache_dir, safe)
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            with open(local_path, "w", encoding="utf-8") as f:
                f.write(text)
            self.remote_mapping_ready.emit(local_path, remote_path)
            self.file_open_requested.emit(local_path)
        except Exception as e:
            QMessageBox.warning(self, "Open", str(e))

    def _set_root_dialog(self):
        p, ok = QInputDialog.getText(self, "JupyterHub root", "Remote path (e.g. / or notebooks):", text="/" + (self._root_path or ""))
        if not ok:
            return
        self.set_root((p or "").strip().lstrip("/"))

    def _ctx(self, pos):
        item = self.tree.itemAt(pos)
        if not item or not self._client:
            return
        meta = item.data(0, Qt.UserRole) or {}
        path = str(meta.get("path") or "")
        typ = str(meta.get("type") or "")

        menu = QMenu(self.tree)
        act_new_file = menu.addAction("New File")
        act_new_folder = menu.addAction("New Folder")
        menu.addSeparator()
        act_rename = menu.addAction("Rename")
        act_delete = menu.addAction("Delete")
        menu.addSeparator()
        act_upload = menu.addAction("Upload file")

        base_dir = path if typ == "directory" else "/".join(path.split("/")[:-1])

        def _new_file():
            name, ok = QInputDialog.getText(self, "New File", "File name:")
            if not ok or not (name or "").strip():
                return
            target = (base_dir.rstrip("/") + "/" + name.strip()).lstrip("/")
            try:
                self._client.contents_put_text(target, "")
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "New File", str(e))

        def _new_folder():
            name, ok = QInputDialog.getText(self, "New Folder", "Folder name:")
            if not ok or not (name or "").strip():
                return
            target = (base_dir.rstrip("/") + "/" + name.strip()).lstrip("/")
            try:
                self._client.contents_mkdir(target)
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "New Folder", str(e))

        def _rename():
            old = path.split("/")[-1]
            name, ok = QInputDialog.getText(self, "Rename", "New name:", text=old)
            if not ok or not (name or "").strip() or name.strip() == old:
                return
            new_path = ("/".join(path.split("/")[:-1]) + "/" + name.strip()).lstrip("/")
            try:
                self._client.contents_rename(path, new_path)
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "Rename", str(e))

        def _delete():
            if QMessageBox.question(self, "Delete", f"Delete remote:\n{path}") != QMessageBox.Yes:
                return
            try:
                self._client.contents_delete(path)
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "Delete", str(e))

        def _upload():
            fp, _ = QFileDialog.getOpenFileName(self, "Upload file", "", "All files (*.*)")
            if not fp:
                return
            try:
                with open(fp, "r", encoding="utf-8") as f:
                    text = f.read()
                name = os.path.basename(fp)
                target = (base_dir.rstrip("/") + "/" + name).lstrip("/")
                self._client.contents_put_text(target, text)
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "Upload", str(e))

        act_new_file.triggered.connect(_new_file)
        act_new_folder.triggered.connect(_new_folder)
        act_rename.triggered.connect(_rename)
        act_delete.triggered.connect(_delete)
        act_upload.triggered.connect(_upload)

        menu.exec(self.tree.viewport().mapToGlobal(pos))
