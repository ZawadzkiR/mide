import os
import shutil
import json
from PySide6.QtCore import Signal, QModelIndex, Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QTreeView, QFileSystemModel,
    QMenu, QInputDialog, QMessageBox
)


class ProjectDock(QDockWidget):
    file_open_requested = Signal(str)

    def __init__(self, parent=None):
        super().__init__("Project", parent)
        self.setObjectName("dock.project")

        self.model = QFileSystemModel(self)
        self.model.setReadOnly(True)

        self.tree = QTreeView()
        self.tree.setModel(self.model)
        self.tree.setHeaderHidden(True)
        self.tree.doubleClicked.connect(self._on_double_click)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._context_menu)

        wrap = QWidget()
        lay = QVBoxLayout(wrap)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.addWidget(self.tree)
        self.setWidget(wrap)

        self._root: str | None = None

    def set_root(self, root: str):
        root = os.path.abspath(root)
        self._root = root
        self.model.setRootPath(root)
        idx = self.model.index(root)
        self.tree.setRootIndex(idx)

        for col in range(1, self.model.columnCount()):
            self.tree.setColumnHidden(col, True)

    def _on_double_click(self, index: QModelIndex):
        path = self.model.filePath(index)
        if os.path.isfile(path):
            self.file_open_requested.emit(path)

    def _context_menu(self, pos):
        idx = self.tree.indexAt(pos)
        if not idx.isValid():
            return

        path = self.model.filePath(idx)
        is_dir = os.path.isdir(path)
        base_dir = path if is_dir else os.path.dirname(path)

        menu = QMenu(self.tree)

        act_new_file = QAction("New File", self.tree)
        act_new_folder = QAction("New Folder", self.tree)
        act_rename = QAction("Rename", self.tree)
        act_delete = QAction("Delete", self.tree)

        menu.addAction(act_new_file)
        menu.addAction(act_new_folder)
        menu.addSeparator()
        menu.addAction(act_rename)
        menu.addAction(act_delete)

        def new_file():
            name, ok = QInputDialog.getText(self.tree, "New File", "File name:")
            if not ok or not name.strip():
                return
            target = os.path.join(base_dir, name.strip())
            if os.path.exists(target):
                QMessageBox.warning(self.tree, "New File", "File already exists.")
                return
            try:
                if target.lower().endswith(".ipynb"):
                    nb = {
                        "cells": [
                            {
                                "cell_type": "code",
                                "execution_count": None,
                                "metadata": {},
                                "outputs": [],
                                "source": []
                            }
                        ],
                        "metadata": {
                            "kernelspec": {"name": "python3", "display_name": "Python 3"},
                            "language_info": {"name": "python"}
                        },
                        "nbformat": 4,
                        "nbformat_minor": 5
                    }
                    with open(target, "w", encoding="utf-8") as f:
                        json.dump(nb, f, ensure_ascii=False, indent=2)
                else:
                    with open(target, "w", encoding="utf-8") as f:
                        f.write("")
                self.file_open_requested.emit(target)
            except Exception as e:
                QMessageBox.critical(self.tree, "New File", str(e))

        def new_folder():
            name, ok = QInputDialog.getText(self.tree, "New Folder", "Folder name:")
            if not ok or not name.strip():
                return
            target = os.path.join(base_dir, name.strip())
            if os.path.exists(target):
                QMessageBox.warning(self.tree, "New Folder", "Folder already exists.")
                return
            try:
                os.makedirs(target, exist_ok=False)
            except Exception as e:
                QMessageBox.critical(self.tree, "New Folder", str(e))

        def rename():
            old = os.path.basename(path)
            name, ok = QInputDialog.getText(self.tree, "Rename", "New name:", text=old)
            if not ok or not name.strip() or name.strip() == old:
                return
            target = os.path.join(os.path.dirname(path), name.strip())
            if os.path.exists(target):
                QMessageBox.warning(self.tree, "Rename", "Target already exists.")
                return
            try:
                os.rename(path, target)
            except Exception as e:
                QMessageBox.critical(self.tree, "Rename", str(e))

        def delete():
            reply = QMessageBox.question(
                self.tree,
                "Delete",
                f"Delete:\n{path}",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
                else:
                    os.remove(path)
            except Exception as e:
                QMessageBox.critical(self.tree, "Delete", str(e))

        act_new_file.triggered.connect(new_file)
        act_new_folder.triggered.connect(new_folder)
        act_rename.triggered.connect(rename)
        act_delete.triggered.connect(delete)

        menu.exec(self.tree.viewport().mapToGlobal(pos))
