from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QTreeWidget, QTreeWidgetItem, QAbstractItemView
)


class ProblemsDock(QDockWidget):
    """Dock z problemami (na razie: SyntaxError).

    - dwuklik / Enter na pozycji -> skok do pliku i linii
    """

    navigate_requested = Signal(str, int, int)  # path, line, col

    def __init__(self, parent=None):
        super().__init__("Problems", parent)
        self.setObjectName("dock.problems")

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Plik", "Linia", "Opis"])
        self.tree.setRootIsDecorated(False)
        self.tree.setUniformRowHeights(True)
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)

        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.addWidget(self.tree)
        self.setWidget(w)

        self.tree.itemActivated.connect(self._on_item_activated)

    def clear(self):
        self.tree.clear()

    def set_items(self, items):
        """Ustaw listę problemów.

        Wspierane formaty:
        - list[tuple[path, line, msg]]
        - list[dict] z kluczami: path, line, col (opcjonalnie), message/msg
        """
        self.tree.clear()

        for it in items or []:
            if isinstance(it, dict):
                path = str(it.get("path", ""))
                line = int(it.get("line", 1) or 1)
                col = int(it.get("col", 1) or 1)
                msg = str(it.get("message", it.get("msg", "")))
            else:
                # tuple/list
                path = str(it[0]) if len(it) > 0 else ""
                line = int(it[1]) if len(it) > 1 else 1
                col = 1
                msg = str(it[2]) if len(it) > 2 else ""

            twi = QTreeWidgetItem([path, str(line), msg])
            twi.setData(0, Qt.UserRole, path)
            twi.setData(1, Qt.UserRole, line)
            twi.setData(2, Qt.UserRole, col)
            self.tree.addTopLevelItem(twi)

        self.tree.resizeColumnToContents(1)

    def _on_item_activated(self, item: QTreeWidgetItem, _col: int):
        path = item.data(0, Qt.UserRole) or ""
        line = int(item.data(1, Qt.UserRole) or 1)
        col = int(item.data(2, Qt.UserRole) or 1)
        if path:
            self.navigate_requested.emit(str(path), int(line), int(col))
