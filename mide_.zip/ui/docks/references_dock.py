from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QDockWidget, QWidget, QVBoxLayout, QTreeWidget, QTreeWidgetItem, QLabel


class ReferencesDock(QDockWidget):
    """
    Dock na wyniki "Find References" jak w VS Code.
    Emisja: (path, line, col)
    """
    navigate_requested = Signal(str, int, int)

    def __init__(self, parent=None):
        super().__init__("References", parent)
        self.setObjectName("dock.references")

        self._root = QWidget()
        self.setWidget(self._root)

        lay = QVBoxLayout(self._root)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        self.lbl = QLabel("Brak wyników.")
        self.lbl.setStyleSheet("color: #b7c7dd;")
        lay.addWidget(self.lbl)

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setStyleSheet("""
            QTreeWidget {
                background: #070b14;
                color: #e6f1ff;
                border: 1px solid #1b2a4a;
                border-radius: 10px;
            }
            QTreeWidget::item {
                padding: 6px;
                border-radius: 8px;
            }
            QTreeWidget::item:selected {
                background: #132042;
                border: 1px solid #2b5cff;
            }
        """)
        lay.addWidget(self.tree, 1)

        self.tree.itemActivated.connect(self._on_item_activated)

    def clear(self):
        self.tree.clear()
        self.lbl.setText("Brak wyników.")

    def set_results(self, results: list[tuple[str, int, int, str]]):
        """
        results: list[(path, line, col, name)]
        """
        self.tree.clear()

        if not results:
            self.lbl.setText("Brak wyników.")
            return

        # Grupuj po pliku
        by_file: dict[str, list[tuple[int, int, str]]] = {}
        for p, ln, col, name in results:
            p = str(p) if p is not None else ""
            if not p:
                continue
            by_file.setdefault(p, []).append((int(ln), int(col), str(name)))

        self.lbl.setText(f"Wyniki: {sum(len(v) for v in by_file.values())}")

        for p, items in by_file.items():
            top = QTreeWidgetItem([p])
            top.setData(0, Qt.UserRole, ("file", p, 0, 0))
            self.tree.addTopLevelItem(top)

            for ln, col, name in items[:1000]:
                child = QTreeWidgetItem([f"{name}  —  {ln}:{col}"])
                child.setData(0, Qt.UserRole, ("ref", p, ln, col))
                top.addChild(child)

            top.setExpanded(True)

        self.tree.resizeColumnToContents(0)

    def _on_item_activated(self, item: QTreeWidgetItem, _col: int):
        data = item.data(0, Qt.UserRole)
        if not data:
            return
        kind, p, ln, col = data
        if kind == "ref":
            self.navigate_requested.emit(p, int(ln), int(col))
