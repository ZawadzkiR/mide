from __future__ import annotations

from typing import Optional, Tuple

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTreeWidget,
    QTreeWidgetItem,
    QMenu,
    QMessageBox,
    QLabel,
    QToolButton,
    QStyle,
)

from services.db_service import DbService, DbConnection
from services.db_runtime import DbRuntime

# ------------------------
# Tree item roles
# ------------------------
ROLE_KIND = Qt.UserRole + 1   # 'schema' | 'folder' | 'table' | 'view'
ROLE_SCHEMA = Qt.UserRole + 2
ROLE_NAME = Qt.UserRole + 3
ROLE_FULL = Qt.UserRole + 4


class DbExplorerDock(QDockWidget):
    """DB Explorer.

    Ten dock jest spięty z aktualnym `ui/main_window.py`:
    - `MainWindow` przekazuje tu `DbService` (definicje połączeń), nie runtime.
    - Dock emituje żądania (connect/disconnect/refresh/preview/look).
    - Ładowanie schematów/tabel wykonuje dock, ale TYLKO dla `connected_key`.

    Dzięki temu nie ma auto-connect i nie ma wywołań na starcie.
    """

    # --- sygnały oczekiwane przez MainWindow ---
    connectRequested = Signal(str)          # conn_key
    disconnectRequested = Signal(str)       # conn_key
    refreshRequested = Signal(str)          # conn_key
    tableLookRequested = Signal(str, str, str)            # conn_key, schema, table
    tableSelected = Signal(str, str, str)                 # conn_key, schema, table
    tablePreviewRequested = Signal(str, str, str, int)    # conn_key, obj_type, full_name, limit

    def __init__(self, db_service: DbService, parent=None):
        super().__init__("DB Explorer", parent)
        self.db = db_service
        self.runtime = DbRuntime()

        self._selected_key: str = ""
        self._connected_key: str = ""

        root = QWidget(self)
        self.setWidget(root)

        lay = QVBoxLayout(root)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(6)

        # Toolbar (ikonki jak w SqlScreen)
        tb = QHBoxLayout()
        tb.setContentsMargins(0, 0, 0, 0)

        self.btn_connect = QToolButton()
        self.btn_disconnect = QToolButton()
        self.btn_refresh = QToolButton()

        st = self.style()
        self.btn_connect.setIcon(st.standardIcon(QStyle.SP_DialogApplyButton))
        self.btn_disconnect.setIcon(st.standardIcon(QStyle.SP_DialogCancelButton))
        self.btn_refresh.setIcon(st.standardIcon(QStyle.SP_BrowserReload))

        self.btn_connect.setToolTip("Connect")
        self.btn_disconnect.setToolTip("Disconnect")
        self.btn_refresh.setToolTip("Refresh connection (reconnect)")

        self.btn_connect.clicked.connect(self._emit_connect)
        self.btn_disconnect.clicked.connect(self._emit_disconnect)
        self.btn_refresh.clicked.connect(self._emit_refresh)

        tb.addWidget(self.btn_connect)
        tb.addWidget(self.btn_disconnect)
        tb.addWidget(self.btn_refresh)
        tb.addStretch(1)

        lay.addLayout(tb)

        self.lbl_state = QLabel("")
        self.lbl_state.setObjectName("dbExplorerState")
        lay.addWidget(self.lbl_state)

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setAnimated(False)

        # IMPORTANT:
        # Nie uruchamiamy żadnych zapytań po kliknięciu ani po dwukliku.
        # Jedynym sposobem obejrzenia danych jest menu kontekstowe (PPM) -> Look table.

        # PPM
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._on_context_menu)

        lay.addWidget(self.tree, 1)

        self._sync_buttons()
        self._render_placeholder()

    # ------------------------
    # API używane przez MainWindow
    # ------------------------

    def set_selected_key(self, key: str):
        self._selected_key = str(key or "")
        self._sync_buttons()

    def set_connected_key(self, key: str):
        self._connected_key = str(key or "")
        self._sync_buttons()
        # po zmianie połączenia: przeładuj listę obiektów
        self.reload(self._selected_key)

    def reload(self, selected_key: str):
        """Wywoływane przy wejściu w SQL mode. Nie łączy się z DB, tylko odświeża UI."""
        self.set_selected_key(selected_key)
        if not self._connected_key or self._connected_key != self._selected_key:
            self._render_placeholder()
            return
        self._load_tree_for_connected()

    # ------------------------
    # UI helpers
    # ------------------------

    def _sync_buttons(self):
        sel = bool(self._selected_key)
        connected = bool(self._connected_key) and self._connected_key == self._selected_key

        self.btn_connect.setEnabled(sel and not connected)
        self.btn_disconnect.setEnabled(connected)
        self.btn_refresh.setEnabled(connected)

        if connected:
            self.lbl_state.setText(f"Connected: {self._connected_key}")
        elif sel:
            self.lbl_state.setText(f"Selected: {self._selected_key} (not connected)")
        else:
            self.lbl_state.setText("No connection selected")

    def _render_placeholder(self):
        self.tree.clear()
        if not self._selected_key:
            QTreeWidgetItem(self.tree, ["Select a connection in SQL screen"])  # info
        elif self._selected_key != self._connected_key:
            QTreeWidgetItem(self.tree, ["Click Connect to load schemas/tables"])  # info
        else:
            QTreeWidgetItem(self.tree, ["Loading..."])  # should be replaced quickly

    # ------------------------
    # Signals emit
    # ------------------------

    def _emit_connect(self):
        if self._selected_key:
            self.connectRequested.emit(self._selected_key)

    def _emit_disconnect(self):
        if self._connected_key:
            self.disconnectRequested.emit(self._connected_key)

    def _emit_refresh(self):
        if self._connected_key:
            self.refreshRequested.emit(self._connected_key)

    # ------------------------
    # Load schemas/objects (only when connected)
    # ------------------------

    def _load_tree_for_connected(self):
        self.tree.clear()

        conn = self._get_conn(self._connected_key)
        if not conn:
            QTreeWidgetItem(self.tree, ["Connection not found in settings."])
            return

        try:
            schemas = self.runtime.list_schemas(conn)
        except Exception as e:
            # nie wywalaj całego UI – dla części driverów schematy mogą nie działać
            QMessageBox.warning(self, "DB Explorer", f"List schemas failed:\n{e}")
            schemas = []

        if not schemas:
            self._add_objects_under(self.tree.invisibleRootItem(), conn, schema=None)
            return

        for s in schemas:
            schema_item = QTreeWidgetItem([str(s)])
            schema_item.setData(0, ROLE_KIND, "schema")
            schema_item.setData(0, ROLE_SCHEMA, str(s))
            self.tree.addTopLevelItem(schema_item)

            self._add_objects_under(schema_item, conn, schema=str(s))
            schema_item.setExpanded(False)

    def _add_objects_under(self, parent: QTreeWidgetItem, conn: DbConnection, schema: Optional[str]):
        try:
            obj = self.runtime.list_objects(conn, schema=schema)
        except Exception as e:
            QMessageBox.warning(self, "DB Explorer", f"List objects failed:\n{e}")
            return

        tables = obj.get("tables", []) or []
        views = obj.get("views", []) or []

        tables_folder = QTreeWidgetItem(["Tables"])
        tables_folder.setData(0, ROLE_KIND, "folder")
        tables_folder.setFlags(tables_folder.flags() & ~Qt.ItemIsSelectable)

        views_folder = QTreeWidgetItem(["Views"])
        views_folder.setData(0, ROLE_KIND, "folder")
        views_folder.setFlags(views_folder.flags() & ~Qt.ItemIsSelectable)

        parent.addChild(tables_folder)
        parent.addChild(views_folder)

        for t in tables:
            sch, name, full = self._split_fullname(str(t), default_schema=schema)
            it = QTreeWidgetItem([name])
            it.setData(0, ROLE_KIND, "table")
            it.setData(0, ROLE_SCHEMA, sch or "")
            it.setData(0, ROLE_NAME, name)
            it.setData(0, ROLE_FULL, full)
            tables_folder.addChild(it)

        for v in views:
            sch, name, full = self._split_fullname(str(v), default_schema=schema)
            it = QTreeWidgetItem([name])
            it.setData(0, ROLE_KIND, "view")
            it.setData(0, ROLE_SCHEMA, sch or "")
            it.setData(0, ROLE_NAME, name)
            it.setData(0, ROLE_FULL, full)
            views_folder.addChild(it)

        tables_folder.setExpanded(True)
        views_folder.setExpanded(False)

    def _get_conn(self, key: str) -> Optional[DbConnection]:
        return self.db.find(key) if key else None

    def _split_fullname(self, value: str, default_schema: Optional[str]) -> Tuple[str, str, str]:
        v = (value or "").strip()
        if v and "." in v:
            a, b = v.split(".", 1)
            schema = (a or "").strip() or (default_schema or "")
            name = (b or "").strip()
            full = f"{schema}.{name}" if schema else name
            return schema, name, full
        name = v
        schema = (default_schema or "")
        full = f"{schema}.{name}" if schema else name
        return schema, name, full

    # ------------------------
    # Selection + context menu
    # ------------------------

    def _on_context_menu(self, pos):
        item = self.tree.itemAt(pos)
        if item is None:
            return

        self.tree.setCurrentItem(item)
        kind = item.data(0, ROLE_KIND)
        if kind not in ("table", "view"):
            return
        if not self._connected_key:
            return

        schema = str(item.data(0, ROLE_SCHEMA) or "")
        name = str(item.data(0, ROLE_NAME) or "")
        full = str(item.data(0, ROLE_FULL) or "")

        menu = QMenu(self.tree)
        act_look = menu.addAction("Look table")

        chosen = menu.exec(self.tree.viewport().mapToGlobal(pos))
        if not chosen:
            return

        if chosen == act_look:
            # MainWindow otworzy TableInspectorDialog
            self.tableLookRequested.emit(self._connected_key, schema, name)
            return
