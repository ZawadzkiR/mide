from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QDockWidget, QWidget, QVBoxLayout, QToolButton, QStyle


class ActivityBarDock(QDockWidget):
    """Wąski pasek ikon jak w VS Code (Explorer / SQL)."""

    modeChanged = Signal(str)  # "code" | "sql"

    def __init__(self, parent=None):
        super().__init__("", parent)
        self.setAllowedAreas(Qt.LeftDockWidgetArea)
        self.setFeatures(QDockWidget.NoDockWidgetFeatures)
        self.setTitleBarWidget(QWidget())

        root = QWidget()
        lay = QVBoxLayout(root)
        lay.setContentsMargins(4, 6, 4, 6)
        lay.setSpacing(6)

        self.btn_explorer = QToolButton()
        self.btn_explorer.setToolTip("Explorer")
        self.btn_explorer.setCheckable(True)
        self.btn_explorer.setChecked(True)
        self.btn_explorer.setIcon(self.style().standardIcon(QStyle.SP_DirOpenIcon))
        self.btn_explorer.setIconSize(root.fontMetrics().size(0, "MMMM"))

        self.btn_sql = QToolButton()
        self.btn_sql.setToolTip("SQL")
        self.btn_sql.setCheckable(True)
        self.btn_sql.setIcon(self.style().standardIcon(QStyle.SP_DriveHDIcon))
        self.btn_sql.setIconSize(root.fontMetrics().size(0, "MMMM"))

        for b in (self.btn_explorer, self.btn_sql):
            b.setCursor(Qt.PointingHandCursor)
            b.setAutoRaise(True)
            b.setFixedSize(40, 40)

        lay.addWidget(self.btn_explorer)
        lay.addWidget(self.btn_sql)
        lay.addStretch(1)

        self.setWidget(root)
        self.setFixedWidth(54)

        self.btn_explorer.clicked.connect(self._set_code)
        self.btn_sql.clicked.connect(self._set_sql)

    def _set_code(self):
        self.btn_explorer.setChecked(True)
        self.btn_sql.setChecked(False)
        self.modeChanged.emit("code")

    def _set_sql(self):
        self.btn_explorer.setChecked(False)
        self.btn_sql.setChecked(True)
        self.modeChanged.emit("sql")
