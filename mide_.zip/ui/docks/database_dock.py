from __future__ import annotations

from typing import List

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QTreeWidget, QTreeWidgetItem,
    QPushButton, QTabWidget, QPlainTextEdit, QTableWidget, QTableWidgetItem,
    QMessageBox
)

from services.db_service import DbService, DbConnection


class DatabaseDock(QDockWidget):
    """Dock pod pracę z bazami.

    Ta iteracja: UI + zapis połączeń (w Settings). Bez realnego łączenia.
    Następna iteracja: connect + introspekcja (schemas/tables) + wykonanie query.
    """

    open_settings_requested = Signal()

    def __init__(self, db: DbService, parent=None):
        super().__init__("Database", parent)
        self._db = db

        root = QWidget()
        lay = QVBoxLayout(root)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(8)

        # top bar
        top = QHBoxLayout()
        self.btn_refresh = QPushButton("Refresh")
        self.btn_settings = QPushButton("Connections...")
        self.btn_refresh.setCursor(Qt.PointingHandCursor)
        self.btn_settings.setCursor(Qt.PointingHandCursor)
        self.btn_refresh.clicked.connect(self.refresh_connections)
        self.btn_settings.clicked.connect(self.open_settings_requested.emit)
        top.addWidget(self.btn_refresh)
        top.addWidget(self.btn_settings)
        top.addStretch(1)
        lay.addLayout(top)

        # connections tree
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Connections / Schemas / Tables"])
        self.tree.setStyleSheet(
            "QTreeWidget { background:#060914; color:#e6f1ff; border:1px solid #1b2a4a; border-radius:12px; }"
        )
        lay.addWidget(self.tree, 2)
        self.tree.itemClicked.connect(self._on_tree_clicked)

        # query editor + results
        self.query = QPlainTextEdit()
        self.query.setPlaceholderText("SELECT ...")
        self.query.setFont(QFont("Consolas", 11))
        self.query.setStyleSheet(
            "QPlainTextEdit { background:#060914; color:#e6f1ff; border:1px solid #1b2a4a; border-radius:12px; padding:10px; }"
        )
        lay.addWidget(self.query, 1)

        run_row = QHBoxLayout()
        self.btn_run = QPushButton("Run query")
        self.btn_run.setCursor(Qt.PointingHandCursor)
        self.btn_run.clicked.connect(self._run_query_placeholder)
        run_row.addStretch(1)
        run_row.addWidget(self.btn_run)
        lay.addLayout(run_row)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(
            "QTabWidget::pane { border:1px solid #1b2a4a; border-radius:12px; }"
            "QTabBar::tab { padding:6px 10px; }"
        )
        self.table = QTableWidget(0, 0)
        self.table.setStyleSheet(
            "QTableWidget { background:#060914; color:#e6f1ff; border:none; }"
        )
        self.tabs.addTab(self.table, "Results")
        lay.addWidget(self.tabs, 2)

        self.setWidget(root)
        self.refresh_connections()

    def refresh_connections(self):
        self.tree.clear()
        conns = self._db.load_connections()
        if not conns:
            it = QTreeWidgetItem(["No connections. Click 'Connections...' to add."])
            it.setFlags(it.flags() & ~Qt.ItemIsSelectable)
            self.tree.addTopLevelItem(it)
            return

        selected = self._db.get_selected_key()
        for c in conns:
            top = QTreeWidgetItem([f"{c.name}  ({c.kind})"])
            top.setData(0, Qt.UserRole, c.key)
            if selected and c.key == selected:
                top.setSelected(True)
            # placeholder children (schemas/tables w kolejnym kroku)
            ch = QTreeWidgetItem(["(connect to load schemas/tables)"])
            ch.setFlags(ch.flags() & ~Qt.ItemIsSelectable)
            top.addChild(ch)
            self.tree.addTopLevelItem(top)

        self.tree.expandAll()

    def _on_tree_clicked(self, item: QTreeWidgetItem, _col: int):
        key = item.data(0, Qt.UserRole)
        if isinstance(key, str) and key:
            self._db.set_selected_key(key)

    def _run_query_placeholder(self):
        key = self._db.get_selected_key()
        txt = (self.query.toPlainText() or "").strip()
        if not txt:
            return
        if not key:
            QMessageBox.information(self, "Database", "Wybierz połączenie (w Settings) – wykonanie query dodamy w kolejnym kroku.")
            return
        QMessageBox.information(self, "Database", "Wykonanie query + wyniki dodamy w kolejnym kroku.\n\nNa razie działa UI + zapis połączeń.")
