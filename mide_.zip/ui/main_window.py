import os
import re

from PySide6.QtCore import Qt, QSettings
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QMainWindow, QFileDialog, QToolBar, QMessageBox, QStatusBar, QLabel,
    QWidget, QVBoxLayout, QDialog, QStackedWidget
)

from ui.theme import FUTURE_QSS
from ui.docks.project_dock import ProjectDock
from ui.docks.jupyterhub_files_dock import JupyterHubFilesDock
from ui.docks.jupyterhub_terminal_dock import JupyterHubTerminalDock
from ui.docks.console_dock import ConsoleDock
from ui.docks.problems_dock import ProblemsDock
from ui.docks.references_dock import ReferencesDock
from ui.docks.activity_bar_dock import ActivityBarDock
from ui.docks.db_explorer_dock import DbExplorerDock

from ui.editors.editor_manager import EditorManager
from ui.editors.code_editor import CodeEditor
from ui.editors.notebook_editor import NotebookEditor

from utils.filetypes import detect_filetype, PY, R, IPYNB

from services.project_service import ProjectService
from services.kernel_service import KernelService
from services.runner_service import RunnerService
from services.settings_service import SettingsService
from services.python_diagnostics import diagnostics_from_syntax
from services.db_service import DbService

from ui.widgets.env_selector_bar import EnvironmentSelectorBar, EnvironmentItem
from ui.dialogs.settings_dialog import SettingsDialog
from ui.screens.sql_screen import SqlScreen


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("FutIDE")
        self.resize(1500, 900)
        self.setStyleSheet(FUTURE_QSS)

        self._qsettings = QSettings("FutIDE", "FutIDE")

        self.projects = ProjectService()
        self.kernels = KernelService()
        self.runner = RunnerService()
        self.settings = SettingsService()
        self.db = DbService()

        # mapowanie lokalnych plików-cache na ścieżki zdalne JupyterHub
        self._remote_path_by_local: dict[str, str] = {}
        self._jhub_env_key: str = ""

        # central: tryb kodu + tryb SQL
        self.editors = EditorManager(self.kernels)
        self.env_bar = EnvironmentSelectorBar(self)
        handler = getattr(self, '_on_env_changed', None)
        if handler:
            self.env_bar.environmentChanged.connect(handler)

        code_central = QWidget()
        code_lay = QVBoxLayout(code_central)
        code_lay.setContentsMargins(0, 0, 0, 0)
        code_lay.setSpacing(0)
        code_lay.addWidget(self.env_bar, 0)
        code_lay.addWidget(self.editors, 1)

        self.sql_screen = SqlScreen(self.db)
        self.sql_screen.connectionConnected.connect(self._on_sql_connected)
        self.sql_screen.connectionDisconnected.connect(self._on_sql_disconnected)
        self.sql_screen.connectionSelected.connect(self._on_sql_selected)

        self.central_stack = QStackedWidget()
        self.central_stack.addWidget(code_central)   # index 0
        self.central_stack.addWidget(self.sql_screen)  # index 1
        self.setCentralWidget(self.central_stack)

        self.editors.currentChanged.connect(self._on_editor_changed)

        # docks
        self.dock_activity = ActivityBarDock(self)
        self.dock_project = ProjectDock(self)
        self.dock_project.setMinimumWidth(260)
        self.dock_jhub_files = JupyterHubFilesDock(self)
        self.dock_jhub_files.setMinimumWidth(260)
        self.dock_jhub_terminal = JupyterHubTerminalDock(self)
        self.dock_db_explorer = DbExplorerDock(self.db, self)
        self.dock_db_explorer.setMinimumWidth(260)
        self.dock_console = ConsoleDock(self.kernels, self)
        self.dock_problems = ProblemsDock(self)
        self.dock_refs = ReferencesDock(self)
 
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_activity)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_project)

        # JupyterHub files tabbed with Project
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_jhub_files)
        self.tabifyDockWidget(self.dock_project, self.dock_jhub_files)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_jhub_terminal)

        # Place ActivityBar as a narrow strip and Project/DB explorer next to it (resizable)
        self.splitDockWidget(self.dock_activity, self.dock_project, Qt.Horizontal)

        # DB explorer shares the same space as Project (we toggle visibility by mode)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_db_explorer)
        self.tabifyDockWidget(self.dock_project, self.dock_db_explorer)
        self.tabifyDockWidget(self.dock_project, self.dock_jhub_files)

        # Give Project dock comfortable default width; ActivityBar stays narrow
        self.resizeDocks([self.dock_activity, self.dock_project], [54, 320], Qt.Horizontal)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_console)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_problems)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_refs)

        self.dock_db_explorer.setVisible(False)
        self.dock_jhub_files.setVisible(False)
        self.dock_jhub_terminal.setVisible(False)

        self.tabifyDockWidget(self.dock_console, self.dock_problems)
        self.tabifyDockWidget(self.dock_console, self.dock_refs)
        self.tabifyDockWidget(self.dock_console, self.dock_jhub_terminal)
        self.dock_console.raise_()

        self.setDockOptions(
            QMainWindow.AllowNestedDocks
            | QMainWindow.AllowTabbedDocks
            | QMainWindow.AnimatedDocks
            | QMainWindow.GroupedDragging
        )

        self.dock_project.file_open_requested.connect(self.editors.open_path)
        self.dock_jhub_files.file_open_requested.connect(self.editors.open_path)
        self.dock_jhub_files.remote_mapping_ready.connect(self._on_remote_mapping_ready)
        self.dock_refs.navigate_requested.connect(self._navigate_to)
        self.dock_problems.navigate_requested.connect(self._navigate_to)
        self.dock_activity.modeChanged.connect(self._set_mode)
        self.dock_db_explorer.connectRequested.connect(self._on_db_connect_requested)
        self.dock_db_explorer.disconnectRequested.connect(self._on_db_disconnect_requested)
        self.dock_db_explorer.refreshRequested.connect(self._on_db_refresh_requested)
        self.dock_db_explorer.tableLookRequested.connect(self._on_db_table_look_requested)
        self.dock_db_explorer.tableSelected.connect(self._on_db_table_selected)
        self.dock_db_explorer.tablePreviewRequested.connect(self._on_db_table_preview_requested)

        # menu, toolbar, status
        self._build_actions()
        self._build_menubar()
        self._build_toolbar()
        self._build_statusbar()

        self.load_layout(silent=True)
        self._enforce_core_ui()
        self._refresh_status()
        self._refresh_env_bar()

    def closeEvent(self, event):
        # niezapisane zmiany w zakładkach
        if not self.editors.maybe_close_all():
            event.ignore()
            return

        self.save_layout(silent=True)
        self.kernels.shutdown()
        super().closeEvent(event)

    
    def _enforce_core_ui(self):
        """Wymuś widoczność kluczowych elementów UI niezależnie od zapisanego układu (QSettings)."""
        try:
            # menubar
            if self.menuBar():
                self.menuBar().setVisible(True)
        except Exception:
            pass

        # toolbars (mogą być ukryte przez restoreState)
        for tb in self.findChildren(QToolBar):
            try:
                tb.setVisible(True)
            except Exception:
                pass

        # Activity bar + przełączniki trybu
        try:
            self.dock_activity.setVisible(True)
            self.dock_activity.setFeatures(self.dock_activity.features() & ~self.dock_activity.DockWidgetClosable)
        except Exception:
            pass

        # Nie pozwól, żeby oba: Project i DB explorer były ukryte naraz
        try:
            if not self.dock_project.isVisible() and not self.dock_db_explorer.isVisible():
                # domyślnie wróć do code mode
                self.dock_project.setVisible(True)
        except Exception:
            pass

        # Jeśli z jakiegoś powodu toolbar nie ma Settings, odbuduj chrome
        try:
            has_settings = any(a is self.act_settings for a in getattr(self, 'toolbar_main', []).actions()) if hasattr(self, 'toolbar_main') else False
            if not has_settings:
                # rebuild toolbar/menubar safely
                self._build_menubar()
                self._build_toolbar()
        except Exception:
            pass

# ---------- modes ----------

    def _set_mode(self, mode: str):
        mode = (mode or "code").lower()
        if mode == "sql":
            # central
            self.central_stack.setCurrentIndex(1)

            # left docks
            self.dock_project.setVisible(False)
            self.dock_db_explorer.setVisible(True)

            # hide python consoles in SQL mode
            self.dock_console.setVisible(False)
            self.dock_problems.setVisible(False)
            self.dock_refs.setVisible(False)

            # refresh
            self.sql_screen.reload_connections()
            self.dock_db_explorer.reload(self.db.get_selected_key())
        else:
            self.central_stack.setCurrentIndex(0)

            self.dock_project.setVisible(True)
            self.dock_db_explorer.setVisible(False)

            self.dock_console.setVisible(True)
            self.dock_problems.setVisible(True)
            self.dock_refs.setVisible(True)

        self._refresh_status()

    
    def _on_db_connect_requested(self, key: str):
        # Called when user clicks Connect in DB explorer
        if not key:
            return
        # switch to SQL mode so user sees connection + editor
        if self.central_stack.currentIndex() != 1:
            self._set_mode("sql")

        # select the same key in SQL screen combo (if present)
        try:
            idx = self.sql_screen.cmb.findData(key)
            if idx >= 0:
                self.sql_screen.cmb.setCurrentIndex(idx)
        except Exception:
            pass

        # connect (explicit)
        self.sql_screen.connect_current()

    def _on_db_disconnect_requested(self, key: str):
        if not key:
            return
        if self.sql_screen.is_connected() and self.sql_screen.current_connection_key() == key:
            self.sql_screen.disconnect_current()

    def _on_db_refresh_requested(self, key: str):
        if not key:
            return
        if self.sql_screen.is_connected() and self.sql_screen.current_connection_key() == key:
            self.sql_screen.reconnect_current()

    def _on_sql_selected(self, key: str):
        # keep dock selection state in sync
        try:
            self.dock_db_explorer.set_selected_key(key)
        except Exception:
            pass

    def _on_sql_connected(self, key: str):
        try:
            self.dock_db_explorer.set_connected_key(key)
        except Exception:
            pass

    def _on_sql_disconnected(self, key: str):
        try:
            self.dock_db_explorer.set_connected_key("")
        except Exception:
            pass

    def _on_db_table_selected(self, conn_key: str, schema: str, table: str):
        # Show quick preview when user clicks a table
        if self.central_stack.currentIndex() != 1:
            self._set_mode("sql")
        self.sql_screen.preview_table(conn_key, schema, table, limit=200)

    def _on_db_table_preview_requested(self, conn_key: str, obj_type: str, full_name: str, limit: int):
        if self.central_stack.currentIndex() != 1:
            self._set_mode("sql")
        self.sql_screen.run_table_top(conn_key, full_name, limit)

    def _on_db_table_look_requested(self, conn_key: str, schema: str, table: str):
        if not self.sql_screen.is_connected() or self.sql_screen.current_connection_key() != conn_key:
            return
        from ui.dialogs.table_inspector_dialog import TableInspectorDialog
        conn = self.db.find(conn_key)
        if not conn:
            return
        dlg = TableInspectorDialog(self.sql_screen.runtime, conn, schema, table, parent=self)
        dlg.exec()


# ---------- UI building ----------

    def _build_actions(self):
        # File
        self.act_open_project = QAction("Otwórz projekt...", self)
        self.act_open_file = QAction("Otwórz plik...", self)
        self.act_save = QAction("Zapisz", self)
        self.act_save_as = QAction("Zapisz jako...", self)
        self.act_save_all = QAction("Zapisz wszystko", self)
        self.act_settings = QAction("Ustawienia...", self)
        self.act_save_layout = QAction("Zapisz układ", self)
        self.act_load_layout = QAction("Wczytaj układ", self)
        self.act_reset_layout = QAction("Reset układu", self)
        self.act_exit = QAction("Zamknij", self)

        self.act_open_file.setShortcut(QKeySequence.Open)
        self.act_exit.setShortcut(QKeySequence.Quit)
        self.act_save.setShortcut(QKeySequence.Save)
        self.act_save_as.setShortcut(QKeySequence("Ctrl+Shift+S"))
        self.act_save_all.setShortcut(QKeySequence("Ctrl+Alt+Shift+S"))
        self.act_save_layout.setShortcut(QKeySequence("Ctrl+Alt+S"))
        self.act_load_layout.setShortcut(QKeySequence("Ctrl+Alt+L"))

        self.act_open_project.triggered.connect(self.open_project)
        self.act_open_file.triggered.connect(self.open_file_dialog)
        self.act_save.triggered.connect(self.save_current)
        self.act_save_as.triggered.connect(self.save_current_as)
        self.act_save_all.triggered.connect(self.save_all)
        self.act_settings.triggered.connect(self.open_settings)
        self.act_save_layout.triggered.connect(lambda: self.save_layout(silent=False))
        self.act_load_layout.triggered.connect(lambda: self.load_layout(silent=False))
        self.act_reset_layout.triggered.connect(self.reset_layout)
        self.act_exit.triggered.connect(self.close)

        # Run
        self.act_run_selection = QAction("Run selection", self)
        self.act_run_file = QAction("Run file", self)
        self.act_run_selection.setShortcut(QKeySequence("Shift+Return"))
        self.act_run_file.setShortcut(QKeySequence("Ctrl+Return"))
        self.act_run_selection.triggered.connect(self.run_selection)
        self.act_run_file.triggered.connect(self.run_file)

        # Navigate
        self.act_goto_def = QAction("Go to Definition", self)
        self.act_find_refs = QAction("Find References", self)
        self.act_goto_def.setShortcut(QKeySequence("F12"))
        self.act_find_refs.setShortcut(QKeySequence("Shift+F12"))
        self.act_goto_def.triggered.connect(self.go_to_definition)
        self.act_find_refs.triggered.connect(self.find_references)

        # View: toggle docks
        self.act_toggle_project = QAction("Project", self, checkable=True)
        self.act_toggle_console = QAction("Console", self, checkable=True)
        self.act_toggle_problems = QAction("Problems", self, checkable=True)
        self.act_toggle_refs = QAction("References", self, checkable=True)
        self.act_toggle_db = QAction("Database", self, checkable=True)

        self.act_toggle_project.setChecked(True)
        self.act_toggle_console.setChecked(True)
        self.act_toggle_problems.setChecked(True)
        self.act_toggle_refs.setChecked(True)
        self.act_toggle_db.setChecked(True)

        self.act_toggle_project.triggered.connect(lambda: self.dock_project.setVisible(self.act_toggle_project.isChecked()))
        self.act_toggle_console.triggered.connect(lambda: self.dock_console.setVisible(self.act_toggle_console.isChecked()))
        self.act_toggle_problems.triggered.connect(lambda: self.dock_problems.setVisible(self.act_toggle_problems.isChecked()))
        self.act_toggle_refs.triggered.connect(lambda: self.dock_refs.setVisible(self.act_toggle_refs.isChecked()))
        self.act_toggle_db.triggered.connect(lambda: self.dock_db.setVisible(self.act_toggle_db.isChecked()))

        # Help
        self.act_about = QAction("O programie", self)
        self.act_about.triggered.connect(self.about)

    def _build_menubar(self):
        mb = self.menuBar()

        m_file = mb.addMenu("File")
        m_file.addAction(self.act_open_project)
        m_file.addAction(self.act_open_file)
        m_file.addAction(self.act_save)
        m_file.addAction(self.act_save_as)
        m_file.addAction(self.act_save_all)
        m_file.addSeparator()
        m_file.addAction(self.act_settings)
        m_file.addSeparator()
        m_file.addAction(self.act_save_layout)
        m_file.addAction(self.act_load_layout)
        m_file.addAction(self.act_reset_layout)
        m_file.addSeparator()
        m_file.addAction(self.act_exit)

        m_edit = mb.addMenu("Edit")
        # placeholder pod przyszłe: undo/redo/cut/copy/paste/find/replace
        # (Qt ma standardowe akcje, dołożymy w kolejnym kroku)

        m_view = mb.addMenu("View")
        m_view.addAction(self.act_toggle_project)
        m_view.addAction(self.act_toggle_console)
        m_view.addAction(self.act_toggle_problems)
        m_view.addAction(self.act_toggle_refs)
        m_view.addAction(self.act_toggle_db)
        m_view.addSeparator()
        m_view.addAction(self.act_reset_layout)

        m_run = mb.addMenu("Run")
        m_run.addAction(self.act_run_selection)
        m_run.addAction(self.act_run_file)

        m_nav = mb.addMenu("Navigate")
        m_nav.addAction(self.act_goto_def)
        m_nav.addAction(self.act_find_refs)

        m_help = mb.addMenu("Help")
        m_help.addAction(self.act_about)

    def _build_toolbar(self):
        # rebuild main toolbar (może zostać ukryty przez restoreState)
        if hasattr(self, 'toolbar_main') and self.toolbar_main is not None:
            try:
                self.removeToolBar(self.toolbar_main)
            except Exception:
                pass
        tb = QToolBar("Main")
        tb.setObjectName('main_toolbar')
        tb.setMovable(False)
        self.addToolBar(tb)
        self.toolbar_main = tb

        tb.addAction(self.act_open_project)
        tb.addAction(self.act_open_file)
        tb.addAction(self.act_save)
        tb.addAction(self.act_save_as)
        tb.addSeparator()
        tb.addAction(self.act_run_selection)
        tb.addAction(self.act_run_file)
        tb.addSeparator()
        tb.addAction(self.act_goto_def)
        tb.addAction(self.act_find_refs)
        tb.addSeparator()
        tb.addAction(self.act_save_layout)
        tb.addAction(self.act_settings)

    def _build_statusbar(self):
        sb = QStatusBar(self)
        self.setStatusBar(sb)

        self.status_path = QLabel("")
        self.status_pos = QLabel("")
        self.status_kernel = QLabel("Kernel: Python (in-process)")

        self.status_path.setStyleSheet("color: #b7c7dd; padding: 0 8px;")
        self.status_pos.setStyleSheet("color: #b7c7dd; padding: 0 8px;")
        self.status_kernel.setStyleSheet("color: #b7c7dd; padding: 0 8px;")

        sb.addWidget(self.status_path, 1)
        sb.addPermanentWidget(self.status_pos)
        sb.addPermanentWidget(self.status_kernel)

    # ---------- layout persistence ----------

    def save_layout(self, silent: bool = False):
        self._qsettings.setValue("window/geometry", self.saveGeometry())
        self._qsettings.setValue("window/state", self.saveState())
        if not silent:
            QMessageBox.information(self, "Układ", "Układ zapisany.")

    def load_layout(self, silent: bool = False):
        geom = self._qsettings.value("window/geometry", None)
        state = self._qsettings.value("window/state", None)
        if geom is None or state is None:
            self._enforce_core_ui()
            if not silent:
                QMessageBox.information(self, "Układ", "Brak zapisanego układu.")
            return
        try:
            self.restoreGeometry(geom)
            self.restoreState(state)
            self._enforce_core_ui()
            if not silent:
                QMessageBox.information(self, "Układ", "Układ wczytany.")
        except Exception:
            if not silent:
                QMessageBox.warning(self, "Układ", "Nie udało się wczytać układu.")

    def reset_layout(self):
        # usuń zapisany układ (QSettings), bo może ukrywać toolbary/docki
        try:
            self._qsettings.remove('window/state')
            self._qsettings.remove('window/geometry')
            self._qsettings.sync()
        except Exception:
            pass
        # klasyczny układ: activity bar + project left, bottom console/prob/refs
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_activity)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_project)

        # Place ActivityBar as a narrow strip and Project/DB explorer next to it (resizable)
        self.splitDockWidget(self.dock_activity, self.dock_project, Qt.Horizontal)

        # DB explorer shares the same space as Project (we toggle visibility by mode)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_db_explorer)
        self.tabifyDockWidget(self.dock_project, self.dock_db_explorer)

        # Give Project dock comfortable default width; ActivityBar stays narrow
        self.resizeDocks([self.dock_activity, self.dock_project], [54, 320], Qt.Horizontal)
        self.dock_db_explorer.setVisible(False)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_console)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_problems)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_refs)

        self.tabifyDockWidget(self.dock_console, self.dock_problems)
        self.tabifyDockWidget(self.dock_console, self.dock_refs)
        self.tabifyDockWidget(self.dock_console, self.dock_jhub_terminal)
        self.dock_console.raise_()

    # ---------- project / files ----------

        self._enforce_core_ui()

    def open_project(self):
        root = QFileDialog.getExistingDirectory(self, "Wybierz katalog projektu")
        if not root:
            return
        p = self.projects.open_project(root)
        self.setWindowTitle(f"FutIDE — {os.path.basename(p.root)}")
        self.dock_project.set_root(p.root)
        self._refresh_status()

    def open_file_dialog(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Otwórz",
            "",
            "Wszystkie (*.py *.ipynb *.r *.txt *.md);;Python (*.py);;Notebook (*.ipynb);;R (*.r);;Wszystkie (*.*)"
        )
        if path:
            self.editors.open_path(path)
            self._refresh_problems_for_current()
            self._refresh_status()

    # ---------- run ----------

    def save_current(self):
        # Save aktywnego edytora
        if not self.editors.save_current():
            return
        self._sync_remote_if_needed(self.editors.current_path() or "")
        self._refresh_status()

    def save_current_as(self):
        if not self.editors.save_current_as():
            return
        self._sync_remote_if_needed(self.editors.current_path() or "")
        self._refresh_status()

    def save_all(self):
        if not self.editors.save_all():
            return
        # best-effort: synchronizuj wszystkie pliki-cache
        for lp in list(self._remote_path_by_local.keys()):
            self._sync_remote_if_needed(lp)
        self._refresh_status()

    def run_selection(self):
        self._refresh_problems_for_current()
        self._refresh_status()

        w = self.editors.current_widget()
        if not isinstance(w, CodeEditor):
            if isinstance(w, NotebookEditor):
                QMessageBox.information(self, "Notebook", "Uruchamianie jest per-komórka (Run przy komórce).")
            return

        code = w.get_selected_or_line()
        if not code.strip():
            return

        ftype = self._current_ftype()
        env = self.env_bar.current_item()

        if ftype == R:
            r_path = (env.path if env and env.kind == "r" else "Rscript")
            r_name = (env.name if env and env.kind == "r" else "R (Rscript)")
            self.dock_console.clear_run_output()
            self.dock_console.append_text(f"[R] {r_name}\n")
            self.runner.run_r_code(
                r_path,
                code,
                on_text=self.dock_console.append_text,
                on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}")
            )
            return

        # default: Python
        if not env or env.kind == "python-kernel" or env.key == "python:kernel":
            self.dock_console.execute(code)
            return

        self.dock_console.clear_run_output()
        if getattr(env, "kind", "") == "jupyterhub":
            cfg = self.settings.find_env(env.key) or {}
            self.dock_console.append_text(f"[JupyterHub] {env.name}\n")
            self.runner.run_jupyterhub_code(
                hub_url=str(cfg.get("hub_url") or ""),
                user=str(cfg.get("hub_user") or ""),
                token=str(cfg.get("hub_token") or ""),
                kernel_name=str(cfg.get("hub_kernel") or ""),
                code=code,
                on_text=self.dock_console.append_text,
                on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}"),
            )
        else:
            self.dock_console.append_text(f"[Python] {env.name}\n")
            self.runner.run_python_code(
                env.path,
                code,
                on_text=self.dock_console.append_text,
                on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}"),
                extra_pythonpath=(env.libs_path if getattr(env, 'kind', '') == 'python-pseudo' else None),
            )

    def run_file(self):
        self._refresh_problems_for_current()
        self._refresh_status()

        ftype = self._current_ftype()
        w = self.editors.current_widget()

        # jeśli brak ścieżki (nowy/niezapisany) – uruchom z kodu
        path = self.editors.current_path()
        if not path and isinstance(w, CodeEditor):
            code = w.toPlainText()
            if not code.strip():
                return
            env = self.env_bar.current_item()

            if ftype == R:
                r_path = (env.path if env and env.kind == "r" else "Rscript")
                r_name = (env.name if env and env.kind == "r" else "R (Rscript)")
                self.dock_console.clear_run_output()
                self.dock_console.append_text(f"[R] {r_name}\n")
                self.runner.run_r_code(
                    r_path,
                    code,
                    on_text=self.dock_console.append_text,
                    on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}")
                )
                return

            # Python (external or kernel)
            if not env or env.kind == "python-kernel" or env.key == "python:kernel":
                self.dock_console.execute(code)
                return

            self.dock_console.clear_run_output()
            if getattr(env, "kind", "") == "jupyterhub":
                cfg = self.settings.find_env(env.key) or {}
                self.dock_console.append_text(f"[JupyterHub] {env.name}\n")
                self.runner.run_jupyterhub_code(
                    hub_url=str(cfg.get("hub_url") or ""),
                    user=str(cfg.get("hub_user") or ""),
                    token=str(cfg.get("hub_token") or ""),
                    kernel_name=str(cfg.get("hub_kernel") or ""),
                    code=code,
                    on_text=self.dock_console.append_text,
                    on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}"),
                )
            else:
                self.dock_console.append_text(f"[Python] {env.name}\n")
                self.runner.run_python_code(
                    env.path,
                    code,
                    on_text=self.dock_console.append_text,
                    on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}"),
                    extra_pythonpath=(env.libs_path if getattr(env, 'kind', '') == 'python-pseudo' else None),
                )
            return

        if not path:
            return

        if ftype == PY:
            if isinstance(w, CodeEditor):
                code = w.toPlainText()
                if not code.strip():
                    return
                env = self.env_bar.current_item()
                if not env or env.kind == "python-kernel" or env.key == "python:kernel":
                    self.dock_console.execute(code)
                    return

                self.dock_console.clear_run_output()
                if getattr(env, "kind", "") == "jupyterhub":
                    # zdalnie i tak wyślemy treść (dla spójności z run_selection)
                    cfg = self.settings.find_env(env.key) or {}
                    self.dock_console.append_text(f"[JupyterHub] {env.name}\n")
                    self.runner.run_jupyterhub_code(
                        hub_url=str(cfg.get("hub_url") or ""),
                        user=str(cfg.get("hub_user") or ""),
                        token=str(cfg.get("hub_token") or ""),
                        kernel_name=str(cfg.get("hub_kernel") or ""),
                        code=code,
                        on_text=self.dock_console.append_text,
                        on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}"),
                    )
                else:
                    self.dock_console.append_text(f"[Python] {env.name}\n")
                    # uruchom plik, jeśli jest zapisany
                    self.runner.run_python_file(
                        env.path,
                        path,
                        on_text=self.dock_console.append_text,
                        on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}"),
                        extra_pythonpath=(env.libs_path if getattr(env, 'kind', '') == 'python-pseudo' else None),
                    )
            return

        if ftype == R:
            env = self.env_bar.current_item()
            r_path = (env.path if env and env.kind == "r" else "Rscript")
            r_name = (env.name if env and env.kind == "r" else "R (Rscript)")

            self.dock_console.clear_run_output()
            self.dock_console.append_text(f"[R] {r_name}\n")
            self.runner.run_r_file(
                r_path,
                path,
                on_text=self.dock_console.append_text,
                on_finished=lambda rc: self.dock_console.append_text(f"\n[exit code] {rc}")
            )
            return

        if ftype == IPYNB:
            QMessageBox.information(self, "Notebook", "Notebook mode aktywny. Uruchamiaj komórki przyciskiem Run.")
            return

    def _on_editor_changed(self, _):
        self._refresh_problems_for_current()
        self._refresh_status()
        self._refresh_env_bar()
        self._wire_cursor_tracking()

    def _wire_cursor_tracking(self):
        w = self.editors.current_widget()
        try:
            if isinstance(w, CodeEditor):
                # aktualizuj pozycję kursora na bieżąco
                w.cursorPositionChanged.connect(self._refresh_status_pos)
        except Exception:
            pass

    def _refresh_problems_for_current(self):
        w = self.editors.current_widget()
        path = self.editors.current_path() or ""

        if isinstance(w, CodeEditor):
            code = w.toPlainText()
            diags = diagnostics_from_syntax(code)
            items = [(path, d.line, f"{d.severity.upper()}: {d.message}") for d in diags]
            self.dock_problems.set_items(items)
            return

        self.dock_problems.set_items([])

    # ---------- status bar ----------

    def _refresh_status(self):
        path = self.editors.current_path() or ""
        self.status_path.setText(path if path else "Brak pliku")
        self._refresh_status_pos()

        ftype = self._current_ftype()
        env = self.env_bar.current_item()
        if ftype in (PY, IPYNB) or not ftype:
            if env:
                self.status_kernel.setText(f"Python: {env.name}")
            else:
                self.status_kernel.setText("Python: Python (Kernel)")
        elif ftype == R:
            if env:
                self.status_kernel.setText(f"R: {env.name}")
            else:
                self.status_kernel.setText("R: Rscript")
        else:
            self.status_kernel.setText("")

    def _refresh_status_pos(self):
        w = self.editors.current_widget()
        if isinstance(w, CodeEditor):
            tc = w.textCursor()
            pos = tc.position()
            txt = w.toPlainText()
            before = txt[:pos]
            line = before.count("\n") + 1
            col = len(before.split("\n")[-1]) + 1
            self.status_pos.setText(f"Ln {line}, Col {col}")
        else:
            self.status_pos.setText("")

    # ---------- environments ----------

    
    def _current_ftype(self):
        """Zwraca typ pliku dla aktywnej zakładki.

        Jeśli edytor nie ma jeszcze ścieżki (nowy/niezapisany plik),
        próbujemy wywnioskować typ po nazwie taba (bez '*').
        """
        path = self.editors.current_path()
        if path:
            return detect_filetype(path)
        # fallback: tab text (np. 'test.r*')
        try:
            idx = self.editors.currentIndex()
            if idx >= 0:
                title = self.editors.tabText(idx).strip()
                title = title.replace("*", "").strip()
                if title:
                    return detect_filetype(title)
        except Exception:
            pass
        return None

    def _refresh_env_bar(self):
        """Odśwież zawartość comboboxa w zależności od aktywnego pliku."""
        ftype = self._current_ftype()

        envs = self.settings.load_environments()
        items: list[EnvironmentItem] = []

        if ftype in (PY, IPYNB) or not ftype:
            # Python: kernel + zewnętrzne python
            for e in envs:
                kind = (e or {}).get("kind")
                if kind in ("python-kernel", "python", "python-pseudo", "jupyterhub"):
                    items.append(EnvironmentItem(
                        key=str(e.get("key")),
                        kind=str(kind),
                        name=str(e.get("name")),
                        path=str(e.get("path")),
                        libs_path=str((e.get("libs_path") or e.get("libs") or "")),
                        hub_url=str(e.get("hub_url") or ""),
                        hub_user=str(e.get("hub_user") or ""),
                    ))
            selected = self.settings.get_selected_python_env_key()
        elif ftype == R:
            for e in envs:
                kind = (e or {}).get("kind")
                if kind == "r":
                    items.append(EnvironmentItem(
                        key=str(e.get("key")),
                        kind="r",
                        name=str(e.get("name")),
                        path=str(e.get("path")),
                    ))
            selected = self.settings.get_selected_r_env_key()
        else:
            # domyślnie python kernel
            items = [EnvironmentItem("python:kernel", "python-kernel", "Python (Kernel)", "")]
            selected = "python:kernel"

        # jeśli brak R envów, pokaż hint (bez blokowania UI)
        if ftype == R and not items:
            items = [EnvironmentItem("r:Rscript", "r", "R (Rscript w PATH)", "Rscript")]
            selected = "r:Rscript"

        self.env_bar.set_items(items, selected_key=selected)
        # jeśli aktualne środowisko to JupyterHub, uaktualnij dock
        self._update_jhub_files_dock()
        self._update_jhub_terminal_dock()

    def _on_env_changed(self, key: str):
        """Zapisz wybór środowiska (per-typ)."""
        ftype = self._current_ftype()
        item = self.env_bar.current_item()
        if not item:
            return

        if ftype in (PY, IPYNB) or not ftype:
            self.settings.set_selected_python_env_key(key)
        elif ftype == R:
            self.settings.set_selected_r_env_key(key)

        # aktualizuj dock z plikami JupyterHub
        self._update_jhub_files_dock()
        self._update_jhub_terminal_dock()

    def _update_jhub_files_dock(self):
        item = self.env_bar.current_item()
        if not item or getattr(item, "kind", "") != "jupyterhub":
            self.dock_jhub_files.setVisible(False)
            self._jhub_env_key = ""
            return

        cfg = self.settings.find_env(item.key) or {}
        self._jhub_env_key = item.key
        self.dock_jhub_files.set_env(
            hub_url=str(cfg.get("hub_url") or ""),
            hub_user=str(cfg.get("hub_user") or ""),
            hub_token=str(cfg.get("hub_token") or ""),
        )
        self.dock_jhub_files.setVisible(True)
        # nie wymuszaj refresh przy każdym przełączeniu pliku, ale odśwież przy pierwszym pokazaniu
        if self.dock_jhub_files.isVisible():
            self.dock_jhub_files.refresh()

    def _update_jhub_terminal_dock(self):
        item = self.env_bar.current_item()
        if not item or getattr(item, "kind", "") != "jupyterhub":
            self.dock_jhub_terminal.setVisible(False)
            return

        cfg = self.settings.find_env(item.key) or {}
        self.dock_jhub_terminal.set_env(
            hub_url=str(cfg.get("hub_url") or ""),
            hub_user=str(cfg.get("hub_user") or ""),
            hub_token=str(cfg.get("hub_token") or ""),
            hub_kernel=str(cfg.get("hub_kernel") or ""),
        )
        self.dock_jhub_terminal.setVisible(True)

    def _on_remote_mapping_ready(self, local_path: str, remote_path: str):
        if local_path and remote_path:
            self._remote_path_by_local[os.path.abspath(local_path)] = str(remote_path)

    def _sync_remote_if_needed(self, local_path: str):
        try:
            lp = os.path.abspath(local_path or "")
        except Exception:
            return
        remote_path = self._remote_path_by_local.get(lp)
        if not remote_path:
            return
        item = self.env_bar.current_item()
        if not item or getattr(item, "kind", "") != "jupyterhub":
            return
        cfg = self.settings.find_env(item.key) or {}
        try:
            from services.jupyterhub_client import JupyterHubClient, JupyterHubEnv
            client = JupyterHubClient(JupyterHubEnv(
                hub_url=str(cfg.get("hub_url") or ""),
                user=str(cfg.get("hub_user") or ""),
                token=str(cfg.get("hub_token") or ""),
            ))
            client.start_user_server()
            with open(lp, "r", encoding="utf-8") as f:
                text = f.read()
            client.contents_put_text(remote_path, text)
            self.dock_console.append_text(f"\n[JupyterHub] synced: {remote_path}\n")
        except Exception as e:
            self.dock_console.append_text(f"\n[JupyterHub] sync failed: {e}\n")

    def open_settings(self):
        dlg = SettingsDialog(self.settings, self.db, self)
        if dlg.exec() == QDialog.Accepted:
            # po zapisaniu ustawień odśwież listę
            self._refresh_env_bar()
            self.dock_db.refresh_connections()

    # ---------- navigation ----------

    def _navigate_to(self, path: str, line: int, col: int):
        if not path:
            return
        self.editors.open_path(path)
        ew = self.editors.current_widget()
        if isinstance(ew, CodeEditor):
            tc = ew.textCursor()
            block = ew.document().findBlockByNumber(max(0, line - 1))
            tc.setPosition(block.position() + max(0, col))
            ew.setTextCursor(tc)
            ew.setFocus()
        self._refresh_status()

    def go_to_definition(self):
        w = self.editors.current_widget()
        if not isinstance(w, CodeEditor):
            return

        res = w.go_to_definition()
        if not res:
            return

        mpath, line, col = res
        if not mpath:
            return

        self._navigate_to(str(mpath), int(line), int(col))

    def find_references(self):
        w = self.editors.current_widget()
        if not isinstance(w, CodeEditor):
            return

        refs = w.find_references()
        self.dock_refs.set_results(refs)
        self.dock_refs.raise_()

    # ---------- help ----------

    def about(self):
        QMessageBox.information(
            self,
            "FutIDE",
            "FutIDE – prototyp IDE.\n\n"
            "Aktualnie: edytor (highlight + jedi), console, project tree, problems, references.\n"
            "Następne kroki: Git, LSP, debug, notebook runtime i renderery."
        )
