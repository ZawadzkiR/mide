from __future__ import annotations

import os
import json
import uuid
from typing import Dict, List, Optional, Tuple

from PySide6.QtCore import Qt, QProcess
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget, QTableWidget,
    QTableWidgetItem, QPushButton, QMessageBox, QFileDialog, QComboBox, QLineEdit,
    QFormLayout, QDialogButtonBox, QAbstractItemView, QLabel, QPlainTextEdit
)

from services.settings_service import SettingsService
from services.db_service import DbService, DbConnection
from services.db_runtime import DbRuntime


class _DbEditDialog(QDialog):
    """Dialog dodawania/edycji połączenia do bazy."""

    def __init__(self, parent=None, initial: Optional[Dict] = None):
        super().__init__(parent)
        self.setWindowTitle("Database connection")
        self.resize(620, 260)

        initial = dict(initial or {})

        self.ed_name = QLineEdit(str(initial.get("name", "") or ""))

        self.cb_kind = QComboBox()
        self.cb_kind.addItem("SQLite", "sqlite")
        self.cb_kind.addItem("ODBC", "odbc")
        self.cb_kind.addItem("Oracle (oracledb)", "oracle")
        self.cb_kind.addItem("Snowflake (snowflake-connector)", "snowflake")
        self.cb_kind.addItem("JDBC (jaydebeapi)", "jaydebeapi")
        self.cb_kind.addItem("MS SQL Server", "mssql")
        self.cb_kind.addItem("Sybase", "sybase")
        self.cb_kind.addItem("Hadoop", "hadoop")

        init_kind = initial.get("kind", "odbc")
        for i in range(self.cb_kind.count()):
            if self.cb_kind.itemData(i) == init_kind:
                self.cb_kind.setCurrentIndex(i)
                break

        self.ed_dsn = QLineEdit(str(initial.get("dsn", "") or ""))
        self.btn_browse_db = QPushButton("Browse")
        self.btn_browse_db.clicked.connect(self._browse_sqlite)
        self.ed_user = QLineEdit(str(initial.get("user", "") or ""))
        self.ed_pass = QLineEdit(str(initial.get("password", "") or ""))
        self.ed_pass.setEchoMode(QLineEdit.Password)
        self.ed_extra = QLineEdit(str(initial.get("extra_json", "") or ""))

        form = QFormLayout()
        form.addRow("Name", self.ed_name)
        form.addRow("Type", self.cb_kind)

        dsn_row = QHBoxLayout()
        dsn_row.addWidget(self.ed_dsn, 1)
        dsn_row.addWidget(self.btn_browse_db)
        form.addRow("DSN / Connection string", dsn_row)
        form.addRow("User", self.ed_user)
        form.addRow("Password", self.ed_pass)
        form.addRow("Extra (JSON)", self.ed_extra)

        self._runtime = DbRuntime()

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.btn_test = QPushButton("Test connection")
        buttons.addButton(self.btn_test, QDialogButtonBox.ActionRole)
        self.btn_test.clicked.connect(self._test_connection)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        root = QVBoxLayout(self)
        root.addLayout(form)
        root.addStretch(1)
        root.addWidget(buttons)

        self.cb_kind.currentIndexChanged.connect(self._apply_kind_ui)
        self._apply_kind_ui()

    def _test_connection(self):
        v = self.get_value()
        # key isn't important for testing
        conn = DbConnection(
            key=f"{v.get('kind','')}:{v.get('dsn','')}",
            name=v.get("name") or "",
            kind=v.get("kind") or "",
            dsn=v.get("dsn") or "",
            user=v.get("user") or "",
            password=v.get("password") or "",
            extra_json=v.get("extra_json") or "",
        )
        ok, msg = self._runtime.test_connection(conn)
        if ok:
            QMessageBox.information(self, "Test connection", msg)
        else:
            QMessageBox.warning(self, "Test connection", msg)

    def _apply_kind_ui(self):
        kind = str(self.cb_kind.currentData() or "").lower()
        is_sqlite = kind in ("sqlite", "sqlite3")
        self.btn_browse_db.setVisible(is_sqlite)
        # SQLite nie używa user/pass
        self.ed_user.setEnabled(not is_sqlite)
        self.ed_pass.setEnabled(not is_sqlite)

    def _browse_sqlite(self):
        kind = str(self.cb_kind.currentData() or "").lower()
        if kind not in ("sqlite", "sqlite3"):
            return
        p, _ = QFileDialog.getOpenFileName(
            self,
            "Select SQLite database",
            "",
            "SQLite DB (*.db *.sqlite *.sqlite3);;All files (*.*)"
        )
        if p:
            self.ed_dsn.setText(p)

    def get_value(self) -> Dict:
        return {
            "name": (self.ed_name.text() or "").strip(),
            "kind": str(self.cb_kind.currentData() or "").strip(),
            "dsn": (self.ed_dsn.text() or "").strip(),
            "user": (self.ed_user.text() or "").strip(),
            "password": (self.ed_pass.text() or "").strip(),
            "extra_json": (self.ed_extra.text() or "").strip(),
        }


class _EnvEditDialog(QDialog):
    """Dialog dodawania/edycji środowiska uruchomieniowego."""

    def __init__(self, parent=None, initial: Optional[Dict] = None):
        super().__init__(parent)
        self.setWindowTitle("Environment")
        self.resize(620, 240)

        initial = dict(initial or {})

        self.ed_name = QLineEdit(str(initial.get("name") or ""))

        self.cb_kind = QComboBox()
        self.cb_kind.addItem("Python", "python")
        self.cb_kind.addItem("Python (Pseudo-Venv)", "python-pseudo")
        self.cb_kind.addItem("JupyterHub (Remote)", "jupyterhub")
        self.cb_kind.addItem("R (Rscript)", "r")

        init_kind = str(initial.get("kind") or "python")
        idx = self.cb_kind.findData(init_kind)
        self.cb_kind.setCurrentIndex(idx if idx >= 0 else 0)
        self.cb_kind.currentIndexChanged.connect(self._kind_changed)

        # interpreter path (python/r/pseudo)
        self.ed_path = QLineEdit(str(initial.get("path") or ""))
        self.btn_browse = QPushButton("Browse")
        self.btn_browse.clicked.connect(self._browse_interpreter)

        # libs path (pseudo-venv)
        self.ed_libs = QLineEdit(str(initial.get("libs") or ""))
        # jupyterhub fields
        self.ed_hub_url = QLineEdit(str(initial.get("hub_url") or ""))
        self.ed_hub_user = QLineEdit(str(initial.get("hub_user") or ""))
        self.ed_hub_token = QLineEdit(str(initial.get("hub_token") or ""))
        self.ed_hub_token.setEchoMode(QLineEdit.Password)
        self.ed_hub_kernel = QLineEdit(str(initial.get("hub_kernel") or "python3"))

        self.btn_browse_libs = QPushButton("Browse")
        self.btn_browse_libs.clicked.connect(self._browse_libs_dir)

        form = QFormLayout()
        form.addRow("Name", self.ed_name)
        form.addRow("Type", self.cb_kind)

        row = QHBoxLayout()
        row.addWidget(self.ed_path, 1)
        row.addWidget(self.btn_browse)
        form.addRow("Interpreter", row)

        row2 = QHBoxLayout()
        row2.addWidget(self.ed_libs, 1)
        row2.addWidget(self.btn_browse_libs)
        self._row_libs_widget = QWidget()
        self._row_libs_widget.setLayout(row2)
        form.addRow("Libraries folder", self._row_libs_widget)

        # jupyterhub rows
        self._row_hub_url = self.ed_hub_url
        self._row_hub_user = self.ed_hub_user
        self._row_hub_token = self.ed_hub_token
        form.addRow("JupyterHub URL", self._row_hub_url)
        form.addRow("Hub user", self._row_hub_user)
        form.addRow("API token", self._row_hub_token)
        form.addRow("Kernel (kernelspec)", self.ed_hub_kernel)

        hint = QLabel(
            "Pseudo-Venv: instalacja pakietów trafia do wskazanego folderu bibliotek (pip --target).\n"
            "JupyterHub: kod wykonywany jest zdalnie przez REST + WebSocket (kernel channels)."
        )
        hint.setStyleSheet("color:#a9b6c7;")
        hint.setWordWrap(True)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        root = QVBoxLayout(self)
        root.addLayout(form)
        root.addWidget(hint)
        root.addStretch(1)
        root.addWidget(buttons)

        self._kind_changed()

    def _kind_changed(self):
        kind = str(self.cb_kind.currentData() or "")
        is_pseudo = kind == "python-pseudo"
        is_hub = kind == "jupyterhub"
        self._row_libs_widget.setVisible(is_pseudo)

        # dla jupyterhub nie wymagamy lokalnego interpretera
        self.ed_path.setEnabled(not is_hub)
        self.btn_browse.setEnabled(not is_hub)

        self._row_hub_url.setVisible(is_hub)
        self._row_hub_user.setVisible(is_hub)
        self._row_hub_token.setVisible(is_hub)
        self.ed_hub_kernel.setVisible(is_hub)

        # label na browse dla interpretera
        if kind == "r":
            self.btn_browse.setText("Browse")
        else:
            self.btn_browse.setText("Browse")

    def _browse_interpreter(self):
        kind = str(self.cb_kind.currentData() or "")
        if kind == "r":
            filt = "Rscript (Rscript.exe);;R (R.exe);;All files (*.*)"
        else:
            filt = "Python (python.exe);;All files (*.*)"
        p, _ = QFileDialog.getOpenFileName(self, "Select interpreter", "", filt)
        if not p:
            return

        # jeśli user wskaże R.exe, a obok jest Rscript.exe, to podmień automatycznie
        if kind == "r" and os.path.basename(p).lower() == "r.exe":
            cand = os.path.join(os.path.dirname(p), "Rscript.exe")
            if os.path.exists(cand):
                p = cand

        self.ed_path.setText(p)

    def _browse_libs_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Select libraries folder", self.ed_libs.text() or "")
        if d:
            self.ed_libs.setText(d)

    def get_value(self) -> Dict:
        kind = str(self.cb_kind.currentData() or "")
        return {
            "kind": kind,
            "name": (self.ed_name.text() or "").strip(),
            "path": (self.ed_path.text() or "").strip(),
            "libs": (self.ed_libs.text() or "").strip(),
            "hub_url": (self.ed_hub_url.text() or "").strip(),
            "hub_user": (self.ed_hub_user.text() or "").strip(),
            "hub_token": (self.ed_hub_token.text() or "").strip(),
            "hub_kernel": (self.ed_hub_kernel.text() or "").strip(),
        }


class SettingsDialog(QDialog):
    """Ustawienia aplikacji."""

    def __init__(self, settings: SettingsService, db: DbService, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.resize(920, 520)

        self._settings = settings
        self._db = db
        self._envs: List[Dict] = self._settings.load_environments()
        self._conns: List[DbConnection] = self._db.load_connections()

        self.tabs = QTabWidget()

        self.tab_env = QWidget()
        self.tabs.addTab(self.tab_env, "Environments")

        self.tab_pkg = QWidget()
        self.tabs.addTab(self.tab_pkg, "Python Packages")

        self.tab_db = QWidget()
        self.tabs.addTab(self.tab_db, "Databases")

        self._build_env_tab()
        self._build_pkg_tab()
        self._build_db_tab()

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)

        root = QVBoxLayout(self)
        root.addWidget(self.tabs)
        root.addWidget(buttons)

        self._refresh_env_table()
        self._refresh_db_table()
        self._refresh_pkg_envs()

    # ---------------- env tab ----------------

    def _build_env_tab(self):
        self.tbl = QTableWidget(0, 4)
        self.tbl.setHorizontalHeaderLabels(["Name", "Type", "Interpreter", "Libs"])
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.horizontalHeader().setStretchLastSection(True)

        self.btn_add = QPushButton("Add")
        self.btn_edit = QPushButton("Edit")
        self.btn_remove = QPushButton("Remove")
        self.btn_test = QPushButton("Test")

        self.btn_add.clicked.connect(self._add_env)
        self.btn_edit.clicked.connect(self._edit_env)
        self.btn_remove.clicked.connect(self._remove_env)
        self.btn_test.clicked.connect(self._test_env)

        side = QVBoxLayout()
        side.addWidget(self.btn_add)
        side.addWidget(self.btn_edit)
        side.addWidget(self.btn_remove)
        side.addSpacing(12)
        side.addWidget(self.btn_test)
        side.addStretch(1)

        layout = QHBoxLayout(self.tab_env)
        layout.addWidget(self.tbl, 1)
        layout.addLayout(side)

    def _refresh_env_table(self):
        shown = [e for e in self._envs if (e or {}).get("key") != "python:kernel"]
        self.tbl.setRowCount(len(shown))

        for r, e in enumerate(shown):
            e = e or {}
            name = str(e.get("name") or "")
            kind = str(e.get("kind") or "")
            if kind == "jupyterhub":
                path = str(e.get("hub_url") or "")
                libs = str(e.get("hub_user") or "")
            else:
                path = str(e.get("path") or "")
                libs = str(e.get("libs") or "")

            if kind == "python-pseudo":
                kind_label = "Python (Pseudo-Venv)"
            elif kind == "jupyterhub":
                kind_label = "JupyterHub (Remote)"
            elif kind == "r":
                kind_label = "R (Rscript)"
            elif kind in ("python-kernel",) or (e.get("key") == "python:kernel"):
                kind_label = "Python (Kernel)"
            else:
                kind_label = "Python"

            it0 = QTableWidgetItem(name)
            it1 = QTableWidgetItem(kind_label)
            it2 = QTableWidgetItem(path)
            it3 = QTableWidgetItem(libs)

            for it in (it0, it1, it2, it3):
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)

            it0.setData(Qt.UserRole, e.get("key"))
            self.tbl.setItem(r, 0, it0)
            self.tbl.setItem(r, 1, it1)
            self.tbl.setItem(r, 2, it2)
            self.tbl.setItem(r, 3, it3)

        self.tbl.resizeColumnsToContents()

    def _selected_key(self) -> Optional[str]:
        row = self.tbl.currentRow()
        if row < 0:
            return None
        it = self.tbl.item(row, 0)
        if not it:
            return None
        return it.data(Qt.UserRole)

    def _add_env(self):
        dlg = _EnvEditDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        v = dlg.get_value()

        if not v["name"]:
            QMessageBox.warning(self, "Environment", "Name is required.")
            return
        if v["kind"] == "jupyterhub":
            if not v.get("hub_url") or not v.get("hub_user") or not v.get("hub_token"):
                QMessageBox.warning(self, "Environment", "JupyterHub URL, user and token are required.")
                return
        else:
            if not v["path"]:
                QMessageBox.warning(self, "Environment", "Interpreter path is required.")
                return
            if v["kind"] == "python-pseudo" and not v["libs"]:
                QMessageBox.warning(self, "Environment", "Libraries folder is required for Pseudo-Venv.")
                return

        key = self._make_env_key(v)
        if any((e or {}).get("key") == key for e in self._envs):
            QMessageBox.warning(self, "Environment", "Environment with same config already exists.")
            return

        self._envs.append({
            "key": key,
            "kind": v["kind"],
            "name": v["name"],
            "path": v["path"],
            "libs": v.get("libs", ""),
            "hub_url": v.get("hub_url", ""),
            "hub_user": v.get("hub_user", ""),
            "hub_token": v.get("hub_token", ""),
        })
        self._refresh_env_table()
        self._refresh_pkg_envs()

    def _edit_env(self):
        key = self._selected_key()
        if not key:
            return
        env = next((e for e in self._envs if (e or {}).get("key") == key), None)
        if not env:
            return

        dlg = _EnvEditDialog(self, env)
        if dlg.exec() != QDialog.Accepted:
            return
        v = dlg.get_value()

        if not v["name"]:
            QMessageBox.warning(self, "Environment", "Name is required.")
            return
        if v["kind"] == "jupyterhub":
            if not v.get("hub_url") or not v.get("hub_user") or not v.get("hub_token"):
                QMessageBox.warning(self, "Environment", "JupyterHub URL, user and token are required.")
                return
        else:
            if not v["path"]:
                QMessageBox.warning(self, "Environment", "Interpreter path is required.")
                return
            if v["kind"] == "python-pseudo" and not v["libs"]:
                QMessageBox.warning(self, "Environment", "Libraries folder is required for Pseudo-Venv.")
                return

        new_key = self._make_env_key(v)
        env["kind"] = v["kind"]
        env["name"] = v["name"]
        env["path"] = v["path"]
        env["libs"] = v.get("libs", "")
        env["hub_url"] = v.get("hub_url", "")
        env["hub_user"] = v.get("hub_user", "")
        env["hub_token"] = v.get("hub_token", "")
        env["key"] = new_key

        self._refresh_env_table()
        self._refresh_pkg_envs()

    def _remove_env(self):
        key = self._selected_key()
        if not key:
            return
        env = next((e for e in self._envs if (e or {}).get("key") == key), None)
        if not env:
            return
        if QMessageBox.question(self, "Remove", f"Remove environment '{env.get('name')}'?") != QMessageBox.Yes:
            return
        self._envs = [e for e in self._envs if (e or {}).get("key") != key]
        self._refresh_env_table()
        self._refresh_pkg_envs()

    def _make_env_key(self, v: Dict) -> str:
        kind = str(v.get("kind") or "")
        if kind == "jupyterhub":
            hub = str(v.get("hub_url") or "").strip().rstrip("/")
            user = str(v.get("hub_user") or "").strip()
            return f"jupyterhub:{hub}|{user}"
        path = os.path.abspath(str(v.get("path") or "")).replace("\\", "/")
        libs = os.path.abspath(str(v.get("libs") or "")).replace("\\", "/") if v.get("libs") else ""
        if kind == "python-pseudo":
            return f"python-pseudo:{path}|{libs}"
        return f"{kind}:{path}"

    def _test_env(self):
        key = self._selected_key()
        if not key:
            return
        env = next((e for e in self._envs if (e or {}).get("key") == key), None)
        if not env:
            return

        kind = str(env.get("kind") or "")
        if kind == "jupyterhub":
            from services.jupyterhub_client import JupyterHubClient, JupyterHubEnv
            try:
                jenv = JupyterHubEnv(
                    hub_url=str(env.get("hub_url") or ""),
                    user=str(env.get("hub_user") or ""),
                    token=str(env.get("hub_token") or ""),
                )
                client = JupyterHubClient(jenv)
                client.start_user_server()
                client.wait_user_ready(tries=20, sleep_s=0.5)
                QMessageBox.information(self, "Test", "JupyterHub OK (user server reachable).")
            except Exception as e:
                QMessageBox.warning(self, "Test", f"JupyterHub test failed:\n{e}")
            return

        path = str(env.get("path") or "")
        libs = str(env.get("libs") or "")

        if kind == "python-kernel" or (env.get("key") == "python:kernel"):
            QMessageBox.information(self, "Test", "Python (Kernel) jest dostępny.")
            return

        if not path or not os.path.exists(path):
            QMessageBox.warning(self, "Test", "Interpreter path does not exist.")
            return

        if kind == "python-pseudo":
            if not libs:
                QMessageBox.warning(self, "Test", "Libraries folder is empty.")
                return

        # uruchom --version / info
        p = QProcess(self)
        p.setProcessChannelMode(QProcess.MergedChannels)

        args: List[str] = []
        if kind == "r":
            args = [path, "--version"]
        else:
            args = [path, "-c", "import sys; import site; print(sys.version); print(sys.executable); print('OK')"]

        if kind == "python-pseudo":
            # PYTHONPATH = libs
            from PySide6.QtCore import QProcessEnvironment
            envv = QProcessEnvironment.systemEnvironment()
            envv.insert("PYTHONPATH", libs)
            p.setProcessEnvironment(envv)

        out: List[str] = []

        def _ready():
            data = bytes(p.readAllStandardOutput())
            if data:
                out.append(data.decode("utf-8", errors="replace"))

        def _fin(rc: int, _st):
            _ready()
            text = "".join(out).strip()
            if rc == 0:
                QMessageBox.information(self, "Test", text or "OK")
            else:
                QMessageBox.warning(self, "Test", text or f"Exit code {rc}")

        p.readyReadStandardOutput.connect(_ready)
        p.finished.connect(_fin)
        p.start(args[0], args[1:])

    # ---------------- packages tab ----------------

    def _build_pkg_tab(self):
        self.cb_pkg_env = QComboBox()
        self.cb_pkg_env.setMinimumWidth(320)
        self.cb_pkg_env.currentIndexChanged.connect(self._on_pkg_env_changed)

        self.lbl_pkg_info = QLabel("")
        self.lbl_pkg_info.setWordWrap(True)
        self.lbl_pkg_info.setStyleSheet("color:#a9b6c7;")

        top = QHBoxLayout()
        top.addWidget(QLabel("Pseudo-Venv:"))
        top.addWidget(self.cb_pkg_env, 1)

        self.btn_pkg_refresh = QPushButton("Refresh")
        self.btn_pkg_ensure = QPushButton("Create libs folder")
        self.btn_pkg_open = QPushButton("Open libs folder")
        top.addWidget(self.btn_pkg_refresh)
        top.addWidget(self.btn_pkg_ensure)
        top.addWidget(self.btn_pkg_open)

        self.btn_pkg_refresh.clicked.connect(self._refresh_packages)
        self.btn_pkg_ensure.clicked.connect(self._ensure_libs_dir)
        self.btn_pkg_open.clicked.connect(self._open_libs_dir)

        self.tbl_pkg = QTableWidget(0, 2)
        self.tbl_pkg.setHorizontalHeaderLabels(["Package", "Version"])
        self.tbl_pkg.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl_pkg.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tbl_pkg.verticalHeader().setVisible(False)
        self.tbl_pkg.horizontalHeader().setStretchLastSection(True)

        self.ed_pkg_spec = QLineEdit()
        self.ed_pkg_spec.setPlaceholderText("np. requests==2.32.0  |  pandas  |  numpy>=1.26")

        self.btn_install = QPushButton("Install / Upgrade")
        self.btn_uninstall = QPushButton("Uninstall selected")

        self.btn_install.clicked.connect(self._install_pkg)
        self.btn_uninstall.clicked.connect(self._uninstall_selected_pkg)

        row = QHBoxLayout()
        row.addWidget(QLabel("Package spec:"))
        row.addWidget(self.ed_pkg_spec, 1)
        row.addWidget(self.btn_install)
        row.addWidget(self.btn_uninstall)

        self.out_pkg = QPlainTextEdit()
        self.out_pkg.setReadOnly(True)
        self.out_pkg.setMaximumBlockCount(5000)

        layout = QVBoxLayout(self.tab_pkg)
        layout.addLayout(top)
        layout.addWidget(self.lbl_pkg_info)
        layout.addWidget(self.tbl_pkg, 1)
        layout.addLayout(row)
        layout.addWidget(QLabel("pip output:"))
        layout.addWidget(self.out_pkg, 1)

        self._pkg_proc: Optional[QProcess] = None

    def _pseudo_envs(self) -> List[Dict]:
        return [e for e in (self._envs or []) if str((e or {}).get("kind") or "") == "python-pseudo"]

    def _refresh_pkg_envs(self):
        cur_key = self.cb_pkg_env.currentData()
        self.cb_pkg_env.blockSignals(True)
        self.cb_pkg_env.clear()

        envs = self._pseudo_envs()
        for e in envs:
            self.cb_pkg_env.addItem(str(e.get("name") or e.get("key")), str(e.get("key")))

        self.cb_pkg_env.blockSignals(False)

        if cur_key:
            idx = self.cb_pkg_env.findData(cur_key)
            if idx >= 0:
                self.cb_pkg_env.setCurrentIndex(idx)
            elif self.cb_pkg_env.count() > 0:
                self.cb_pkg_env.setCurrentIndex(0)
        else:
            if self.cb_pkg_env.count() > 0:
                self.cb_pkg_env.setCurrentIndex(0)
        self._on_pkg_env_changed()

    def _current_pkg_env(self) -> Optional[Dict]:
        key = self.cb_pkg_env.currentData()
        if not key:
            return None
        return next((e for e in self._envs if (e or {}).get("key") == key), None)

    def _on_pkg_env_changed(self):
        env = self._current_pkg_env()
        if not env:
            self.lbl_pkg_info.setText("Brak środowisk typu Python (Pseudo-Venv). Dodaj je w zakładce Environments.")
            self.tbl_pkg.setRowCount(0)
            return
        libs = str(env.get("libs") or "")
        py = str(env.get("path") or "")
        self.lbl_pkg_info.setText(f"Interpreter: {py}\nLibs: {libs}")
        # Nie odświeżaj automatycznie (żeby nie odpalać pip przy każdym kliknięciu),
        # ale czyść tabelę jeśli zmiana env.
        self.tbl_pkg.setRowCount(0)

    def _ensure_libs_dir(self):
        env = self._current_pkg_env()
        if not env:
            return
        libs = str(env.get("libs") or "")
        if not libs:
            QMessageBox.warning(self, "Pseudo-Venv", "Libs folder is empty.")
            return
        try:
            os.makedirs(libs, exist_ok=True)
            QMessageBox.information(self, "Pseudo-Venv", "Libs folder is ready.")
        except Exception as e:
            QMessageBox.warning(self, "Pseudo-Venv", f"Cannot create libs folder:\n{e}")

    def _open_libs_dir(self):
        env = self._current_pkg_env()
        if not env:
            return
        libs = str(env.get("libs") or "")
        if not libs or not os.path.exists(libs):
            QMessageBox.warning(self, "Pseudo-Venv", "Libs folder does not exist.")
            return
        try:
            os.startfile(libs)  # Windows
        except Exception:
            # fallback: show in dialog
            QMessageBox.information(self, "Libs folder", libs)

    def _selected_pkg_name(self) -> Optional[str]:
        r = self.tbl_pkg.currentRow()
        if r < 0:
            return None
        it = self.tbl_pkg.item(r, 0)
        if not it:
            return None
        return (it.text() or "").strip() or None

    def _append_pkg_out(self, text: str):
        if not text:
            return
        # PySide6: MoveOperation enum is on QTextCursor, not on the cursor instance.
        self.out_pkg.moveCursor(QTextCursor.MoveOperation.End)
        self.out_pkg.insertPlainText(text)
        self.out_pkg.moveCursor(QTextCursor.MoveOperation.End)

    def _run_pip(self, args: List[str], on_done=None):
        if self._pkg_proc and self._pkg_proc.state() != QProcess.NotRunning:
            self._append_pkg_out("\n[pip] process already running\n")
            return

        env = self._current_pkg_env()
        if not env:
            return

        py = str(env.get("path") or "")
        libs = str(env.get("libs") or "")
        if not py or not os.path.exists(py):
            QMessageBox.warning(self, "pip", "Interpreter path does not exist.")
            return
        if not libs:
            QMessageBox.warning(self, "pip", "Libs folder is empty.")
            return
        try:
            os.makedirs(libs, exist_ok=True)
        except Exception as e:
            QMessageBox.warning(self, "pip", f"Cannot create libs folder:\n{e}")
            return

        self._pkg_proc = QProcess(self)
        self._pkg_proc.setProcessChannelMode(QProcess.MergedChannels)

        # pip działa na interpreterze, ale instalujemy do --target libs
        full = [py, "-m", "pip"] + args

        def _ready():
            data = bytes(self._pkg_proc.readAllStandardOutput())
            if data:
                self._append_pkg_out(data.decode("utf-8", errors="replace"))

        def _fin(rc: int, _st):
            _ready()
            self._append_pkg_out(f"\n[pip exit] {rc}\n")
            self._pkg_proc = None
            if on_done:
                on_done(int(rc))

        self._pkg_proc.readyReadStandardOutput.connect(_ready)
        self._pkg_proc.finished.connect(_fin)
        self._append_pkg_out("\n$ " + " ".join(full) + "\n")
        self._pkg_proc.start(full[0], full[1:])

    def _refresh_packages(self):
        env = self._current_pkg_env()
        if not env:
            return
        libs = str(env.get("libs") or "")
        if not libs:
            QMessageBox.warning(self, "Pseudo-Venv", "Libs folder is empty.")
            return
        if not os.path.exists(libs):
            # nie wymuszaj, ale ułatw
            if QMessageBox.question(self, "Pseudo-Venv", "Libs folder does not exist. Create it?") == QMessageBox.Yes:
                self._ensure_libs_dir()
            else:
                return

        # pip list --path libs --format=json
        def _done(rc: int):
            if rc != 0:
                return
            # output pip list jest już w out_pkg, ale potrzebujemy parsować
            # uruchom osobny proces tylko do pobrania json (bez mieszania w output)
            self._load_pip_list()

        self._run_pip(["list", "--path", libs, "--format", "json"], on_done=_done)

    def _load_pip_list(self):
        env = self._current_pkg_env()
        if not env:
            return
        py = str(env.get("path") or "")
        libs = str(env.get("libs") or "")
        if not py or not libs:
            return

        p = QProcess(self)
        p.setProcessChannelMode(QProcess.MergedChannels)
        out: List[str] = []

        def _ready():
            data = bytes(p.readAllStandardOutput())
            if data:
                out.append(data.decode("utf-8", errors="replace"))

        def _fin(rc: int, _st):
            _ready()
            if rc != 0:
                return
            raw = "".join(out).strip()
            try:
                items = json.loads(raw) if raw else []
            except Exception:
                items = []
            if not isinstance(items, list):
                items = []
            self.tbl_pkg.setRowCount(len(items))
            for r, it in enumerate(items):
                name = str((it or {}).get("name") or "")
                ver = str((it or {}).get("version") or "")
                a = QTableWidgetItem(name)
                b = QTableWidgetItem(ver)
                a.setFlags(a.flags() & ~Qt.ItemIsEditable)
                b.setFlags(b.flags() & ~Qt.ItemIsEditable)
                self.tbl_pkg.setItem(r, 0, a)
                self.tbl_pkg.setItem(r, 1, b)
            self.tbl_pkg.resizeColumnsToContents()

        p.readyReadStandardOutput.connect(_ready)
        p.finished.connect(_fin)
        p.start(py, ["-m", "pip", "list", "--path", libs, "--format", "json"])

    def _install_pkg(self):
        env = self._current_pkg_env()
        if not env:
            return
        libs = str(env.get("libs") or "")
        spec = (self.ed_pkg_spec.text() or "").strip()
        if not spec:
            QMessageBox.warning(self, "pip", "Podaj nazwę pakietu.")
            return

        def _done(_rc: int):
            self._refresh_packages()

        self._run_pip(["install", "--upgrade", "--target", libs, spec], on_done=_done)

    def _uninstall_selected_pkg(self):
        env = self._current_pkg_env()
        if not env:
            return
        libs = str(env.get("libs") or "")
        name = self._selected_pkg_name()
        if not name:
            QMessageBox.information(self, "pip", "Wybierz pakiet z listy.")
            return
        if QMessageBox.question(self, "pip", f"Uninstall '{name}' from libs folder?") != QMessageBox.Yes:
            return

        def _done(_rc: int):
            self._refresh_packages()

        # uninstall z --target nie istnieje; używamy --path + -y
        self._run_pip(["uninstall", "-y", "--path", libs, name], on_done=_done)

    # ---------------- db tab ----------------

    def _build_db_tab(self):
        self.tbl_db = QTableWidget(0, 3)
        self.tbl_db.setHorizontalHeaderLabels(["Name", "Type", "DSN"])
        self.tbl_db.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl_db.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tbl_db.verticalHeader().setVisible(False)
        self.tbl_db.horizontalHeader().setStretchLastSection(True)

        self.btn_db_add = QPushButton("Add")
        self.btn_db_edit = QPushButton("Edit")
        self.btn_db_remove = QPushButton("Remove")

        self.btn_db_add.clicked.connect(self._add_conn)
        self.btn_db_edit.clicked.connect(self._edit_conn)
        self.btn_db_remove.clicked.connect(self._remove_conn)

        side = QVBoxLayout()
        side.addWidget(self.btn_db_add)
        side.addWidget(self.btn_db_edit)
        side.addWidget(self.btn_db_remove)
        side.addStretch(1)

        layout = QHBoxLayout(self.tab_db)
        layout.addWidget(self.tbl_db, 1)
        layout.addLayout(side)

    def _refresh_db_table(self):
        self.tbl_db.setRowCount(len(self._conns))
        for r, c in enumerate(self._conns):
            it0 = QTableWidgetItem(c.name)
            it1 = QTableWidgetItem(c.kind)
            it2 = QTableWidgetItem(c.dsn)
            for it in (it0, it1, it2):
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
            # przechowuj stabilny klucz (a nie name), bo nazwy mogą się zmieniać
            it0.setData(Qt.UserRole, c.key)
            self.tbl_db.setItem(r, 0, it0)
            self.tbl_db.setItem(r, 1, it1)
            self.tbl_db.setItem(r, 2, it2)
        self.tbl_db.resizeColumnsToContents()

    def _selected_db_key(self) -> Optional[str]:
        row = self.tbl_db.currentRow()
        if row < 0:
            return None
        it = self.tbl_db.item(row, 0)
        if not it:
            return None
        return it.data(Qt.UserRole)

    def _add_conn(self):
        dlg = _DbEditDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        v = dlg.get_value()
        if not v["name"]:
            QMessageBox.warning(self, "Database", "Name is required.")
            return
        if not v["dsn"]:
            QMessageBox.warning(self, "Database", "DSN/Path is required.")
            return
        # DbService wymaga stabilnego `key` – bez tego zapis jest pomijany.
        v["key"] = uuid.uuid4().hex
        self._conns.append(DbConnection(**v))
        self._refresh_db_table()

    def _edit_conn(self):
        key = self._selected_db_key()
        if not key:
            return
        conn = next((c for c in self._conns if c.key == key), None)
        if not conn:
            return

        dlg = _DbEditDialog(self, {
            "name": conn.name,
            "kind": conn.kind,
            "dsn": conn.dsn,
            "user": conn.user,
            "password": conn.password,
            "extra_json": conn.extra_json,
        })
        if dlg.exec() != QDialog.Accepted:
            return
        v = dlg.get_value()
        if not v["name"]:
            QMessageBox.warning(self, "Database", "Name is required.")
            return
        if not v["dsn"]:
            QMessageBox.warning(self, "Database", "DSN/Path is required.")
            return

        conn.name = v["name"]
        conn.kind = v["kind"]
        conn.dsn = v["dsn"]
        conn.user = v["user"]
        conn.password = v["password"]
        conn.extra_json = v.get("extra_json") or ""

        self._refresh_db_table()

    def _remove_conn(self):
        key = self._selected_db_key()
        if not key:
            return
        conn = next((c for c in self._conns if c.key == key), None)
        if not conn:
            return
        if QMessageBox.question(self, "Remove", f"Remove connection '{conn.name}'?") != QMessageBox.Yes:
            return
        self._conns = [c for c in self._conns if c.key != key]
        self._refresh_db_table()

    # ---------------- save ----------------

    def _save(self):
        # pseudo-venv: jeśli libs nie istnieje, utwórz
        for e in (self._envs or []):
            if str((e or {}).get("kind") or "") == "python-pseudo":
                libs = str((e or {}).get("libs") or "")
                if libs:
                    try:
                        os.makedirs(libs, exist_ok=True)
                    except Exception as ex:
                        QMessageBox.warning(self, "Pseudo-Venv", f"Cannot create libs folder:\n{libs}\n\n{ex}")
                        return

        self._settings.save_environments(self._envs)
        self._db.save_connections(self._conns)
        self.accept()
