from __future__ import annotations

import json
from dataclasses import dataclass
from queue import Empty

from PySide6.QtCore import QObject, QTimer

from qtconsole.inprocess import QtInProcessKernelManager


@dataclass
class KernelSpec:
    id: str
    label: str


class KernelService(QObject):
    """
    Jeden kernel, dwa klienty:
    - console_client: wyłącznie dla qtconsole
    - exec_client: wyłącznie dla notebooka (żeby nie było "kradzieży" iopub)

    Notebook wykonuje kod przez exec_client i my czytamy iopub -> emitujemy zdarzenia per msg_id.
    """

    def __init__(self):
        super().__init__()
        self._km: QtInProcessKernelManager | None = None
        self._console_kc = None
        self._exec_kc = None

        self._timer: QTimer | None = None
        self._handlers: dict[str, dict] = {}  # msg_id -> {on_item, on_done}

    def start_inprocess_python(self):
        if self._km:
            return self._km

        km = QtInProcessKernelManager()
        km.start_kernel(show_banner=False)
        km.kernel.gui = "qt"
        self._km = km

        self._console_kc = km.client()
        self._console_kc.start_channels()

        self._exec_kc = km.client()
        self._exec_kc.start_channels()

        self._timer = QTimer(self)
        self._timer.setInterval(20)
        self._timer.timeout.connect(self._poll_exec_iopub)
        self._timer.start()

        return km

    def get_console_client(self):
        self.start_inprocess_python()
        return self._console_kc

    def shutdown(self):
        try:
            if self._timer:
                self._timer.stop()
        finally:
            self._timer = None

        try:
            if self._exec_kc:
                self._exec_kc.stop_channels()
            if self._console_kc:
                self._console_kc.stop_channels()
            if self._km:
                self._km.shutdown_kernel(now=True)
        finally:
            self._km = None
            self._console_kc = None
            self._exec_kc = None
            self._handlers.clear()

    def execute_notebook_cell(self, code: str, on_item, on_done=None) -> str:
        """
        on_item(item: dict) gdzie item ma postać:
          {"type": "stream", "text": "..."}
          {"type": "error", "traceback": "..."}
          {"type": "display", "data": {...}, "metadata": {...}}
        """
        self.start_inprocess_python()
        code = (code or "").rstrip() + "\n"
        msg_id = self._exec_kc.execute(code, store_history=True)

        self._handlers[msg_id] = {"on_item": on_item, "on_done": on_done}
        return msg_id

    def _poll_exec_iopub(self):
        if not self._exec_kc:
            return

        while True:
            try:
                msg = self._exec_kc.get_iopub_msg(timeout=0)
            except Empty:
                break
            except Exception:
                break

            parent = (msg.get("parent_header") or {})
            msg_id = parent.get("msg_id")
            if not msg_id or msg_id not in self._handlers:
                continue

            h = self._handlers[msg_id]
            on_item = h.get("on_item")
            on_done = h.get("on_done")

            mtype = msg.get("msg_type")
            content = msg.get("content") or {}

            if mtype == "stream":
                if on_item:
                    on_item({"type": "stream", "text": content.get("text", "")})

            elif mtype in ("execute_result", "display_data"):
                if on_item:
                    on_item({
                        "type": "display",
                        "data": content.get("data") or {},
                        "metadata": content.get("metadata") or {}
                    })

            elif mtype == "error":
                tb = content.get("traceback") or []
                # tb może mieć ANSI; zostawiamy, renderer może je oczyścić
                if on_item:
                    on_item({"type": "error", "traceback": "\n".join(tb)})

            elif mtype == "status":
                if content.get("execution_state") == "idle":
                    if on_done:
                        try:
                            on_done()
                        except Exception:
                            pass
                    self._handlers.pop(msg_id, None)
