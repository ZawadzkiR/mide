import os
from dataclasses import dataclass


@dataclass
class Project:
    root: str


class ProjectService:
    def __init__(self):
        self.project: Project | None = None

    def open_project(self, root: str) -> Project:
        root = os.path.abspath(root)
        self.project = Project(root=root)
        return self.project
