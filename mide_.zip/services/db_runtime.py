from __future__ import annotations

import contextlib
import json
import sqlite3
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from services.db_service import DbConnection


@dataclass
class QueryResult:
    columns: List[str]
    rows: List[Tuple[Any, ...]]


@dataclass
class TableColumn:
    name: str
    data_type: str
    nullable: bool = True
    is_pk: bool = False


class CancelToken:
    """
    Best-effort cancel:
    - sqlite3: connection.interrupt()
    - pyodbc: cursor.cancel()
    - inne: best-effort
    """

    def __init__(self):
        self._cancel_cb = None

    def set_cancel_callback(self, cb):
        self._cancel_cb = cb

    def cancel(self):
        try:
            if self._cancel_cb:
                self._cancel_cb()
        except Exception:
            pass


class DbRuntime:
    # =========================
    # Public API
    # =========================

    def test_connection(self, conn: DbConnection) -> Tuple[bool, str]:
        """Returns (ok, message)."""
        kind = (conn.kind or "").lower()
        try:
            if kind in ("sqlite", "sqlite3"):
                c = self._sqlite_connect(conn)
                c.close()
                return True, "SQLite: OK"
            if kind in ("odbc", "mssql"):
                c = self._odbc_connect(conn)
                c.close()
                return True, "ODBC: OK"
            if kind in ("oracle", "oracledb"):
                c = self._oracle_connect(conn)
                c.close()
                return True, "Oracle: OK"
            if kind in ("snowflake",):
                c = self._snowflake_connect(conn)
                c.close()
                return True, "Snowflake: OK"
            if kind in ("jaydebeapi", "jdbc", "sybase"):
                c = self._jdbc_connect(conn)
                c.close()
                return True, "JDBC: OK"
            if kind in ("hadoop",):
                extra = self._parse_extra(conn)
                mode = (extra.get("mode") or "odbc").lower()
                c = self._jdbc_connect(conn) if mode == "jdbc" else self._odbc_connect(conn)
                c.close()
                return True, f"Hadoop/{mode.upper()}: OK"
            return False, f"Unknown kind: {conn.kind}"
        except Exception as e:
            return False, str(e)

    def execute(self, conn: DbConnection, sql: str, limit: int = 0) -> QueryResult:
        kind = (conn.kind or "").lower()
        if kind in ("sqlite", "sqlite3"):
            return self._sqlite_execute(conn, sql, limit)
        if kind in ("odbc", "mssql"):
            return self._odbc_execute(conn, sql, limit)
        if kind in ("oracle", "oracledb"):
            return self._oracle_execute(conn, sql, limit)
        if kind in ("snowflake",):
            return self._snowflake_execute(conn, sql, limit)
        if kind in ("jaydebeapi", "jdbc", "sybase"):
            return self._jdbc_execute(conn, sql, limit)
        if kind in ("hadoop",):
            extra = self._parse_extra(conn)
            mode = (extra.get("mode") or "odbc").lower()
            return self._jdbc_execute(conn, sql, limit) if mode == "jdbc" else self._odbc_execute(conn, sql, limit)
        raise NotImplementedError(f"Connector not implemented for kind: {conn.kind}")

    def execute_cancellable(
        self,
        conn: DbConnection,
        sql: str,
        limit: int = 0,
        token: Optional[CancelToken] = None,
    ) -> QueryResult:
        kind = (conn.kind or "").lower()
        if kind in ("sqlite", "sqlite3"):
            return self._sqlite_execute_cancellable(conn, sql, limit, token)
        if kind in ("odbc", "mssql"):
            return self._odbc_execute_cancellable(conn, sql, limit, token)
        if kind in ("oracle", "oracledb"):
            return self._oracle_execute_cancellable(conn, sql, limit, token)
        if kind in ("snowflake",):
            return self._snowflake_execute_cancellable(conn, sql, limit, token)
        if kind in ("jaydebeapi", "jdbc", "sybase"):
            return self._jdbc_execute_cancellable(conn, sql, limit, token)
        if kind in ("hadoop",):
            extra = self._parse_extra(conn)
            mode = (extra.get("mode") or "odbc").lower()
            return self._jdbc_execute_cancellable(conn, sql, limit, token) if mode == "jdbc" else self._odbc_execute_cancellable(conn, sql, limit, token)
        return self.execute(conn, sql, limit)

    def list_schemas(self, conn: DbConnection) -> List[str]:
        kind = (conn.kind or "").lower()
        if kind in ("sqlite", "sqlite3"):
            return []
        if kind in ("odbc", "mssql"):
            return self._odbc_schemas(conn)
        if kind in ("oracle", "oracledb"):
            return self._oracle_schemas(conn)
        if kind in ("snowflake",):
            return self._snowflake_schemas(conn)
        if kind in ("jaydebeapi", "jdbc", "sybase"):
            return self._jdbc_schemas(conn)
        if kind in ("hadoop",):
            extra = self._parse_extra(conn)
            mode = (extra.get("mode") or "odbc").lower()
            return self._jdbc_schemas(conn) if mode == "jdbc" else self._odbc_schemas(conn)
        return []

    def list_objects(self, conn: DbConnection, schema: Optional[str] = None) -> Dict[str, List[str]]:
        kind = (conn.kind or "").lower()
        if kind in ("sqlite", "sqlite3"):
            return self._sqlite_objects(conn)
        if kind in ("odbc", "mssql"):
            return self._odbc_objects(conn, schema=schema)
        if kind in ("oracle", "oracledb"):
            return self._oracle_objects(conn, schema=schema)
        if kind in ("snowflake",):
            return self._snowflake_objects(conn, schema=schema)
        if kind in ("jaydebeapi", "jdbc", "sybase"):
            return self._jdbc_objects(conn, schema=schema)
        if kind in ("hadoop",):
            extra = self._parse_extra(conn)
            mode = (extra.get("mode") or "odbc").lower()
            return self._jdbc_objects(conn, schema=schema) if mode == "jdbc" else self._odbc_objects(conn, schema=schema)
        return {"tables": [], "views": []}

    def describe_table(self, conn: DbConnection, table: str, schema: Optional[str] = None) -> List[TableColumn]:
        kind = (conn.kind or "").lower()
        if kind in ("sqlite", "sqlite3"):
            return self._sqlite_describe_table(conn, table)
        if kind in ("odbc", "mssql"):
            return self._odbc_describe_table(conn, table, schema=schema)
        if kind in ("oracle", "oracledb"):
            return self._oracle_describe_table(conn, table, schema=schema)
        if kind in ("snowflake",):
            return self._snowflake_describe_table(conn, table, schema=schema)
        if kind in ("jaydebeapi", "jdbc", "sybase"):
            return self._jdbc_describe_table(conn, table, schema=schema)
        if kind in ("hadoop",):
            extra = self._parse_extra(conn)
            mode = (extra.get("mode") or "odbc").lower()
            return self._jdbc_describe_table(conn, table, schema=schema) if mode == "jdbc" else self._odbc_describe_table(conn, table, schema=schema)
        return []

    def build_table_preview_sql(self, conn: DbConnection, table: str, schema: Optional[str] = None, limit: int = 1000) -> str:
        kind = (conn.kind or "").lower()
        full = f"{schema}.{table}" if schema else table
        lim = int(limit)

        if lim <= 0:
            return f"SELECT * FROM {full}"

        if kind in ("mssql",):
            return f"SELECT TOP {lim} * FROM {full}"
        if kind in ("oracle", "oracledb"):
            # Oracle: quoting avoids ORA-00942 for quoted/mixed-case identifiers.
            # ROWNUM works across versions (unlike FETCH FIRST on older DBs).
            qfull = self._oracle_qual(schema, table)
            if lim <= 0:
                return f"SELECT * FROM {qfull}"
            return f"SELECT * FROM {qfull} WHERE ROWNUM <= {lim}"
        if kind in ("snowflake",):
            return f"SELECT * FROM {full} LIMIT {lim}"
        if kind in ("sqlite", "sqlite3"):
            if schema:
                return f'SELECT * FROM "{schema}"."{table}" LIMIT {lim}'
            return f'SELECT * FROM "{table}" LIMIT {lim}'
        return f"SELECT * FROM {full} LIMIT {lim}"

    # =========================
    # Helpers
    # =========================

    def _parse_extra(self, conn: DbConnection) -> Dict[str, Any]:
        raw = (conn.extra_json or "").strip()
        if not raw:
            return {}
        try:
            v = json.loads(raw)
            return v if isinstance(v, dict) else {}
        except Exception:
            return {}

    def _oracle_quote_ident(self, ident: str) -> str:
        """Quote identifier for Oracle safely (supports mixed-case / special chars)."""
        s = (ident or "").replace('"', '""')
        return f'"{s}"'

    def _oracle_qual(self, schema: Optional[str], table: str) -> str:
        """Return fully-qualified Oracle name with quotes."""
        if schema:
            return f"{self._oracle_quote_ident(schema)}.{self._oracle_quote_ident(table)}"
        return self._oracle_quote_ident(table)

    # =========================
    # SQLite
    # =========================

    def _sqlite_connect(self, conn: DbConnection) -> sqlite3.Connection:
        path = (conn.dsn or "").strip()
        if not path:
            raise ValueError("SQLite requires file path in DSN/Path")
        return sqlite3.connect(path, check_same_thread=False)

    def _sqlite_execute(self, conn: DbConnection, sql: str, limit: int) -> QueryResult:
        return self._sqlite_execute_cancellable(conn, sql, limit, None)

    def _sqlite_execute_cancellable(self, conn: DbConnection, sql: str, limit: int, token: Optional[CancelToken]) -> QueryResult:
        sql = (sql or "").strip()
        if not sql:
            return QueryResult([], [])

        c = self._sqlite_connect(conn)
        try:
            if token:
                token.set_cancel_callback(getattr(c, "interrupt", None) or (lambda: None))
            cur = c.cursor()
            cur.execute(sql)
            if cur.description:
                cols = [d[0] for d in cur.description]
                rows = cur.fetchmany(int(limit)) if int(limit) > 0 else cur.fetchall()
                return QueryResult(cols, rows)
            c.commit()
            return QueryResult(["result"], [("OK",)])
        finally:
            with contextlib.suppress(Exception):
                c.close()

    def _sqlite_objects(self, conn: DbConnection) -> Dict[str, List[str]]:
        q = "SELECT name, type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY type, name"
        res = self._sqlite_execute(conn, q, 0)
        tables, views = [], []
        for name, typ in res.rows:
            if str(typ).lower() == "view":
                views.append(str(name))
            else:
                tables.append(str(name))
        return {"tables": tables, "views": views}

    def _sqlite_describe_table(self, conn: DbConnection, table: str) -> List[TableColumn]:
        c = self._sqlite_connect(conn)
        try:
            cur = c.cursor()
            cur.execute(f'PRAGMA table_info("{table}")')
            out: List[TableColumn] = []
            for _, name, typ, notnull, _, pk in cur.fetchall():
                out.append(TableColumn(
                    name=str(name),
                    data_type=str(typ),
                    nullable=(int(notnull) == 0),
                    is_pk=(int(pk) == 1),
                ))
            return out
        finally:
            with contextlib.suppress(Exception):
                c.close()

    # =========================
    # ODBC (pyodbc)
    # =========================

    def _odbc_connect(self, conn: DbConnection):
        import pyodbc  # type: ignore
        dsn = (conn.dsn or "").strip()
        if not dsn:
            raise ValueError("ODBC requires connection string/DSN in DSN field")

        low = dsn.lower()
        if conn.user and "uid=" not in low and "user=" not in low:
            dsn = dsn.rstrip(";") + f";UID={conn.user}"
        if conn.password and "pwd=" not in low and "password=" not in low:
            dsn = dsn.rstrip(";") + f";PWD={conn.password}"

        return pyodbc.connect(dsn, autocommit=False)

    def _odbc_execute(self, conn: DbConnection, sql: str, limit: int) -> QueryResult:
        return self._odbc_execute_cancellable(conn, sql, limit, None)

    def _odbc_execute_cancellable(self, conn: DbConnection, sql: str, limit: int, token: Optional[CancelToken]) -> QueryResult:
        sql = (sql or "").strip()
        if not sql:
            return QueryResult([], [])

        c = self._odbc_connect(conn)
        try:
            cur = c.cursor()
            if token:
                token.set_cancel_callback(getattr(cur, "cancel", None) or (lambda: None))
            cur.execute(sql)
            if cur.description:
                cols = [d[0] for d in cur.description]
                rows = cur.fetchmany(int(limit)) if int(limit) > 0 else cur.fetchall()
                return QueryResult(cols, rows)
            c.commit()
            return QueryResult(["result"], [("OK",)])
        finally:
            with contextlib.suppress(Exception):
                c.close()

    def _odbc_schemas(self, conn: DbConnection) -> List[str]:
        c = self._odbc_connect(conn)
        try:
            cur = c.cursor()
            for q in (
                "SELECT DISTINCT TABLE_SCHEMA FROM INFORMATION_SCHEMA.TABLES",
                "SELECT DISTINCT table_schema FROM information_schema.tables",
            ):
                try:
                    cur.execute(q)
                    rows = cur.fetchall()
                    return sorted({str(r[0]) for r in rows if r and r[0] is not None})
                except Exception:
                    continue

            schemas = set()
            try:
                for row in cur.tables():
                    schem = getattr(row, "table_schem", None) or getattr(row, "TABLE_SCHEM", None)
                    if schem:
                        schemas.add(str(schem))
            except Exception:
                pass
            return sorted(schemas)
        finally:
            with contextlib.suppress(Exception):
                c.close()

    def _odbc_objects(self, conn: DbConnection, schema: Optional[str] = None) -> Dict[str, List[str]]:
        c = self._odbc_connect(conn)
        try:
            cur = c.cursor()
            tables, views = [], []
            try:
                for row in cur.tables(schema=schema or None):
                    name = getattr(row, "table_name", None) or getattr(row, "TABLE_NAME", None)
                    schem = getattr(row, "table_schem", None) or getattr(row, "TABLE_SCHEM", None)
                    typ = getattr(row, "table_type", None) or getattr(row, "TABLE_TYPE", None)
                    if not name or not typ:
                        continue
                    full = f"{schem}.{name}" if schem else str(name)
                    t = str(typ).upper()
                    if "VIEW" in t:
                        views.append(full)
                    elif "TABLE" in t:
                        tables.append(full)
                return {"tables": sorted(set(tables)), "views": sorted(set(views))}
            except Exception:
                pass

            where = "WHERE TABLE_SCHEMA = ?" if schema else ""
            q = f"SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES {where}"
            cur.execute(q, (schema,)) if schema else cur.execute(q)
            for schem, name, typ in cur.fetchall():
                full = f"{schem}.{name}" if schem else str(name)
                if "VIEW" in str(typ).upper():
                    views.append(full)
                else:
                    tables.append(full)
            return {"tables": sorted(set(tables)), "views": sorted(set(views))}
        finally:
            with contextlib.suppress(Exception):
                c.close()

    def _odbc_describe_table(self, conn: DbConnection, table: str, schema: Optional[str] = None) -> List[TableColumn]:
        c = self._odbc_connect(conn)
        try:
            cur = c.cursor()
            pk_cols = set()
            try:
                for r in cur.primaryKeys(table=table, schema=schema or None):
                    name = getattr(r, "column_name", None) or getattr(r, "COLUMN_NAME", None)
                    if name:
                        pk_cols.add(str(name))
            except Exception:
                pk_cols = set()

            cols: List[TableColumn] = []
            try:
                for r in cur.columns(table=table, schema=schema or None):
                    name = getattr(r, "column_name", None) or getattr(r, "COLUMN_NAME", None)
                    typ = getattr(r, "type_name", None) or getattr(r, "TYPE_NAME", None) or ""
                    nullable = getattr(r, "nullable", None) or getattr(r, "NULLABLE", None)
                    is_nullable = True
                    if nullable is not None:
                        is_nullable = (int(nullable) != 0)
                    cols.append(TableColumn(
                        name=str(name),
                        data_type=str(typ),
                        nullable=is_nullable,
                        is_pk=(str(name) in pk_cols),
                    ))
                return cols
            except Exception:
                full = f"{schema}.{table}" if schema else table
                cur.execute(f"SELECT * FROM {full} WHERE 1=0")
                for d in (cur.description or []):
                    cols.append(TableColumn(name=str(d[0]), data_type=str(d[1])))
                return cols
        finally:
            with contextlib.suppress(Exception):
                c.close()

    # =========================
    # Oracle (oracledb) - best-effort
    # =========================

    def _oracle_connect(self, conn: DbConnection):
        import oracledb  # type: ignore
        dsn = (conn.dsn or "").strip()
        if not dsn:
            raise ValueError("Oracle requires DSN in DSN field")
        return oracledb.connect(user=conn.user, password=conn.password, dsn=dsn)

    def _oracle_execute(self, conn: DbConnection, sql: str, limit: int) -> QueryResult:
        return self._oracle_execute_cancellable(conn, sql, limit, None)

    def _oracle_execute_cancellable(self, conn: DbConnection, sql: str, limit: int, token: Optional[CancelToken]) -> QueryResult:
        sql = (sql or "").strip()
        if not sql:
            return QueryResult([], [])

        c = self._oracle_connect(conn)
        try:
            if token:
                token.set_cancel_callback(getattr(c, "cancel", None) or (lambda: None))
            cur = c.cursor()
            cur.execute(sql)
            if cur.description:
                cols = [d[0] for d in cur.description]
                rows = cur.fetchmany(int(limit)) if int(limit) > 0 else cur.fetchall()
                return QueryResult(cols, rows)
            c.commit()
            return QueryResult(["result"], [("OK",)])
        finally:
            with contextlib.suppress(Exception):
                c.close()

    def _oracle_schemas(self, conn: DbConnection) -> List[str]:
        res = self._oracle_execute(conn, "SELECT USERNAME FROM ALL_USERS ORDER BY USERNAME", 0)
        return [str(r[0]) for r in res.rows if r and r[0] is not None]

    def _oracle_objects(self, conn: DbConnection, schema: Optional[str] = None) -> Dict[str, List[str]]:
        schema_u = (schema or "").strip().upper()
        if schema_u:
            q = (
                "SELECT OWNER, OBJECT_NAME, OBJECT_TYPE "
                f"FROM ALL_OBJECTS WHERE OWNER = '{schema_u}' AND OBJECT_TYPE IN ('TABLE','VIEW') "
                "ORDER BY OWNER, OBJECT_TYPE, OBJECT_NAME"
            )
        else:
            q = (
                "SELECT OWNER, OBJECT_NAME, OBJECT_TYPE "
                "FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE','VIEW') "
                "ORDER BY OWNER, OBJECT_TYPE, OBJECT_NAME"
            )
        res = self._oracle_execute(conn, q, 0)
        tables, views = [], []
        for owner, name, typ in res.rows:
            full = f"{owner}.{name}" if owner else str(name)
            if str(typ).upper() == "VIEW":
                views.append(full)
            else:
                tables.append(full)
        return {"tables": sorted(set(tables)), "views": sorted(set(views))}

    def _oracle_describe_table(self, conn: DbConnection, table: str, schema: Optional[str] = None) -> List[TableColumn]:
        schema_u = (schema or "").strip().upper()
        table_u = (table or "").strip().upper()
        owner_clause = f"AND OWNER = '{schema_u}'" if schema_u else ""

        pk_q = (
            "SELECT cols.COLUMN_NAME "
            "FROM ALL_CONSTRAINTS cons "
            "JOIN ALL_CONS_COLUMNS cols ON cons.OWNER = cols.OWNER AND cons.CONSTRAINT_NAME = cols.CONSTRAINT_NAME "
            f"WHERE cons.CONSTRAINT_TYPE = 'P' AND cols.TABLE_NAME = '{table_u}' {owner_clause}"
        )
        pk_res = self._oracle_execute(conn, pk_q, 0)
        pk_cols = {str(r[0]) for r in pk_res.rows if r and r[0] is not None}

        col_q = (
            "SELECT COLUMN_NAME, DATA_TYPE, NULLABLE "
            "FROM ALL_TAB_COLUMNS "
            f"WHERE TABLE_NAME = '{table_u}' {owner_clause} "
            "ORDER BY COLUMN_ID"
        )
        res = self._oracle_execute(conn, col_q, 0)
        out: List[TableColumn] = []
        for name, dtype, nullable in res.rows:
            out.append(TableColumn(
                name=str(name),
                data_type=str(dtype),
                nullable=(str(nullable).upper() == "Y"),
                is_pk=(str(name) in pk_cols),
            ))
        return out

    # =========================
    # Snowflake - FIXED
    # =========================

    def _snowflake_connect(self, conn: DbConnection):
        import snowflake.connector  # type: ignore

        extra = self._parse_extra(conn)

        # Account: allow either extra_json["account"] OR DSN field
        account = (extra.get("account") or extra.get("ACCOUNT") or "").strip()
        if not account:
            account = (conn.dsn or "").strip()

        # User/password: prefer UI fields, fallback to extra_json if ktoś tam trzyma
        user = (conn.user or "").strip() or (extra.get("user") or extra.get("USER") or "").strip()
        password = (conn.password or "").strip() or (extra.get("password") or extra.get("PASSWORD") or "").strip()

        if not account:
            raise ValueError("Snowflake requires account: set it in DSN field or extra_json {'account':'...'}")
        if not user:
            raise ValueError("Snowflake requires user: set it in User field or extra_json {'user':'...'}")
        if not password:
            raise ValueError("Snowflake requires password: set it in Password field or extra_json {'password':'...'}")

        # Optional params from extra_json
        kwargs = {
            "account": account,
            "user": user,
            "password": password,
        }
        for k in ("warehouse", "database", "schema", "role"):
            v = extra.get(k) or extra.get(k.upper())
            if v:
                kwargs[k] = v

        return snowflake.connector.connect(**kwargs)

    def _snowflake_execute(self, conn: DbConnection, sql: str, limit: int) -> QueryResult:
        return self._snowflake_execute_cancellable(conn, sql, limit, None)

    def _snowflake_execute_cancellable(self, conn: DbConnection, sql: str, limit: int, token: Optional[CancelToken]) -> QueryResult:
        sql = (sql or "").strip()
        if not sql:
            return QueryResult([], [])

        c = self._snowflake_connect(conn)
        try:
            cur = c.cursor()
            if token:
                token.set_cancel_callback(getattr(cur, "cancel", None) or (lambda: None))
            cur.execute(sql)
            if cur.description:
                cols = [d[0] for d in cur.description]
                rows = cur.fetchmany(int(limit)) if int(limit) > 0 else cur.fetchall()
                return QueryResult(cols, rows)
            return QueryResult(["result"], [("OK",)])
        finally:
            with contextlib.suppress(Exception):
                c.close()

    def _snowflake_schemas(self, conn: DbConnection) -> List[str]:
        res = self._snowflake_execute(conn, "SHOW SCHEMAS", 0)
        out = []
        for r in res.rows:
            if len(r) >= 2 and r[1]:
                out.append(str(r[1]))
        return sorted(set(out))

    def _snowflake_objects(self, conn: DbConnection, schema: Optional[str] = None) -> Dict[str, List[str]]:
        schema_clause = f"IN SCHEMA {schema}" if schema else ""
        tables = self._snowflake_execute(conn, f"SHOW TABLES {schema_clause}", 0)
        views = self._snowflake_execute(conn, f"SHOW VIEWS {schema_clause}", 0)

        def pick_name(rows):
            out = []
            for r in rows:
                if len(r) >= 2 and r[1]:
                    out.append(str(r[1]))
            return out

        return {"tables": sorted(set(pick_name(tables.rows))), "views": sorted(set(pick_name(views.rows)))}

    def _snowflake_describe_table(self, conn: DbConnection, table: str, schema: Optional[str] = None) -> List[TableColumn]:
        full = f"{schema}.{table}" if schema else table
        res = self._snowflake_execute(conn, f"DESC TABLE {full}", 0)
        out: List[TableColumn] = []
        for r in res.rows:
            if len(r) >= 2:
                name = str(r[0])
                dtype = str(r[1])
                nullable = True
                if len(r) >= 4 and r[3] is not None:
                    nullable = (str(r[3]).upper() != "N")
                out.append(TableColumn(name=name, data_type=dtype, nullable=nullable, is_pk=False))
        return out

    # =========================
    # JDBC (JayDeBeApi) - best-effort
    # =========================

    def _jdbc_connect(self, conn: DbConnection):
        import jaydebeapi  # type: ignore
        extra = self._parse_extra(conn)
        driver = extra.get("driver") or extra.get("driverClass") or extra.get("driver_class")
        jars = extra.get("jars") or extra.get("jar") or extra.get("classpath")

        if not driver:
            raise ValueError("JDBC requires extra_json with {'driver': 'com....Driver', 'jars': ['path1.jar', ...]}")

        url = (conn.dsn or "").strip()
        if not url:
            raise ValueError("JDBC requires DSN as JDBC URL (e.g. jdbc:...)")

        if isinstance(jars, str):
            jars = [jars]
        if not isinstance(jars, list) or not jars:
            raise ValueError("JDBC requires extra_json 'jars' (list of jar paths)")

        props = extra.get("props") if isinstance(extra.get("props"), dict) else {}
        user = props.get("user") or conn.user
        pwd = props.get("password") or conn.password

        return jaydebeapi.connect(driver, url, [user, pwd], jars)

    def _jdbc_execute(self, conn: DbConnection, sql: str, limit: int) -> QueryResult:
        return self._jdbc_execute_cancellable(conn, sql, limit, None)

    def _jdbc_execute_cancellable(self, conn: DbConnection, sql: str, limit: int, token: Optional[CancelToken]) -> QueryResult:
        sql = (sql or "").strip()
        if not sql:
            return QueryResult([], [])

        c = self._jdbc_connect(conn)
        try:
            cur = c.cursor()
            if token:
                token.set_cancel_callback(getattr(cur, "cancel", None) or (lambda: None))
            cur.execute(sql)
            try:
                cols = [d[0] for d in (cur.description or [])]
                if cols:
                    rows = cur.fetchmany(int(limit)) if int(limit) > 0 else cur.fetchall()
                    return QueryResult(cols, rows)
            except Exception:
                pass
            try:
                c.commit()
            except Exception:
                pass
            return QueryResult(["result"], [("OK",)])
        finally:
            with contextlib.suppress(Exception):
                c.close()

    def _jdbc_schemas(self, conn: DbConnection) -> List[str]:
        try:
            res = self._jdbc_execute(conn, "SELECT DISTINCT table_schema FROM information_schema.tables", 0)
            return sorted({str(r[0]) for r in res.rows if r and r[0] is not None})
        except Exception:
            return []

    def _jdbc_objects(self, conn: DbConnection, schema: Optional[str] = None) -> Dict[str, List[str]]:
        where = ""
        if schema:
            where = f"WHERE table_schema = '{schema}'"
        q = f"SELECT table_schema, table_name, table_type FROM information_schema.tables {where}"
        try:
            res = self._jdbc_execute(conn, q, 0)
            tables, views = [], []
            for schem, name, typ in res.rows:
                full = f"{schem}.{name}" if schem else str(name)
                if "VIEW" in str(typ).upper():
                    views.append(full)
                else:
                    tables.append(full)
            return {"tables": sorted(set(tables)), "views": sorted(set(views))}
        except Exception:
            return {"tables": [], "views": []}

    def _jdbc_describe_table(self, conn: DbConnection, table: str, schema: Optional[str] = None) -> List[TableColumn]:
        full = f"{schema}.{table}" if schema else table
        try:
            res = self._jdbc_execute(conn, f"SELECT * FROM {full} WHERE 1=0", 0)
            return [TableColumn(name=c, data_type="") for c in res.columns]
        except Exception:
            return []
