from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from typing import Callable, Optional, Any, Dict


try:
    import requests
except Exception:  # pragma: no cover
    requests = None

try:
    import websocket  # websocket-client
except Exception:  # pragma: no cover
    websocket = None


@dataclass(frozen=True)
class JupyterHubEnv:
    hub_url: str
    user: str
    token: str
    kernel_name: str = ""  # kernelspec name, e.g. 'python3'

    @property
    def user_base(self) -> str:
        # single-user base URL (Jupyter Server)
        return f"{self.hub_url.rstrip('/')}/user/{self.user}"


class JupyterHubClient:
    """Minimalny klient JupyterHub + Jupyter Server API.

    Założenia:
    - start serwera usera przez /hub/api/... (Authorization: token ...)
    - komunikacja z single-user server: /user/<user>/api/* (token w querystring)
    """

    def __init__(self, env: JupyterHubEnv, timeout: int = 20):
        if requests is None:
            raise RuntimeError("Missing dependency: requests")
        self.env = env
        self.timeout = int(timeout)

    # -------- hub / server lifecycle --------

    def start_user_server(self) -> None:
        url = f"{self.env.hub_url.rstrip('/')}/hub/api/users/{self.env.user}/server"
        r = requests.post(url, headers={"Authorization": f"token {self.env.token}"}, timeout=self.timeout)
        # Zwykle JupyterHub zwraca 201/202, a gdy serwer już działa to 409.
        # Niektóre konfiguracje (np. reverse proxy / custom handlers) zwracają 400 z komunikatem "already running".
        if r.status_code in (201, 202, 409):
            return
        if r.status_code == 400:
            try:
                payload = r.json() if r.text else {}
                msg = str(payload.get("message") or payload.get("error") or r.text)
            except Exception:
                msg = r.text
            if "already running" in (msg or "").lower():
                return
        raise RuntimeError(f"Start server failed: {r.status_code} {r.text}")

    def wait_user_ready(self, tries: int = 60, sleep_s: float = 1.0) -> None:
        base = self.env.user_base
        last: Optional[str] = None
        for _ in range(int(tries)):
            try:
                rr = requests.get(f"{base}/api", params={"token": self.env.token}, timeout=2)
                if rr.status_code == 200:
                    return
                last = f"{rr.status_code} {rr.text}"
            except Exception as e:
                last = str(e)
            time.sleep(float(sleep_s))
        raise RuntimeError(f"User server not ready ({last})")

    # -------- kernels --------

    def kernelspecs(self) -> Dict[str, Any]:
        """Pobierz listę dostępnych kernelspecs."""
        base = self.env.user_base
        r = requests.get(f"{base}/api/kernelspecs", params={"token": self.env.token}, timeout=self.timeout)
        r.raise_for_status()
        return dict(r.json() or {})

    def create_kernel(self, kernel_name: str | None = None) -> str:
        base = self.env.user_base
        kname = (kernel_name if kernel_name is not None else self.env.kernel_name) or ""
        payload = {"name": kname} if kname else None
        r = requests.post(
            f"{base}/api/kernels",
            params={"token": self.env.token},
            data=(json.dumps(payload) if payload else None),
            headers=({"Content-Type": "application/json"} if payload else None),
            timeout=self.timeout,
        )
        r.raise_for_status()
        return str(r.json().get("id"))

    def delete_kernel(self, kernel_id: str) -> None:
        base = self.env.user_base
        try:
            requests.delete(f"{base}/api/kernels/{kernel_id}", params={"token": self.env.token}, timeout=self.timeout)
        except Exception:
            pass

    # -------- execution via websocket --------

    def exec_code_stream(
        self,
        kernel_id: str,
        code: str,
        on_text: Callable[[str], None],
        stop_flag: Callable[[], bool] | None = None,
    ) -> int:
        """Wykonuje kod i streamuje stdout/stderr oraz błędy.

        Zwraca 0 jeśli zakończone OK, !=0 jeśli błąd.
        """
        if websocket is None:
            raise RuntimeError("Missing dependency: websocket-client")

        base = self.env.user_base
        ws_url = (
            f"{base.replace('https://','wss://').replace('http://','ws://')}"
            f"/api/kernels/{kernel_id}/channels?token={self.env.token}"
        )

        ws = websocket.create_connection(ws_url)

        session_id = uuid.uuid4().hex
        msg_id = uuid.uuid4().hex
        req = {
            "header": {
                "msg_id": msg_id,
                "username": self.env.user,
                "session": session_id,
                "msg_type": "execute_request",
                "version": "5.3",
            },
            "parent_header": {},
            "metadata": {},
            "content": {
                "code": code or "",
                "silent": False,
                "store_history": True,
                "user_expressions": {},
                "allow_stdin": False,
                "stop_on_error": True,
            },
            "channel": "shell",
            "buffers": [],
        }

        ws.send(json.dumps(req))

        got_reply = False
        rc = 0

        try:
            while True:
                if stop_flag and stop_flag():
                    # best-effort: przerwij pętlę (kernel zostanie ubity przez caller)
                    rc = -1
                    break

                raw = ws.recv()
                m = json.loads(raw)
                channel = m.get("channel")
                msg_type = (m.get("header") or {}).get("msg_type")
                content = m.get("content") or {}

                if channel == "iopub":
                    if msg_type == "stream":
                        txt = content.get("text")
                        if txt:
                            on_text(str(txt))
                    elif msg_type in ("execute_result", "display_data"):
                        data = content.get("data") or {}
                        txt = data.get("text/plain")
                        if txt:
                            on_text(str(txt) + "\n")
                    elif msg_type == "error":
                        rc = 1
                        tb = content.get("traceback") or []
                        if tb:
                            on_text("\n".join(tb) + "\n")
                        else:
                            on_text(str(content) + "\n")

                if channel == "shell" and msg_type == "execute_reply":
                    got_reply = True
                    status = content.get("status")
                    if status and str(status) != "ok":
                        rc = 1

                if got_reply and channel == "iopub" and msg_type == "status":
                    if content.get("execution_state") == "idle":
                        break

        finally:
            try:
                ws.close()
            except Exception:
                pass

        return int(rc)

    # -------- contents API (file manager) --------

    def contents_get(self, path: str = "", content: bool = False) -> Dict[str, Any]:
        base = self.env.user_base
        p = (path or "").lstrip("/")
        r = requests.get(
            f"{base}/api/contents/{p}",
            params={"token": self.env.token, "content": int(bool(content))},
            timeout=self.timeout,
        )
        r.raise_for_status()
        return dict(r.json() or {})

    def contents_put_text(self, path: str, text: str) -> None:
        base = self.env.user_base
        p = (path or "").lstrip("/")
        payload = {"type": "file", "format": "text", "content": text}
        r = requests.put(
            f"{base}/api/contents/{p}",
            params={"token": self.env.token},
            data=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            timeout=self.timeout,
        )
        r.raise_for_status()

    def contents_mkdir(self, path: str) -> None:
        base = self.env.user_base
        p = (path or "").lstrip("/")
        payload = {"type": "directory"}
        r = requests.put(
            f"{base}/api/contents/{p}",
            params={"token": self.env.token},
            data=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            timeout=self.timeout,
        )
        r.raise_for_status()

    def contents_delete(self, path: str) -> None:
        base = self.env.user_base
        p = (path or "").lstrip("/")
        r = requests.delete(
            f"{base}/api/contents/{p}",
            params={"token": self.env.token},
            timeout=self.timeout,
        )
        r.raise_for_status()

    def contents_rename(self, path: str, new_path: str) -> None:
        base = self.env.user_base
        p = (path or "").lstrip("/")
        payload = {"path": (new_path or "").lstrip("/")}
        r = requests.patch(
            f"{base}/api/contents/{p}",
            params={"token": self.env.token},
            data=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            timeout=self.timeout,
        )
        r.raise_for_status()

    # -------- terminals API (optional) --------

    def terminals_create(self) -> str:
        """Utwórz nowy terminal (Jupyter Server /api/terminals). Zwraca nazwę terminala."""
        base = self.env.user_base
        r = requests.post(f"{base}/api/terminals", params={"token": self.env.token}, timeout=self.timeout)
        r.raise_for_status()
        return str((r.json() or {}).get("name") or "")

    def terminals_delete(self, name: str) -> None:
        base = self.env.user_base
        n = (name or "").strip()
        if not n:
            return
        try:
            requests.delete(f"{base}/api/terminals/{n}", params={"token": self.env.token}, timeout=self.timeout)
        except Exception:
            pass

    def terminal_ws_url(self, name: str) -> str:
        base = self.env.user_base
        n = (name or "").strip()
        return (
            f"{base.replace('https://','wss://').replace('http://','ws://')}"
            f"/terminals/websocket/{n}?token={self.env.token}"
        )
