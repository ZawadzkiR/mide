from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Dict, List, Optional

from PySide6.QtCore import QSettings


@dataclass
class DbConnection:
    key: str
    name: str
    kind: str  # odbc | oracle | snowflake | jaydebeapi | mssql | sybase | hadoop
    dsn: str   # connection string / DSN / URL
    user: str = ""
    password: str = ""
    extra_json: str = ""  # dowolne dodatkowe opcje


class DbService:
    """Przechowywanie definicji połączeń do baz w QSettings.

    W tej iteracji: tylko zapis/odczyt definicji i UI. Realne łączenie + introspekcja
    (schematy/tabele) będzie w następnym kroku.
    """

    ORG = "FutIDE"
    APP = "FutIDE"

    KEY_CONNECTIONS = "db.connections.v1"  # JSON list
    KEY_SELECTED = "db.selected"           # key

    def __init__(self):
        self._qs = QSettings(self.ORG, self.APP)

    def load_connections(self) -> List[DbConnection]:
        raw = self._qs.value(self.KEY_CONNECTIONS, "")
        if raw is None or raw == "":
            return []
        if isinstance(raw, (bytes, bytearray)):
            try:
                raw = raw.decode("utf-8", errors="replace")
            except Exception:
                raw = str(raw)

        try:
            data = json.loads(str(raw)) if not isinstance(raw, list) else raw
            if not isinstance(data, list):
                return []
            out: List[DbConnection] = []
            for x in data:
                if not isinstance(x, dict):
                    continue
                out.append(DbConnection(
                    key=str(x.get("key") or ""),
                    name=str(x.get("name") or ""),
                    kind=str(x.get("kind") or ""),
                    dsn=str(x.get("dsn") or ""),
                    user=str(x.get("user") or ""),
                    password=str(x.get("password") or ""),
                    extra_json=str(x.get("extra_json") or ""),
                ))
            # usuń puste klucze
            return [c for c in out if c.key]
        except Exception:
            return []

    def save_connections(self, conns: List[DbConnection]):
        payload: List[Dict] = []
        for c in conns or []:
            if not c.key:
                continue
            payload.append({
                "key": c.key,
                "name": c.name,
                "kind": c.kind,
                "dsn": c.dsn,
                "user": c.user,
                "password": c.password,
                "extra_json": c.extra_json,
            })
        self._qs.setValue(self.KEY_CONNECTIONS, json.dumps(payload, ensure_ascii=False))
        try:
            self._qs.sync()
        except Exception:
            pass

    def get_selected_key(self) -> str:
        return str(self._qs.value(self.KEY_SELECTED, "") or "")

    def set_selected_key(self, key: str):
        if key is not None:
            self._qs.setValue(self.KEY_SELECTED, key)
            try:
                self._qs.sync()
            except Exception:
                pass

    def find(self, key: str) -> Optional[DbConnection]:
        for c in self.load_connections():
            if c.key == key:
                return c
        return None
