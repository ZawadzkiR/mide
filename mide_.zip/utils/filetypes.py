from dataclasses import dataclass


@dataclass(frozen=True)
class FileType:
    id: str
    label: str


PY = FileType("python", "Python")
R = FileType("r", "R")
IPYNB = FileType("ipynb", "Notebook")


def detect_filetype(path: str) -> FileType:
    p = path.lower()
    if p.endswith(".ipynb"):
        return IPYNB
    if p.endswith(".r"):
        return R
    return PY
