from dataclasses import dataclass


@dataclass(frozen=True)
class FileType:
    id: str
    label: str


PY = FileType("python", "Python")
R = FileType("r", "R")
SQL = FileType("sql", "SQL")
IPYNB = FileType("ipynb", "Notebook")


def detect_filetype(path: str) -> FileType:
    p = (path or "").lower()
    if p.endswith(".ipynb"):
        return IPYNB
    if p.endswith(".sql"):
        return SQL
    if p.endswith(".r"):
        return R
    if p.endswith(".py"):
        return PY
    # fallback
    return PY
