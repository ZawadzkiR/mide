import sys
import os
import traceback
import faulthandler

from PySide6.QtCore import QtMsgType, qInstallMessageHandler
from PySide6.QtWidgets import QApplication, QMessageBox

from ui.main_window import MainWindow


def _append_log(text: str):
    try:
        with open("crash.log", "a", encoding="utf-8") as f:
            f.write(text)
    except Exception:
        pass


def _qt_message_handler(mode, context, message):
    # mode: QtMsgType
    try:
        if mode == QtMsgType.QtFatalMsg:
            kind = "FATAL"
        elif mode == QtMsgType.QtCriticalMsg:
            kind = "CRITICAL"
        elif mode == QtMsgType.QtWarningMsg:
            kind = "WARNING"
        elif mode == QtMsgType.QtInfoMsg:
            kind = "INFO"
        else:
            kind = "DEBUG"
    except Exception:
        kind = "QT"

    loc = ""
    try:
        if context and context.file:
            loc = f"{context.file}:{context.line} "
    except Exception:
        pass

    _append_log(f"[QT {kind}] {loc}{message}\n")


def _install_global_handlers():
    # Python crashes / access violations
    try:
        faulthandler.enable(open("faulthandler.log", "w", encoding="utf-8"), all_threads=True)
    except Exception:
        try:
            faulthandler.enable(all_threads=True)
        except Exception:
            pass

    # Qt internal warnings / fatals
    try:
        qInstallMessageHandler(_qt_message_handler)
    except Exception:
        pass

    # Unhandled Python exceptions (incl. those bubbling outside main())
    def excepthook(exc_type, exc, tb):
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        _append_log("\n" + "=" * 80 + "\n")
        _append_log(text + "\n")
        try:
            QMessageBox.critical(None, "FutIDE - crash", text)
        except Exception:
            pass

    sys.excepthook = excepthook


def main() -> int:
    _install_global_handlers()
    app = QApplication(sys.argv)

    # Keep app alive even if a window is temporarily hidden during layout restore.
    try:
        app.setQuitOnLastWindowClosed(True)
    except Exception:
        pass

    w = None
    try:
        w = MainWindow()
        w.show()
        return app.exec()
    except Exception:
        tb = traceback.format_exc()
        _append_log("\n" + "=" * 80 + "\n")
        _append_log(tb + "\n")
        try:
            QMessageBox.critical(None, "FutIDE - crash", tb)
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
