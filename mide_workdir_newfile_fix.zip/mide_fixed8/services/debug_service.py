from __future__ import annotations

import os
import sys
import tempfile
from dataclasses import dataclass
from typing import Optional, Callable

from PySide6.QtCore import QObject, QProcess, Signal


@dataclass
class DebugSessionInfo:
    lang: str  # 'python' | 'r' | 'sql'
    title: str
    source_path: str | None = None


class DebugService(QObject):
    outputReceived = Signal(str)
    errorReceived = Signal(str)
    started = Signal(object)   # DebugSessionInfo
    finished = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._proc: Optional[QProcess] = None
        self._session: Optional[DebugSessionInfo] = None
        self._tmp_path: Optional[str] = None

    def is_running(self) -> bool:
        return self._proc is not None and self._proc.state() != QProcess.NotRunning

    def session(self) -> Optional[DebugSessionInfo]:
        return self._session

    def stop(self):
        if not self._proc:
            return
        try:
            self._proc.kill()
        except Exception:
            pass

    def send(self, text: str):
        if not self._proc:
            return
        if not text.endswith("\n"):
            text += "\n"
        try:
            self._proc.write(text.encode("utf-8"))
        except Exception:
            try:
                self._proc.write(text.encode("latin-1", errors="ignore"))
            except Exception:
                pass

    # ---------------- Python ----------------

    def start_python_pdb_file(self, python_exe: str, path: str, title: str = "Python (pdb)"):
        self._cleanup()
        self._proc = QProcess(self)
        self._proc.setProcessChannelMode(QProcess.SeparateChannels)

        self._proc.readyReadStandardOutput.connect(lambda: self._emit_out(self._proc.readAllStandardOutput()))
        self._proc.readyReadStandardError.connect(lambda: self._emit_err(self._proc.readAllStandardError()))
        self._proc.finished.connect(self._on_finished)

        args = ["-m", "pdb", path]
        self._session = DebugSessionInfo(lang="python", title=title, source_path=path)
        self._proc.start(python_exe or sys.executable, args)
        self.started.emit(self._session)

    def start_python_pdb_code(self, python_exe: str, code: str, title: str = "Python (pdb)"):
        fd, tmp = tempfile.mkstemp(prefix="mide_dbg_", suffix=".py", text=True)
        os.close(fd)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(code)
        self._tmp_path = tmp
        self.start_python_pdb_file(python_exe, tmp, title=title)

    # ---------------- R (minimal interactive) ----------------

    def start_r_interactive(self, r_exe: str = "R", title: str = "R (interactive)"):
        self._cleanup()
        self._proc = QProcess(self)
        self._proc.setProcessChannelMode(QProcess.SeparateChannels)

        self._proc.readyReadStandardOutput.connect(lambda: self._emit_out(self._proc.readAllStandardOutput()))
        self._proc.readyReadStandardError.connect(lambda: self._emit_err(self._proc.readAllStandardError()))
        self._proc.finished.connect(self._on_finished)

        # vanilla interactive session
        self._session = DebugSessionInfo(lang="r", title=title, source_path=None)
        self._proc.start(r_exe, ["--vanilla"])
        self.started.emit(self._session)

    def _emit_out(self, ba):
        try:
            s = bytes(ba).decode("utf-8", errors="replace")
        except Exception:
            s = str(ba)
        if s:
            self.outputReceived.emit(s)

    def _emit_err(self, ba):
        try:
            s = bytes(ba).decode("utf-8", errors="replace")
        except Exception:
            s = str(ba)
        if s:
            self.errorReceived.emit(s)

    def _on_finished(self, exitCode: int, _status=None):
        self.finished.emit(int(exitCode))
        self._cleanup()

    def _cleanup(self):
        if self._proc:
            try:
                self._proc.readyReadStandardOutput.disconnect()
            except Exception:
                pass
            try:
                self._proc.readyReadStandardError.disconnect()
            except Exception:
                pass
            try:
                self._proc.finished.disconnect()
            except Exception:
                pass
            try:
                self._proc.deleteLater()
            except Exception:
                pass
        self._proc = None
        self._session = None
        if self._tmp_path:
            try:
                os.remove(self._tmp_path)
            except Exception:
                pass
        self._tmp_path = None
