from __future__ import annotations

from dataclasses import dataclass
from queue import Empty

from PySide6.QtCore import QObject, QTimer
from qtconsole.inprocess import QtInProcessKernelManager


@dataclass
class KernelSpec:
    id: str
    label: str


class KernelService(QObject):
    """
    Jeden kernel, dwa klienty:
    - console_client: wyłącznie dla qtconsole
    - exec_client: wyłącznie dla notebooka/wykonywania (żeby nie było "kradzieży" iopub)

    Wykonanie kodu idzie przez exec_client, a my pollujemy iopub/shell i wołamy handlery per msg_id.
    """

    def __init__(self):
        super().__init__()
        self._km: QtInProcessKernelManager | None = None
        self._console_kc = None
        self._exec_kc = None

        self._timer: QTimer | None = None
        self._handlers: dict[str, dict] = {}  # msg_id -> {on_item, on_done}

    def start_inprocess_python(self):
        if self._km:
            return self._km

        km = QtInProcessKernelManager()
        km.start_kernel(show_banner=False)
        km.kernel.gui = "qt"
        self._km = km

        self._console_kc = km.client()
        self._console_kc.start_channels()

        self._exec_kc = km.client()
        self._exec_kc.start_channels()

        self._timer = QTimer(self)
        self._timer.setInterval(20)
        self._timer.timeout.connect(self._poll_channels)
        self._timer.start()

        return km

    def get_console_client(self):
        self.start_inprocess_python()
        return self._console_kc

    def get_user_namespace(self) -> dict:
        """Zwraca user_ns z in-process kernela (bez roundtripu przez kanały).

        Działa tylko dla QtInProcessKernelManager. Jest to najbardziej niezawodny
        sposób na podgląd zmiennych (jak w Spyder/RStudio), bo nie zależy od
        user_expressions/streamów.
        """
        self.start_inprocess_python()
        try:
            shell = getattr(self._km.kernel, "shell", None)
            ns = getattr(shell, "user_ns", None)
            return ns if isinstance(ns, dict) else {}
        except Exception:
            return {}

    def _safe_shutdown_kernel(self):
        """Zamyka kernel in-process. Różne wersje mają różne sygnatury."""
        if not self._km:
            return
        try:
            self._km.shutdown_kernel(now=True)
        except TypeError:
            try:
                self._km.shutdown_kernel()
            except Exception:
                pass
        except Exception:
            pass

    def shutdown(self):
        try:
            if self._timer:
                self._timer.stop()
        finally:
            self._timer = None

        try:
            if self._exec_kc:
                self._exec_kc.stop_channels()
            if self._console_kc:
                self._console_kc.stop_channels()
            if self._km:
                self._safe_shutdown_kernel()
        finally:
            self._km = None
            self._console_kc = None
            self._exec_kc = None
            self._handlers.clear()

    def execute_notebook_cell(self, code: str, on_item, on_done=None) -> str:
        """
        on_item(item: dict) gdzie item ma postać:
          {"type": "stream", "text": "..."}
          {"type": "error", "traceback": "..."}
          {"type": "display", "data": {...}, "metadata": {...}}
        """
        # UWAGA (in-process): qtconsole i nasz exec_kc mogą "konkurować" o te same
        # wiadomości (IOPub/Shell) i wtedy UI notebooka nie dostaje status=idle.
        # Żeby notebook nie wisiał na "running...", wykonujemy komórki notebooka
        # bezpośrednio przez IPython shell (run_cell) i sami emitujemy itemy.
        return self.execute_notebook_cell_direct(code, on_item=on_item, on_done=on_done)

    def execute_notebook_cell_direct(self, code: str, on_item=None, on_done=None) -> str:
        """Wykonuje kod komórki bez roundtripu po kanałach Jupyter.

        Działa stabilnie z QtInProcessKernelManager i nie zależy od tego, czy qtconsole
        w tym samym czasie odbiera IOPub.
        """
        from contextlib import redirect_stdout, redirect_stderr
        import io

        self.start_inprocess_python()
        code = (code or "").rstrip() + "\n"

        shell = getattr(self._km.kernel, "shell", None)
        msg_id = f"direct-{id(code)}"

        out_buf = io.StringIO()
        err_buf = io.StringIO()

        try:
            with redirect_stdout(out_buf), redirect_stderr(err_buf):
                res = shell.run_cell(code, store_history=True)

            stdout_text = out_buf.getvalue()
            stderr_text = err_buf.getvalue()

            if stdout_text and on_item:
                on_item({"type": "stream", "name": "stdout", "text": stdout_text})
            if stderr_text and on_item:
                on_item({"type": "stream", "name": "stderr", "text": stderr_text})

            # Jeśli była wartość (np. ostatnie wyrażenie), pokaż ją jako text/plain
            try:
                if getattr(res, "result", None) is not None and on_item:
                    on_item({
                        "type": "display",
                        "data": {"text/plain": repr(res.result)},
                        "metadata": {},
                    })
            except Exception:
                pass

            # Obsłuż błędy IPython
            if getattr(res, "error_in_exec", None) is not None or getattr(res, "error_before_exec", None) is not None:
                err = res.error_in_exec or res.error_before_exec
                tb = getattr(err, "__traceback__", None)
                import traceback as _tb
                tb_text = "".join(_tb.format_exception(type(err), err, tb))
                if on_item:
                    on_item({"type": "error", "traceback": tb_text, "ename": type(err).__name__, "evalue": str(err)})

        except Exception as e:
            import traceback as _tb
            if on_item:
                on_item({"type": "error", "traceback": "".join(_tb.format_exception(type(e), e, e.__traceback__))})
        finally:
            if on_done:
                try:
                    on_done()
                except TypeError:
                    try:
                        on_done({})
                    except Exception:
                        pass
                except Exception:
                    pass

        return msg_id

    def execute_silent(
        self,
        code: str,
        on_item=None,
        on_done=None,
        *,
        silent: bool = True,
        store_history: bool = False,
        user_expressions: dict | None = None,
    ) -> str:
        """Wykonuje kod w kernelu.

        - silent=True: nie spamuje konsoli kernela (qtconsole) i nie dodaje In/Out.
        - store_history=False: nie zapisuje w historii.
        - user_expressions: pozwala odebrać wynik bez print() (wraca w execute_reply).
        """
        self.start_inprocess_python()
        code = (code or "").rstrip() + "\n"
        kwargs = {}
        if user_expressions is not None:
            kwargs["user_expressions"] = user_expressions

        msg_id = self._exec_kc.execute(
            code,
            silent=bool(silent),
            store_history=bool(store_history),
            **kwargs,
        )
        self._handlers[msg_id] = {"on_item": on_item, "on_done": on_done}
        return msg_id

    def _poll_channels(self):
        self._poll_exec_iopub()
        self._poll_exec_shell()

    def _poll_exec_iopub(self):
        if not self._exec_kc:
            return

        while True:
            try:
                msg = self._exec_kc.get_iopub_msg(timeout=0)
            except Empty:
                break
            except Exception:
                break

            parent = (msg.get("parent_header") or {})
            msg_id = parent.get("msg_id")
            if not msg_id or msg_id not in self._handlers:
                continue

            h = self._handlers[msg_id]
            on_item = h.get("on_item")
            mtype = msg.get("msg_type")
            content = msg.get("content") or {}

            if mtype == "stream":
                if on_item:
                    on_item({"type": "stream", "text": content.get("text", "")})

            elif mtype in ("execute_result", "display_data"):
                if on_item:
                    on_item(
                        {
                            "type": "display",
                            "data": content.get("data") or {},
                            "metadata": content.get("metadata") or {},
                        }
                    )

            elif mtype == "error":
                tb = content.get("traceback") or []
                if on_item:
                    on_item({"type": "error", "traceback": "\n".join(tb)})
            elif mtype == "status":
                # Dla in-process kernela czasem execute_reply nie przychodzi (albo przychodzi
                # przed ostatnimi streamami). Najpewniejsze jest domknięcie wykonania na IOPub idle.
                if content.get("execution_state") == "idle":
                    on_done = h.get("on_done")
                    if on_done:
                        try:
                            on_done()
                        except TypeError:
                            try:
                                on_done(content)
                            except Exception:
                                pass
                        except Exception:
                            pass
                    self._handlers.pop(msg_id, None)

            # status/idle obsługujemy w shell execute_reply (fallback)


    def _poll_exec_shell(self):
        if not self._exec_kc:
            return

        while True:
            try:
                msg = self._exec_kc.get_shell_msg(timeout=0)
            except Empty:
                break
            except Exception:
                break

            parent = (msg.get("parent_header") or {})
            msg_id = parent.get("msg_id")
            if not msg_id or msg_id not in self._handlers:
                continue

            h = self._handlers.get(msg_id) or {}
            on_done = h.get("on_done")
            mtype = msg.get("msg_type")
            content = msg.get("content") or {}

            if mtype == "execute_reply":
                if on_done:
                    try:
                        on_done(content)
                    except TypeError:
                        try:
                            on_done()
                        except Exception:
                            pass
                    except Exception:
                        pass
                self._handlers.pop(msg_id, None)
