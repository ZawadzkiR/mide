from __future__ import annotations

import ast
from dataclasses import dataclass


@dataclass
class Diagnostic:
    line: int
    col: int
    message: str
    severity: str = "error"


def diagnostics_from_syntax(code: str) -> list[Diagnostic]:
    try:
        ast.parse(code)
        return []
    except SyntaxError as e:
        line = int(getattr(e, "lineno", 1) or 1)
        col = int(getattr(e, "offset", 1) or 1)
        msg = getattr(e, "msg", "SyntaxError")
        return [Diagnostic(line=line, col=col, message=msg, severity="error")]
