from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Dict, List, Optional

from PySide6.QtCore import QSettings


@dataclass
class Settings:
    autocomplete: bool = True


class SettingsService:
    """Trwałe ustawienia aplikacji (QSettings).

    W tej iteracji dodajemy obsługę "środowisk" uruchomieniowych:
    - Python kernel (wbudowany in-process) – zawsze dostępny
    - Python zewnętrzny (ścieżka do python.exe / python)
    - R (ścieżka do Rscript)
    """

    ORG = "FutIDE"
    APP = "FutIDE"

    KEY_ENVS = "environments.v1"              # JSON list
    KEY_SELECTED_PY = "env.selected.python"   # key
    KEY_SELECTED_R = "env.selected.r"         # key
    KEY_THEME = "appearance.theme"

    def __init__(self):
        self.settings = Settings()
        self._qs = QSettings(self.ORG, self.APP)

    # ---------------- generic get/set ----------------

    def get(self, key: str, default=None):
        try:
            v = self._qs.value(key, default)
            return default if v is None else v
        except Exception:
            return default

    def set(self, key: str, value):
        try:
            self._qs.setValue(key, value)
            try:
                self._qs.sync()
            except Exception:
                pass
        except Exception:
            pass

    # ---------------- environments ----------------

    def default_environments(self) -> List[Dict]:
        return [
            {
                "key": "python:kernel",
                "kind": "python-kernel",
                "name": "Python (Kernel)",
                "path": "",
            }
        ]

    def load_environments(self) -> List[Dict]:
        raw = self._qs.value(self.KEY_ENVS, "")
        if raw is None or raw == "":
            return self.default_environments()

        # QSettings na Windows potrafi zwrócić różne typy (str, QByteArray, list)
        if isinstance(raw, (bytes, bytearray)):
            try:
                raw = raw.decode("utf-8", errors="replace")
            except Exception:
                raw = str(raw)

        try:
            if isinstance(raw, list):
                envs = raw
            else:
                envs = json.loads(str(raw))
            if not isinstance(envs, list):
                return self.default_environments()
            # dołóż kernel, jeśli ktoś skasował
            if not any((e or {}).get("key") == "python:kernel" for e in envs):
                envs = self.default_environments() + envs
            return envs
        except Exception:
            return self.default_environments()

    def save_environments(self, envs: List[Dict]):
        envs = list(envs or [])
        if not any((e or {}).get("key") == "python:kernel" for e in envs):
            envs = self.default_environments() + envs
        self._qs.setValue(self.KEY_ENVS, json.dumps(envs, ensure_ascii=False))
        try:
            self._qs.sync()
        except Exception:
            pass

    def get_selected_python_env_key(self) -> str:
        return str(self._qs.value(self.KEY_SELECTED_PY, "python:kernel") or "python:kernel")

    def set_selected_python_env_key(self, key: str):
        if key:
            self._qs.setValue(self.KEY_SELECTED_PY, key)

    def get_selected_r_env_key(self) -> str:
        return str(self._qs.value(self.KEY_SELECTED_R, "") or "")

    def set_selected_r_env_key(self, key: str):
        if key is not None:
            self._qs.setValue(self.KEY_SELECTED_R, key)

    def find_env(self, key: str) -> Optional[Dict]:
        for e in self.load_environments():
            if (e or {}).get("key") == key:
                return e
        return None
