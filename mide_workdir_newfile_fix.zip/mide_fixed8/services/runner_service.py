from __future__ import annotations

import os
import tempfile
from typing import Callable, Optional, Dict

from PySide6.QtCore import QObject, QProcess, QProcessEnvironment, QThread, Signal

from services.jupyterhub_client import JupyterHubClient, JupyterHubEnv


class _JupyterHubRunWorker(QObject):
    """Wykonuje kod na zdalnym JupyterHub w tle."""

    def __init__(self, env: JupyterHubEnv, code: str):
        super().__init__()
        self.env = env
        self.code = code
        self._stop = False

    def stop(self):
        self._stop = True

    def should_stop(self) -> bool:
        return bool(self._stop)

    def run(self, on_text: Callable[[str], None]) -> int:
        client = JupyterHubClient(self.env)
        client.start_user_server()
        client.wait_user_ready()
        kernel_id = client.create_kernel()
        on_text(f"[JupyterHub] kernel: {kernel_id}\n")
        try:
            rc = client.exec_code_stream(kernel_id, self.code, on_text, stop_flag=self.should_stop)
        finally:
            client.delete_kernel(kernel_id)
        return int(rc)



class RunnerService(QObject):
    """Uruchamianie kodu przez zewnętrzne interpretery (Python / R).

    Strumieniowo przekazuje stdout/stderr przez callback `on_text`.
    Obsługuje dodatkowy PYTHONPATH (np. dla pseudo-venv).
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._process: Optional[QProcess] = None
        self._temp_file: Optional[str] = None
        # remote worker
        self._jh_thread: Optional[QThread] = None
        self._jh_worker: Optional[_JupyterHubRunWorker] = None

    def is_running(self) -> bool:
        local = self._process is not None and self._process.state() != QProcess.NotRunning
        remote = self._jh_thread is not None and self._jh_thread.isRunning()
        return bool(local or remote)

    def terminate(self):
        if self._process and self._process.state() != QProcess.NotRunning:
            self._process.kill()
        if self._jh_worker is not None:
            try:
                self._jh_worker.stop()
            except Exception:
                pass

    # ---------------- R ----------------

    def _resolve_rscript(self, path: str) -> str:
        """Akceptuje Rscript.exe albo R.exe (Windows) i zwraca ścieżkę do Rscript."""
        if not path:
            return "Rscript"

        p = os.path.abspath(path)

        base = os.path.basename(p).lower()
        if base == "r.exe":
            cand = os.path.join(os.path.dirname(p), "Rscript.exe")
            if os.path.exists(cand):
                return cand
            cand2 = os.path.join(os.path.dirname(p), "x64", "Rscript.exe")
            if os.path.exists(cand2):
                return cand2
            return p

        return p

    def run_r_file(
        self,
        r_path: str,
        file_path: str,
        on_text: Callable[[str], None],
        on_finished: Optional[Callable[[int], None]] = None,
    ) -> bool:
        program = self._resolve_rscript(r_path)
        if not program:
            program = "Rscript"

        if os.path.basename(program).lower() == "r.exe":
            return self._start([program, "CMD", "BATCH", "--no-save", "--no-restore", file_path], on_text, on_finished)

        return self._start([program, file_path], on_text, on_finished)

    def run_r_code(
        self,
        r_path: str,
        code: str,
        on_text: Callable[[str], None],
        on_finished: Optional[Callable[[int], None]] = None,
    ) -> bool:
        fd, tmp = tempfile.mkstemp(prefix="futide_run_", suffix=".R")
        os.close(fd)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(code or "")

        self._temp_file = tmp
        return self.run_r_file(r_path, tmp, on_text, on_finished)

    # ---------------- Python ----------------

    def run_python_file(
        self,
        python_path: str,
        file_path: str,
        on_text: Callable[[str], None],
        on_finished: Optional[Callable[[int], None]] = None,
        extra_pythonpath: Optional[str] = None,
        workdir: Optional[str] = None,
    ) -> bool:
        if not python_path:
            return False
        env = self._make_env(extra_pythonpath)
        return self._start([python_path, "-u", file_path], on_text, on_finished, env=env, workdir=workdir)

    def run_python_code(
        self,
        python_path: str,
        code: str,
        on_text: Callable[[str], None],
        on_finished: Optional[Callable[[int], None]] = None,
        extra_pythonpath: Optional[str] = None,
        workdir: Optional[str] = None,
    ) -> bool:
        if not python_path:
            return False

        fd, tmp = tempfile.mkstemp(prefix="futide_run_", suffix=".py")
        os.close(fd)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(code or "")

        self._temp_file = tmp
        env = self._make_env(extra_pythonpath)
        return self._start([python_path, "-u", tmp], on_text, on_finished, env=env, workdir=workdir)

    # ---------------- JupyterHub (remote) ----------------

    def run_jupyterhub_code(
        self,
        hub_url: str,
        user: str,
        token: str,
        kernel_name: str,
        code: str,
        on_text: Callable[[str], None],
        on_finished: Optional[Callable[[int], None]] = None,
    ) -> bool:
        if self.is_running():
            on_text("[Runner] Process is already running.\n")
            return False

        env = JupyterHubEnv(
            hub_url=str(hub_url or "").strip(),
            user=str(user or "").strip(),
            token=str(token or "").strip(),
            kernel_name=str(kernel_name or "").strip(),
        )
        if not env.hub_url or not env.user or not env.token:
            on_text("[JupyterHub] Missing hub_url / user / token.\n")
            return False

        worker = _JupyterHubRunWorker(env, code)
        # Do not parent QThread if we also deleteLater() it (prevents double-delete warnings/crashes).
        thread = QThread()
        worker.moveToThread(thread)

        def _run():
            rc = 1
            try:
                rc = worker.run(on_text)
            except Exception as e:
                on_text(f"[JupyterHub] Error: {e}\n")
                rc = 1
            if on_finished:
                on_finished(int(rc))
            # cleanup
            try:
                thread.quit()
            except Exception:
                pass

        thread.started.connect(_run)

        def _cleanup():
            self._jh_thread = None
            self._jh_worker = None

        thread.finished.connect(_cleanup)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(worker.deleteLater)

        self._jh_thread = thread
        self._jh_worker = worker
        thread.start()
        return True

    # ---------------- internals ----------------

    def _make_env(self, extra_pythonpath: Optional[str]) -> Optional[QProcessEnvironment]:
        extra_pythonpath = (extra_pythonpath or "").strip()
        if not extra_pythonpath:
            return None

        # Dołóż do istniejącego PYTHONPATH.
        pe = QProcessEnvironment.systemEnvironment()
        cur = pe.value("PYTHONPATH")
        if cur:
            # Nie duplikuj, jeśli już jest.
            parts = cur.split(os.pathsep)
            if extra_pythonpath not in parts:
                pe.insert("PYTHONPATH", extra_pythonpath + os.pathsep + cur)
        else:
            pe.insert("PYTHONPATH", extra_pythonpath)
        return pe

    def _start(
        self,
        args: list[str],
        on_text: Callable[[str], None],
        on_finished: Optional[Callable[[int], None]],
        env: Optional[QProcessEnvironment] = None,
        workdir: Optional[str] = None,
    ) -> bool:
        if self.is_running():
            on_text("[Runner] Process is already running.\n")
            return False

        p = QProcess(self)
        p.setProcessChannelMode(QProcess.MergedChannels)
        if env is not None:
            p.setProcessEnvironment(env)
        if workdir:
            try:
                p.setWorkingDirectory(str(workdir))
            except Exception:
                pass

        def _on_ready():
            try:
                data = p.readAllStandardOutput().data()
            except Exception:
                data = b""
            if data:
                try:
                    on_text(data.decode("utf-8", errors="replace"))
                except Exception:
                    on_text(str(data))

        def _on_finished(code: int, _status):
            _on_ready()
            self._cleanup_temp()
            self._process = None
            if on_finished:
                on_finished(int(code))

        p.readyReadStandardOutput.connect(_on_ready)
        p.finished.connect(_on_finished)

        self._process = p
        p.start(args[0], args[1:])
        if not p.waitForStarted(3000):
            self._process = None
            self._cleanup_temp()
            on_text("[Runner] Failed to start process.\n")
            return False

        return True

    def _cleanup_temp(self):
        if self._temp_file:
            try:
                os.remove(self._temp_file)
            except Exception:
                pass
            self._temp_file = None
