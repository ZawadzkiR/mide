from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import Qt, Signal, QEvent, QObject, QThread
from PySide6.QtGui import QFont, QIcon
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton,
    QTabWidget, QTableWidget, QTableWidgetItem, QMessageBox,
    QSpinBox, QLineEdit, QToolButton, QProgressBar, QStyle
)

from services.db_service import DbService, DbConnection
from services.db_runtime import DbRuntime, CancelToken
from ui.editors.sql_editor import SqlEditor


class _QueryWorker(QObject):
    finished = Signal(object)      # QueryResult
    failed = Signal(str)           # error text
    started = Signal()

    def __init__(self, runtime: DbRuntime, conn: DbConnection, sql: str, limit: int):
        super().__init__()
        self.runtime = runtime
        self.conn = conn
        self.sql = sql
        self.limit = int(limit)
        self.token = CancelToken()

    def run(self):
        self.started.emit()
        try:
            res = self.runtime.execute_cancellable(self.conn, self.sql, self.limit, self.token)
            self.finished.emit(res)
        except Exception as e:
            self.failed.emit(str(e))

    def cancel(self):
        self.token.cancel()


class SqlScreen(QWidget):
    """Ekran edytora SQL + wyniki.

    Zasada: aplikacja nie łączy się z bazą automatycznie. Użytkownik musi kliknąć Connect.
    """

    connectionSelected = Signal(str)   # conn_key (tylko wybór w combo)
    connectionConnected = Signal(str)  # conn_key (po Connect)
    connectionDisconnected = Signal(str)  # conn_key (po Disconnect)

    def __init__(self, db_service: DbService, parent=None):
        super().__init__(parent)
        self.db_service = db_service
        self.runtime = DbRuntime()

        self._connected_key: str = ""
        self._query_thread: QThread | None = None
        self._query_worker: _QueryWorker | None = None

        self.lbl = QLabel("Connection:")
        self.cmb = QComboBox()

        # definicje połączeń (tylko lista)
        self.btn_reload_defs = QPushButton("Reload list")
        self.btn_reload_defs.setToolTip("Reload saved connections list")

        # connect/disconnect/refresh (połączenie)
        self.btn_connect = QToolButton()
        self.btn_disconnect = QToolButton()
        self.btn_reconnect = QToolButton()

        st = self.style()
        self.btn_connect.setIcon(st.standardIcon(QStyle.SP_DialogApplyButton))
        self.btn_disconnect.setIcon(st.standardIcon(QStyle.SP_DialogCancelButton))
        self.btn_reconnect.setIcon(st.standardIcon(QStyle.SP_BrowserReload))

        self.btn_connect.setToolTip("Connect")
        self.btn_disconnect.setToolTip("Disconnect")
        self.btn_reconnect.setToolTip("Refresh connection (reconnect)")

        self.btn_disconnect.setEnabled(False)
        self.btn_reconnect.setEnabled(False)

        self.limit = QSpinBox()
        self.limit.setRange(0, 1_000_000)
        self.limit.setValue(0)
        self.limit.setToolTip("0 = no limit")

        self.btn_run = QToolButton()
        self.btn_stop = QToolButton()

        self.btn_run.setIcon(st.standardIcon(QStyle.SP_MediaPlay))
        self.btn_stop.setIcon(st.standardIcon(QStyle.SP_BrowserStop))
        self.btn_run.setToolTip("Run (Ctrl+Enter)")
        self.btn_stop.setToolTip("Stop query")

        self.btn_stop.setEnabled(False)

        self.btn_export_csv = QPushButton("Export CSV")
        self.btn_export_xlsx = QPushButton("Export XLSX")

        # indeterminate progress
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        self.progress.setMaximumHeight(10)

        top = QHBoxLayout()
        top.setContentsMargins(10, 8, 10, 8)
        top.setSpacing(8)
        top.addWidget(self.lbl)
        top.addWidget(self.cmb, 1)
        top.addWidget(self.btn_reload_defs)
        top.addWidget(self.btn_connect)
        top.addWidget(self.btn_disconnect)
        top.addWidget(self.btn_reconnect)
        top.addSpacing(10)
        top.addWidget(QLabel("Limit:"))
        top.addWidget(self.limit)
        top.addWidget(self.btn_run)
        top.addWidget(self.btn_stop)
        top.addWidget(self.btn_export_csv)
        top.addWidget(self.btn_export_xlsx)

        self.editor = SqlEditor()
        self.editor.setFont(QFont("Consolas", 11))
        self.editor.setPlaceholderText("Write SQL here... (Ctrl+Enter to run)")

        # SQL syntax highlighting
        try:
            from ui.syntax.sql_highlighter import SqlHighlighter
            self._hl = SqlHighlighter(self.editor.document())
        except Exception:
            self._hl = None

        self.results = QTabWidget()
        self.results.setTabsClosable(True)
        self.results.tabCloseRequested.connect(self.results.removeTab)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        lay.addLayout(top)
        lay.addWidget(self.progress, 0)
        lay.addWidget(self.editor, 3)
        lay.addWidget(self.results, 2)

        self.btn_reload_defs.clicked.connect(self.reload_connections)
        self.btn_connect.clicked.connect(self.connect_current)
        self.btn_disconnect.clicked.connect(self.disconnect_current)
        self.btn_reconnect.clicked.connect(self.reconnect_current)
        self.btn_run.clicked.connect(self.run_sql)
        self.btn_stop.clicked.connect(self.stop_query)
        self.btn_export_csv.clicked.connect(self.export_current_to_csv)
        self.btn_export_xlsx.clicked.connect(self.export_current_to_xlsx)
        self.cmb.currentIndexChanged.connect(self._on_selected_changed)

        # Ctrl+Enter
        self.editor.installEventFilter(self)

        self.reload_connections()

    # ---------------- keyboard ----------------

    def eventFilter(self, obj, event):
        if obj is self.editor and event.type() == QEvent.Type.KeyPress:
            if event.key() in (Qt.Key_Return, Qt.Key_Enter) and (event.modifiers() & Qt.ControlModifier):
                self.run_sql()
                return True
        return super().eventFilter(obj, event)

    # ---------------- connections ----------------

    def reload_connections(self):
        # Only reload the list (no DB connects here)
        current = self.current_connection_key()
        self.cmb.blockSignals(True)
        self.cmb.clear()
        conns = self.db_service.load_connections()
        for c in conns:
            self.cmb.addItem(f"{c.name} ({c.kind})", c.key)
        self.cmb.blockSignals(False)

        # restore selected
        sel = current or self.db_service.get_selected_key()
        if sel:
            idx = self.cmb.findData(sel)
            if idx >= 0:
                self.cmb.setCurrentIndex(idx)

        self._on_selected_changed()

    def current_connection_key(self) -> str:
        return str(self.cmb.currentData() or "")

    def current_connection(self) -> DbConnection | None:
        key = self.current_connection_key()
        return self.db_service.find(key) if key else None

    def is_connected(self) -> bool:
        return bool(self._connected_key) and self._connected_key == self.current_connection_key()

    def _on_selected_changed(self):
        key = self.current_connection_key()
        if key:
            self.db_service.set_selected_key(key)
        self.connectionSelected.emit(key)

        # If user changes selection while connected to another, keep connection state but disable actions.
        self._sync_conn_buttons()
        if not self.is_connected():
            # do not run DB introspection automatically
            self.editor.set_catalog_items([])

    def _sync_conn_buttons(self):
        key = self.current_connection_key()
        connected = bool(self._connected_key) and self._connected_key == key
        self.btn_connect.setEnabled(bool(key) and not connected)
        self.btn_disconnect.setEnabled(connected)
        self.btn_reconnect.setEnabled(connected)

    def connect_current(self):
        conn = self.current_connection()
        if not conn:
            QMessageBox.warning(self, "SQL", "No connection selected.")
            return
        ok, msg = self.runtime.test_connection(conn)
        if not ok:
            QMessageBox.warning(self, "SQL", f"Connect failed:\n\n{msg}")
            return

        self._connected_key = conn.key
        self.update_autocomplete_catalog(conn.key)
        self._sync_conn_buttons()
        self.connectionConnected.emit(conn.key)

    def disconnect_current(self):
        if not self._connected_key:
            return
        key = self._connected_key
        self._connected_key = ""
        self.editor.set_catalog_items([])
        self._sync_conn_buttons()
        self.connectionDisconnected.emit(key)

    def reconnect_current(self):
        if not self._connected_key:
            return
        key = self._connected_key
        self.disconnect_current()
        # reconnect to the same key if still selected
        if self.current_connection_key() != key:
            # user changed selection meanwhile
            self.cmb.setCurrentIndex(self.cmb.findData(key))
        self.connect_current()

    def update_autocomplete_catalog(self, conn_key: str):
        # Only if the user explicitly connected.
        if not conn_key or conn_key != self._connected_key:
            self.editor.set_catalog_items([])
            return
        conn = self.db_service.find(conn_key)
        if not conn:
            self.editor.set_catalog_items([])
            return
        items = []
        try:
            kind = (conn.kind or "").lower()
            if kind in ("oracle", "oracledb"):
                schemas = self.runtime.list_schemas(conn)
                items.extend([s for s in schemas if s])
            else:
                objs = self.runtime.list_objects(conn) or {}
                for grp in ("tables", "views"):
                    for full in (objs.get(grp) or []):
                        if not full:
                            continue
                        items.append(full)
                        if "." in full:
                            items.append(full.split(".", 1)[1])
        except Exception:
            pass
        self.editor.set_catalog_items(items)

    # ---------------- query execution ----------------

    def _set_query_running(self, running: bool):
        self.progress.setVisible(running)
        self.btn_stop.setEnabled(running)
        self.btn_run.setEnabled(not running)
        self.btn_connect.setEnabled(not running and self.btn_connect.isEnabled())
        self.btn_disconnect.setEnabled(not running and self.btn_disconnect.isEnabled())
        self.btn_reconnect.setEnabled(not running and self.btn_reconnect.isEnabled())

    def run_sql(self):
        if self._query_thread is not None:
            return  # already running

        if not self.is_connected():
            QMessageBox.warning(self, "SQL", "Not connected. Click Connect first.")
            return

        conn = self.current_connection()
        if not conn:
            QMessageBox.warning(self, "SQL", "No connection selected.")
            return

        sql = self.editor.textCursor().selectedText()
        if not sql.strip():
            sql = self.editor.toPlainText()

        if not sql.strip():
            return

        worker = _QueryWorker(self.runtime, conn, sql, int(self.limit.value()))
        # Do not parent QThread if we also use deleteLater() to avoid double-deletion.
        thread = QThread()
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.started.connect(lambda: self._set_query_running(True))
        worker.finished.connect(self._on_query_finished)
        worker.failed.connect(self._on_query_failed)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._on_query_thread_finished)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(worker.deleteLater)

        self._query_thread = thread
        self._query_worker = worker
        thread.start()

    def stop_query(self):
        if self._query_worker is not None:
            self._query_worker.cancel()

        # Try to gracefully stop the thread; never clear references until it finishes.
        th = self._query_thread
        if th is None:
            return
        try:
            if th.isRunning():
                th.requestInterruption()
        except Exception:
            pass
        try:
            if th.isRunning():
                th.quit()
        except Exception:
            pass

    def _cleanup_query_ui(self):
        self._set_query_running(False)

    def _on_query_thread_finished(self):
        # Clear references only when thread is actually finished.
        self._query_thread = None
        self._query_worker = None
        self._set_query_running(False)

    def _on_query_finished(self, res):
        self._cleanup_query_ui()
        self._add_result_tab(res)

    def _on_query_failed(self, msg: str):
        self._cleanup_query_ui()
        QMessageBox.warning(self, "SQL", f"Query failed:\n\n{msg}")

    # ---------------- previews ----------------

    def preview_table(self, conn_key: str, schema: str, table: str, limit: int = 200):
        if not self._connected_key or self._connected_key != conn_key:
            # keep behavior consistent: don't auto-connect
            return
        conn = self.db_service.find(conn_key)
        if not conn:
            return
        sql = self.runtime.build_table_preview_sql(conn, table=table, schema=(schema or None), limit=int(limit))
        self._run_preview(conn, sql, title=f"Preview: {schema+'.' if schema else ''}{table}", limit=limit)

    def run_table_top(self, conn_key: str, full_name: str, limit: int):
        if not self._connected_key or self._connected_key != conn_key:
            return
        conn = self.db_service.find(conn_key)
        if not conn:
            return
        schema = ""
        table = full_name
        if "." in full_name:
            schema, table = full_name.split(".", 1)
        sql = self.runtime.build_table_preview_sql(conn, table=table, schema=(schema or None), limit=int(limit))
        title = f"{full_name} ({'no limit' if int(limit)<=0 else 'top '+str(limit)})"
        self._run_preview(conn, sql, title=title, limit=limit)

    def _run_preview(self, conn: DbConnection, sql: str, title: str, limit: int):
        # preview uses the same async executor but is read-only; if a query is already running, ignore.
        if self._query_thread is not None:
            return
        worker = _QueryWorker(self.runtime, conn, sql, int(limit))
        # Do not parent QThread if we also use deleteLater() to avoid double-deletion.
        thread = QThread()
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.started.connect(lambda: self._set_query_running(True))
        worker.finished.connect(lambda res: self._on_preview_finished(res, title))
        worker.failed.connect(self._on_query_failed)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._on_query_thread_finished)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(worker.deleteLater)

        self._query_thread = thread
        self._query_worker = worker
        thread.start()

    def _on_preview_finished(self, res, title: str):
        self._cleanup_query_ui()
        self._add_result_tab(res, title=title)

    # ---------------- exporting ----------------

    def current_result_table(self):
        w = self.results.currentWidget()
        if not w:
            return None
        return getattr(w, "tbl", None)

    def export_current_to_csv(self):
        tbl = self.current_result_table()
        if tbl is None:
            QMessageBox.information(self, "SQL", "No result tab selected.")
            return
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(self, "Export to CSV", "result.csv", "CSV Files (*.csv)")
        if not path:
            return
        try:
            import csv
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                headers = [tbl.horizontalHeaderItem(c).text() if tbl.horizontalHeaderItem(c) else "" for c in range(tbl.columnCount())]
                w.writerow(headers)
                for r in range(tbl.rowCount()):
                    row = []
                    for c in range(tbl.columnCount()):
                        it = tbl.item(r, c)
                        row.append("" if it is None else it.text())
                    w.writerow(row)
        except Exception as e:
            QMessageBox.warning(self, "SQL", f"Export failed:\n\n{e}")
            return
        QMessageBox.information(self, "SQL", f"Exported to:\n{path}")

    def export_current_to_xlsx(self):
        tbl = self.current_result_table()
        if tbl is None:
            QMessageBox.information(self, "SQL", "No result tab selected.")
            return
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(self, "Export to XLSX", "result.xlsx", "Excel Files (*.xlsx)")
        if not path:
            return
        try:
            from openpyxl import Workbook
            wb = Workbook()
            ws = wb.active
            ws.title = "Result"
            headers = [tbl.horizontalHeaderItem(c).text() if tbl.horizontalHeaderItem(c) else "" for c in range(tbl.columnCount())]
            ws.append(headers)
            for r in range(tbl.rowCount()):
                ws.append([tbl.item(r, c).text() if tbl.item(r, c) else "" for c in range(tbl.columnCount())])
            wb.save(path)
        except Exception as e:
            QMessageBox.warning(self, "SQL", f"Export failed:\n\n{e}")
            return
        QMessageBox.information(self, "SQL", f"Exported to:\n{path}")

    # ---------------- results tabs ----------------

    def _add_result_tab(self, res, title: str | None = None):
        w = _ResultTabWidget(res)
        if not title:
            title = f"Result {self.results.count()+1}"
        self.results.addTab(w, title)
        self.results.setCurrentWidget(w)


class _ResultTabWidget(QWidget):
    """Result tab with quick search (filters rows) like SQL Developer."""

    def __init__(self, res):
        super().__init__()

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search in results...")
        self.btn_clear = QToolButton()
        self.btn_clear.setText("×")
        self.btn_clear.setCursor(Qt.PointingHandCursor)

        top = QHBoxLayout()
        top.setContentsMargins(6, 6, 6, 0)
        top.setSpacing(6)
        top.addWidget(QLabel("Find:"))
        top.addWidget(self.search, 1)
        top.addWidget(self.btn_clear)

        self.tbl = QTableWidget()
        self.tbl.setColumnCount(len(res.columns))
        self.tbl.setRowCount(len(res.rows))
        self.tbl.setHorizontalHeaderLabels([str(c) for c in res.columns])
        self.tbl.setSortingEnabled(True)

        # fill
        for r, row in enumerate(res.rows):
            for c, val in enumerate(row):
                it = QTableWidgetItem("" if val is None else str(val))
                self.tbl.setItem(r, c, it)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        lay.addLayout(top)
        lay.addWidget(self.tbl, 1)

        self._all_rows = res.rows
        self._all_cols = res.columns

        self.search.textChanged.connect(self._apply_filter)
        self.btn_clear.clicked.connect(lambda: self.search.setText(""))

    def _apply_filter(self, text: str):
        q = (text or "").lower().strip()
        if not q:
            self._rebuild(self._all_cols, self._all_rows)
            return
        # naive filter over stringified cells
        out = []
        for row in self._all_rows:
            for v in row:
                if v is None:
                    continue
                if q in str(v).lower():
                    out.append(row)
                    break
        self._rebuild(self._all_cols, out)

    def _rebuild(self, cols, rows):
        self.tbl.setSortingEnabled(False)
        self.tbl.clear()
        self.tbl.setColumnCount(len(cols))
        self.tbl.setRowCount(len(rows))
        self.tbl.setHorizontalHeaderLabels([str(c) for c in cols])
        for r, row in enumerate(rows):
            for c, val in enumerate(row):
                self.tbl.setItem(r, c, QTableWidgetItem("" if val is None else str(val)))
        self.tbl.setSortingEnabled(True)
