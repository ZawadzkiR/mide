# ui/widgets/command_palette.py
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QDialog, QVBoxLayout, QLineEdit, QListWidget, QListWidgetItem


class CommandPalette(QDialog):
    """
    Prosty Command Palette:
    - filtruje listę komend (QActions) po nazwie
    - Enter uruchamia zaznaczoną
    """
    run_action = Signal(object)  # QAction

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Command Palette")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setModal(True)
        self.resize(720, 360)

        self.input = QLineEdit()
        self.input.setPlaceholderText("Type a command...")
        self.list = QListWidget()

        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(10)
        lay.addWidget(self.input)
        lay.addWidget(self.list, 1)

        self._actions: list[object] = []  # QAction list
        self._filtered: list[object] = []

        self.input.textChanged.connect(self._filter)
        self.list.itemActivated.connect(self._activate_current)

        self.setStyleSheet("""
            QDialog { background: #070b14; border: 1px solid #1b2a4a; border-radius: 14px; }
            QLineEdit { background: #050812; border: 1px solid #1b2a4a; border-radius: 10px; padding: 10px; }
            QListWidget { background: #050812; border: 1px solid #1b2a4a; border-radius: 10px; padding: 6px; }
            QListWidget::item { padding: 8px; border-radius: 8px; color: #e6f1ff; }
            QListWidget::item:selected { background: #132042; border: 1px solid #2b5cff; }
        """)

    def set_actions(self, actions: list[object]):
        self._actions = [a for a in actions if getattr(a, "text", lambda: "")()]
        self._filter()

    def open_palette(self):
        self.input.setText("")
        self._filter()
        self.input.setFocus()
        self.exec()

    def _filter(self):
        q = (self.input.text() or "").strip().lower()

        def score(a):
            t = a.text().replace("&", "")
            tl = t.lower()
            if not q:
                return 0
            if tl.startswith(q):
                return 0
            if q in tl:
                return 1
            return 2

        acts = sorted(self._actions, key=score)
        if q:
            acts = [a for a in acts if q in a.text().lower()]

        self._filtered = acts[:250]

        self.list.clear()
        for a in self._filtered:
            it = QListWidgetItem(a.text().replace("&", ""))
            it.setData(Qt.UserRole, a)
            self.list.addItem(it)

        if self.list.count() > 0:
            self.list.setCurrentRow(0)

    def _activate_current(self, item: QListWidgetItem):
        act = item.data(Qt.UserRole)
        if act:
            self.run_action.emit(act)
        self.accept()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.reject()
            return
        if e.key() in (Qt.Key_Return, Qt.Key_Enter):
            it = self.list.currentItem()
            if it:
                self._activate_current(it)
            return
        super().keyPressEvent(e)
