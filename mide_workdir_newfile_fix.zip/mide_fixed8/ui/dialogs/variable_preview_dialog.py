from __future__ import annotations

import html
from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex, QSortFilterProxyModel
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QTabWidget, QTextBrowser, QWidget,
    QTableView, QHBoxLayout, QLineEdit, QCheckBox, QComboBox, QLabel, QToolButton,
    QStyle
)


class _SimpleTableModel(QAbstractTableModel):
    """Lightweight model for displaying 2D data (list of rows)."""

    def __init__(self, columns: list[str], rows: list[list[object]]):
        super().__init__()
        self._cols = columns
        self._rows = rows

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._cols)

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole):  # noqa: N802
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            if 0 <= section < len(self._cols):
                return self._cols[section]
        return str(section)

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):  # noqa: N802
        if not index.isValid():
            return None
        r = index.row()
        c = index.column()
        if r < 0 or r >= len(self._rows) or c < 0 or c >= len(self._cols):
            return None

        v = self._rows[r][c]
        if role in (Qt.DisplayRole, Qt.ToolTipRole):
            if v is None:
                return ""
            s = str(v)
            # do not flood UI
            if len(s) > 500:
                s = s[:500] + "…"
            return s
        return None


class _AllColumnsFilterProxy(QSortFilterProxyModel):
    """Proxy that can filter across all columns or a selected column."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._filter_all = True

    def set_filter_all_columns(self, on: bool):
        self._filter_all = bool(on)
        self.invalidateFilter()

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:  # noqa: N802
        # if filterKeyColumn() is not -1, default implementation is fine
        if not self._filter_all or self.filterKeyColumn() != -1:
            return super().filterAcceptsRow(source_row, source_parent)

        rx = self.filterRegularExpression()
        if rx.pattern() == "":
            return True

        model = self.sourceModel()
        if model is None:
            return True
        cols = model.columnCount()
        for c in range(cols):
            idx = model.index(source_row, c, source_parent)
            txt = str(model.data(idx, Qt.DisplayRole) or "")
            if rx.match(txt).hasMatch():
                return True
        return False


class VariablePreviewDialog(QDialog):
    def __init__(self, name: str, vtype: str, payload: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Variable: {name} ({vtype})")
        self.resize(1000, 650)

        tabs = QTabWidget()

        # payload can include: repr, df (columns, rows), html
        rep = payload.get("repr", "")
        if rep:
            tb = QTextBrowser()
            tb.setOpenExternalLinks(False)
            tb.setFont(QFont("Consolas", 10))
            tb.setPlainText(rep)
            tabs.addTab(tb, "Preview")

        # DataFrame table (preferred) - with search/filter/sort
        df = payload.get("df")
        if isinstance(df, dict) and df.get("columns") and isinstance(df.get("rows"), list):
            w = QWidget()
            lay = QVBoxLayout(w)
            lay.setContentsMargins(6, 6, 6, 6)
            lay.setSpacing(6)

            # Controls
            ctrl = QHBoxLayout()
            ctrl.setContentsMargins(0, 0, 0, 0)
            ctrl.setSpacing(6)

            lbl = QLabel("Search:")
            txt = QLineEdit()
            txt.setPlaceholderText("substring / regex")

            chk_regex = QCheckBox("Regex")
            chk_case = QCheckBox("Case")

            cmb = QComboBox()
            cmb.addItem("All columns", -1)
            for c in df.get("columns") or []:
                cmb.addItem(str(c), str(c))

            btn_clear = QToolButton()
            btn_clear.setIcon(self.style().standardIcon(QStyle.SP_DialogResetButton))
            btn_clear.setToolTip("Clear search")

            ctrl.addWidget(lbl, 0)
            ctrl.addWidget(txt, 1)
            ctrl.addWidget(cmb, 0)
            ctrl.addWidget(chk_regex, 0)
            ctrl.addWidget(chk_case, 0)
            ctrl.addWidget(btn_clear, 0)
            lay.addLayout(ctrl)

            # Table
            cols = [str(c) for c in (df.get("columns") or [])]
            rows = df.get("rows") or []

            model = _SimpleTableModel(cols, rows)
            proxy = _AllColumnsFilterProxy(w)
            proxy.setSourceModel(model)
            proxy.setDynamicSortFilter(True)
            proxy.setFilterKeyColumn(-1)
            proxy.set_filter_all_columns(True)

            view = QTableView(w)
            view.setModel(proxy)
            view.setSortingEnabled(True)
            view.setAlternatingRowColors(True)
            view.setSelectionBehavior(QTableView.SelectRows)
            view.setSelectionMode(QTableView.SingleSelection)
            view.horizontalHeader().setStretchLastSection(True)
            view.resizeColumnsToContents()
            lay.addWidget(view, 1)

            def _apply():
                pattern = txt.text() or ""
                proxy.setFilterCaseSensitivity(Qt.CaseSensitive if chk_case.isChecked() else Qt.CaseInsensitive)
                if chk_regex.isChecked():
                    proxy.setFilterRegularExpression(pattern)
                else:
                    # escape so it's treated as a substring match
                    import re

                    proxy.setFilterRegularExpression(re.escape(pattern))

            def _col_changed():
                key = cmb.currentData()
                if key == -1:
                    proxy.setFilterKeyColumn(-1)
                    proxy.set_filter_all_columns(True)
                else:
                    # map displayed column name to index
                    col_name = cmb.currentText()
                    try:
                        idx = cols.index(col_name)
                    except Exception:
                        idx = -1
                    proxy.setFilterKeyColumn(idx)
                    proxy.set_filter_all_columns(False)
                _apply()

            txt.textChanged.connect(_apply)
            chk_regex.toggled.connect(_apply)
            chk_case.toggled.connect(_apply)
            cmb.currentIndexChanged.connect(_col_changed)
            btn_clear.clicked.connect(lambda: txt.setText(""))

            tabs.addTab(w, "Data")

        # HTML fallback
        h = payload.get("html")
        if isinstance(h, str) and h.strip():
            tb2 = QTextBrowser()
            tb2.setHtml(h)
            tabs.addTab(tb2, "HTML")

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.addWidget(tabs, 1)
