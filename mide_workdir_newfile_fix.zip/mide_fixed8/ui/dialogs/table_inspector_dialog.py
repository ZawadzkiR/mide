from __future__ import annotations

from PySide6.QtCore import Qt, QThread, QObject, Signal
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QTabWidget, QMessageBox, QSplitter, QWidget, QProgressBar, QToolButton, QStyle
)

from services.db_service import DbConnection
from services.db_runtime import DbRuntime, CancelToken, TableColumn


class _InspectWorker(QObject):
    finished = Signal(object, object)  # (columns: list[TableColumn], preview: QueryResult)
    failed = Signal(str)
    started = Signal()

    def __init__(self, runtime: DbRuntime, conn: DbConnection, schema: str, table: str):
        super().__init__()
        self.runtime = runtime
        self.conn = conn
        self.schema = schema or ""
        self.table = table
        self.token = CancelToken()

    def run(self):
        self.started.emit()
        try:
            cols = self.runtime.describe_table(self.conn, self.table, schema=(self.schema or None))
            sql = self.runtime.build_table_preview_sql(self.conn, table=self.table, schema=(self.schema or None), limit=1000)
            preview = self.runtime.execute_cancellable(self.conn, sql, 1000, self.token)
            self.finished.emit(cols, preview)
        except Exception as e:
            self.failed.emit(str(e))

    def cancel(self):
        self.token.cancel()


class TableInspectorDialog(QDialog):
    def __init__(self, runtime: DbRuntime, conn: DbConnection, schema: str, table: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Look table: {schema + '.' if schema else ''}{table}")
        self.resize(1100, 700)

        self.runtime = runtime
        self.conn = conn
        self.schema = schema or ""
        self.table = table

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        self.progress.setMaximumHeight(10)

        self.btn_stop = QToolButton()
        self.btn_stop.setIcon(self.style().standardIcon(QStyle.SP_BrowserStop))
        self.btn_stop.setToolTip("Stop")
        self.btn_stop.setEnabled(False)

        top = QHBoxLayout()
        top.addWidget(QLabel("Loading..."), 0)
        top.addStretch(1)
        top.addWidget(self.btn_stop, 0)

        self.tabs = QTabWidget()

        self.tbl_cols = QTableWidget()
        self.tbl_cols.setColumnCount(4)
        self.tbl_cols.setHorizontalHeaderLabels(["Column", "Type", "Nullable", "PK"])
        self.tbl_cols.verticalHeader().setVisible(False)

        self.tbl_rows = QTableWidget()
        self.tbl_rows.verticalHeader().setVisible(False)

        self.tabs.addTab(self.tbl_cols, "Columns")
        self.tabs.addTab(self.tbl_rows, "Rows (top 1000)")

        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)
        lay.addLayout(top)
        lay.addWidget(self.progress, 0)
        lay.addWidget(self.tabs, 1)

        self._thread: QThread | None = None
        self._worker: _InspectWorker | None = None

        self.btn_stop.clicked.connect(self._stop)

        self._start()

    def _start(self):
        worker = _InspectWorker(self.runtime, self.conn, self.schema, self.table)
        # Do not parent QThread if we also use deleteLater() to avoid double-deletion.
        thread = QThread()
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.started.connect(self._on_started)
        worker.finished.connect(self._on_finished)
        worker.failed.connect(self._on_failed)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._on_thread_finished)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(worker.deleteLater)

        self._thread = thread
        self._worker = worker
        thread.start()

    def _on_started(self):
        self.progress.setVisible(True)
        self.btn_stop.setEnabled(True)

    def _stop(self):
        if self._worker is not None:
            self._worker.cancel()

    def _stop_and_wait(self, timeout_ms: int = 2000):
        """Stop the running inspect job and wait for the QThread to finish.

        If the dialog gets closed while the background thread is still running,
        Qt can emit: "QThread: Destroyed while thread is still running" and the
        app may crash. We always attempt a graceful shutdown first, and only
        terminate as a last resort.
        """
        if self._worker is not None:
            try:
                self._worker.cancel()
            except Exception:
                pass

        th = self._thread
        if th is None:
            return

        try:
            if th.isRunning():
                th.requestInterruption()
        except Exception:
            pass

        try:
            if th.isRunning():
                th.quit()
        except Exception:
            pass

        try:
            if th.isRunning():
                th.wait(timeout_ms)
        except Exception:
            pass

        # Last resort: terminate to avoid fatal Qt error
        try:
            if th.isRunning():
                th.terminate()
                th.wait(1000)
        except Exception:
            pass

    def closeEvent(self, event):
        # Ensure no background thread is left running when the dialog closes
        self._stop_and_wait()
        super().closeEvent(event)

    def reject(self):
        self._stop_and_wait()
        super().reject()

    def _cleanup_ui(self):
        self.progress.setVisible(False)
        self.btn_stop.setEnabled(False)

    def _on_thread_finished(self):
        # Only clear references once the QThread is actually finished.
        self._thread = None
        self._worker = None

    def _on_failed(self, msg: str):
        self._cleanup_ui()
        QMessageBox.warning(self, "Look table", msg)

    def _on_finished(self, cols, preview):
        self._cleanup_ui()
        self._fill_columns(cols or [])
        self._fill_rows(preview)

    def _fill_columns(self, cols: list[TableColumn]):
        self.tbl_cols.setRowCount(len(cols))
        for r, c in enumerate(cols):
            self.tbl_cols.setItem(r, 0, QTableWidgetItem(c.name))
            self.tbl_cols.setItem(r, 1, QTableWidgetItem(c.data_type))
            self.tbl_cols.setItem(r, 2, QTableWidgetItem("YES" if c.nullable else "NO"))
            self.tbl_cols.setItem(r, 3, QTableWidgetItem("🔑" if c.is_pk else ""))
        self.tbl_cols.resizeColumnsToContents()

    def _fill_rows(self, res):
        # res: QueryResult
        self.tbl_rows.clear()
        self.tbl_rows.setColumnCount(len(res.columns))
        self.tbl_rows.setHorizontalHeaderLabels([str(x) for x in res.columns])
        self.tbl_rows.setRowCount(len(res.rows))
        for r, row in enumerate(res.rows):
            for c, v in enumerate(row):
                self.tbl_rows.setItem(r, c, QTableWidgetItem("" if v is None else str(v)))
        self.tbl_rows.resizeColumnsToContents()
