import os
import json
from typing import Optional

from PySide6.QtWidgets import QTabWidget, QWidget, QMessageBox, QPlainTextEdit, QFileDialog
from PySide6.QtCore import QObject

from utils.filetypes import detect_filetype, IPYNB
from services.kernel_service import KernelService

from ui.editors.code_editor import CodeEditor
from ui.editors.notebook_editor import NotebookEditor, NotebookCell, NotebookDoc


class EditorManager(QTabWidget):
    """
    Zarządza zakładkami edytorów i mapowaniem widget->ścieżka.
    Dodaje obsługę:
    - dirty state (gwiazdka na tabie)
    - Save / Save As
    - bezpieczne zamykanie taba (Save/Discard/Cancel)
    """

    def __init__(self, kernel_service: KernelService, parent=None):
        super().__init__(parent)
        self.kernel_service = kernel_service

        self.setTabsClosable(True)
        self.tabCloseRequested.connect(self._close_tab)

        # Stabilne mapowanie per widget (nie po indeksach!)
        self._path_by_widget: dict[int, str] = {}

    # ---------------- public API ----------------

    def open_path(self, path: str):
        path = os.path.abspath(path)

        # jeśli już otwarty -> aktywuj
        for i in range(self.count()):
            w = self.widget(i)
            if w and self._path_by_widget.get(id(w)) == path:
                self.setCurrentIndex(i)
                return

        ftype = detect_filetype(path)

        try:
            if ftype == IPYNB:
                w = NotebookEditor(self.kernel_service)
                w.set_current_path(path)
                doc = self._read_ipynb(path)
                w.load_doc(doc)
                w.set_modified(False)
            else:
                w = CodeEditor()
                w.set_current_path(path)
                w.setPlainText(self._read_text(path))
                w.document().setModified(False)

        except Exception as e:
            # Nie pokazujemy modalnych okienek (jak w JupyterLab/Colab).
            # W razie błędu otwieramy tryb prosty.
            w = QPlainTextEdit()
            try:
                w.setPlainText(self._read_text(path))
            except Exception:
                w.setPlainText("")
            # brak save/dirty dla prostego edytora

        idx = self.addTab(w, os.path.basename(path))
        self.setCurrentIndex(idx)
        self._path_by_widget[id(w)] = path

        self._wire_dirty_tracking(w)

    def current_path(self) -> Optional[str]:
        w = self.currentWidget()
        if not w:
            return None
        return self._path_by_widget.get(id(w))

    def path_for_widget(self, w: QWidget) -> Optional[str]:
        return self._path_by_widget.get(id(w))

    def current_widget(self) -> Optional[QWidget]:
        return self.widget(self.currentIndex())

    def apply_theme(self, theme_name: str | None):
        """Apply syntax palette to editors that support it."""
        for i in range(self.count()):
            w = self.widget(i)
            if isinstance(w, CodeEditor):
                try:
                    w.set_theme(theme_name)
                except Exception:
                    pass
            elif isinstance(w, NotebookEditor):
                try:
                    w.apply_theme(theme_name)
                except Exception:
                    pass

    def is_widget_modified(self, w: QWidget) -> bool:
        if isinstance(w, CodeEditor):
            return bool(w.document().isModified())
        if isinstance(w, NotebookEditor):
            return bool(w.is_modified())
        return False

    def save_current(self) -> bool:
        w = self.currentWidget()
        if not w:
            return True
        return self.save_widget(w)

    def save_current_as(self) -> bool:
        w = self.currentWidget()
        if not w:
            return True
        return self.save_widget_as(w)

    def save_all(self) -> bool:
        """Zapisuje wszystkie otwarte zakładki.

        Zwraca False, jeśli użytkownik anulował (np. Save As) albo zapis się nie udał.
        """
        for i in range(self.count()):
            w = self.widget(i)
            if not w:
                continue
            if not self.is_widget_modified(w):
                continue
            if not self.save_widget(w):
                return False
        return True

    def save_widget(self, w: QWidget) -> bool:
        path = self._path_by_widget.get(id(w))
        if not path:
            # brak ścieżki -> Save As
            return self.save_widget_as(w)
        return self._save_to_path(w, path)

    def save_widget_as(self, w: QWidget) -> bool:
        cur = self._path_by_widget.get(id(w))
        default_dir = os.path.dirname(cur) if cur else os.getcwd()
        default_name = os.path.basename(cur) if cur else "untitled.py"

        if isinstance(w, NotebookEditor):
            filt = "Notebook (*.ipynb);;All files (*.*)"
            if not default_name.lower().endswith(".ipynb"):
                default_name = os.path.splitext(default_name)[0] + ".ipynb"
        else:
            filt = "Python (*.py);;Text (*.txt);;All files (*.*)"

        out, _ = QFileDialog.getSaveFileName(self, "Save As...", os.path.join(default_dir, default_name), filt)
        if not out:
            return False

        out = os.path.abspath(out)
        ok = self._save_to_path(w, out)
        if ok:
            self._path_by_widget[id(w)] = out
            if hasattr(w, "set_current_path"):
                try:
                    w.set_current_path(out)
                except Exception:
                    pass
            self._refresh_tab_title_for_widget(w)
        return ok

    def maybe_close_all(self) -> bool:
        # zamykamy od końca (stabilne indeksy)
        for i in range(self.count() - 1, -1, -1):
            if not self._close_tab(i, interactive=True):
                return False
        return True

    # ---------------- internals ----------------

    def _wire_dirty_tracking(self, w: QWidget):
        if isinstance(w, CodeEditor):
            w.document().modificationChanged.connect(lambda _m, ww=w: self._refresh_tab_title_for_widget(ww))
            self._refresh_tab_title_for_widget(w)
            return

        if isinstance(w, NotebookEditor):
            w.modificationChanged.connect(lambda _m, ww=w: self._refresh_tab_title_for_widget(ww))
            self._refresh_tab_title_for_widget(w)
            return

        # prosty edytor: brak

    def _refresh_tab_title_for_widget(self, w: QWidget):
        idx = self.indexOf(w)
        if idx < 0:
            return

        path = self._path_by_widget.get(id(w))
        base = os.path.basename(path) if path else "untitled"
        star = "*" if self.is_widget_modified(w) else ""
        self.setTabText(idx, f"{base}{star}")

    def _close_tab(self, index: int, interactive: bool = True) -> bool:
        w = self.widget(index)
        if not w:
            return True

        if interactive and self.is_widget_modified(w):
            path = self._path_by_widget.get(id(w)) or "bez nazwy"
            res = QMessageBox.question(
                self,
                "Niezapisane zmiany",
                f"Plik ma niezapisane zmiany:\n\n{path}\n\nZapisać przed zamknięciem?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Save
            )
            if res == QMessageBox.StandardButton.Cancel:
                return False
            if res == QMessageBox.StandardButton.Save:
                if not self.save_widget(w):
                    return False  # użytkownik anulował Save As lub zapis się nie udał

        self.removeTab(index)
        self._path_by_widget.pop(id(w), None)
        try:
            w.deleteLater()
        except Exception:
            pass
        return True

    def _save_to_path(self, w: QWidget, path: str) -> bool:
        try:
            ftype = detect_filetype(path)

            if isinstance(w, NotebookEditor) or ftype == IPYNB:
                nb = self._build_ipynb(w.doc() if isinstance(w, NotebookEditor) else NotebookDoc())
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(nb, f, ensure_ascii=False, indent=2)
                if isinstance(w, NotebookEditor):
                    w.set_modified(False)
                return True

            # CodeEditor / QPlainTextEdit
            text = ""
            if isinstance(w, CodeEditor):
                text = w.toPlainText()
                with open(path, "w", encoding="utf-8") as f:
                    f.write(text)
                # Upewnij się, że "dirty" faktycznie znika.
                # W praktyce sam setModified(False) powinien wystarczyć, ale przy pewnych
                # konfiguracjach undo-stack potrafi zostawić stan zmodyfikowany.
                doc = w.document()
                doc.setModified(False)
                try:
                    doc.clearUndoRedoStacks()
                except Exception:
                    pass
                return True

            if isinstance(w, QPlainTextEdit):
                text = w.toPlainText()
                with open(path, "w", encoding="utf-8") as f:
                    f.write(text)
                return True

            # fallback
            return False

        except Exception as e:
            QMessageBox.warning(self, "Save", f"Nie udało się zapisać pliku:\n\n{path}\n\n{e}")
            return False
        finally:
            self._refresh_tab_title_for_widget(w)

    def _read_text(self, path: str) -> str:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except UnicodeDecodeError:
            with open(path, "r", encoding="latin-1", errors="replace") as f:
                return f.read()

    def _read_ipynb(self, path: str) -> NotebookDoc:
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = f.read().strip()
                if not raw:
                    return NotebookDoc(cells=[], metadata={})
                nb = json.loads(raw)
        except Exception:
            return NotebookDoc(cells=[], metadata={})

        cells: list[NotebookCell] = []
        for c in nb.get("cells", []):
            src = c.get("source", [])
            if isinstance(src, list):
                src = "".join(src)
            cell_type = c.get("cell_type", "code")
            exec_count = c.get("execution_count") if cell_type == "code" else None
            outputs = c.get("outputs") if cell_type == "code" else []
            if not isinstance(outputs, list):
                outputs = []
            md = c.get("metadata")
            if not isinstance(md, dict):
                md = {}
            cells.append(NotebookCell(
                cell_type=cell_type,
                source=src or "",
                execution_count=exec_count,
                outputs=outputs,
                metadata=md,
            ))

        meta = nb.get("metadata")
        if not isinstance(meta, dict):
            meta = {}
        return NotebookDoc(cells=cells, metadata=meta)

    def _build_ipynb(self, doc: NotebookDoc) -> dict:
        def to_source_list(s: str) -> list[str]:
            if not s:
                return []
            # zachowaj nowe linie jak w Jupyterze
            return s.splitlines(True)

        out_cells = []
        for c in (doc.cells or []):
            cell_type = c.cell_type if c.cell_type in ("code", "markdown") else "code"
            if cell_type == "code":
                out_cells.append({
                    "cell_type": "code",
                    "execution_count": c.execution_count,
                    "metadata": c.metadata or {},
                    "outputs": c.outputs or [],
                    "source": to_source_list(c.source or ""),
                })
            else:
                out_cells.append({
                    "cell_type": "markdown",
                    "metadata": c.metadata or {},
                    "source": to_source_list(c.source or ""),
                })

        return {
            "cells": out_cells,
            "metadata": doc.metadata or {},
            "nbformat": 4,
            "nbformat_minor": 5,
        }
