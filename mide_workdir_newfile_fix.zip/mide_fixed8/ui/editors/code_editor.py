from __future__ import annotations

import re
import ast
from dataclasses import dataclass

from PySide6.QtCore import Qt, QRect, QSize, QTimer, QPoint, QEvent
from PySide6.QtGui import (
    QColor, QFont, QPainter, QTextCursor, QTextCharFormat, QTextFormat
)
from PySide6.QtWidgets import QPlainTextEdit, QWidget, QToolTip, QTextEdit

import jedi

from ui.editors.completion_popup import CompletionPopup
from ui.theme import get_syntax_palette, DEFAULT_THEME_NAME


# -------------------- diagnostics --------------------

@dataclass
class Diagnostic:
    line: int
    col: int
    message: str
    severity: str = "error"  # error|warning|info


def diagnostics_from_syntax(code: str) -> list[Diagnostic]:
    try:
        ast.parse(code)
        return []
    except SyntaxError as e:
        line = int(getattr(e, "lineno", 1) or 1)
        col = int(getattr(e, "offset", 1) or 1)
        msg = getattr(e, "msg", "SyntaxError")
        return [Diagnostic(line=line, col=col, message=msg, severity="error")]


# -------------------- helpers --------------------

_ansi_re = re.compile(r"\x1b\[[0-9;]*m")


def strip_ansi(s: str) -> str:
    return _ansi_re.sub("", s or "")


# Preferuj Pygments jeśli jest dostępny
try:
    from pygments import lex
    from pygments.lexers import PythonLexer
    from pygments.token import Token
    PYGMENTS_OK = True
except Exception:
    PYGMENTS_OK = False


# -------------------- line number area --------------------

class LineNumberArea(QWidget):
    def __init__(self, editor: "CodeEditor"):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event):
        self.editor.paint_line_numbers(event)


# -------------------- CodeEditor --------------------

class CodeEditor(QPlainTextEdit):
    """
    PySide6-friendly CodeEditor:
    - numeracja linii (gutter)
    - kolorowanie składni (pygments, fallback regex)
    - podświetlenie aktualnej linii
    - minimalne diagnostyki (SyntaxError): falka + tooltip
    - hover docs/signature z jedi (tooltip)
    - autouzupełnianie (Ctrl+Space + po kropce)
    - go-to-definition (F12) / references (Shift+F12) przez Jedi
    """

    def __init__(self):
        super().__init__()

        self.setFont(QFont("Consolas", 11))
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(" "))

        # theme/syntax palette
        self._theme_name = DEFAULT_THEME_NAME
        self._palette = get_syntax_palette(self._theme_name)

        self._current_path: str | None = None

        # line numbers
        self._line_area = LineNumberArea(self)
        self.blockCountChanged.connect(self._update_line_area_width)
        self.updateRequest.connect(self._update_line_area)
        self.cursorPositionChanged.connect(self._highlight_current_line)
        self._update_line_area_width(0)

        # timers
        self._diag_timer = QTimer(self)
        self._diag_timer.setSingleShot(True)
        self._diag_timer.setInterval(250)
        self._diag_timer.timeout.connect(self._refresh_diagnostics)

        self._hl_timer = QTimer(self)
        self._hl_timer.setSingleShot(True)
        self._hl_timer.setInterval(120)
        self._hl_timer.timeout.connect(self._rehighlight)

        self.textChanged.connect(self._on_text_changed)

        # diagnostics state
        self._diagnostics: list[Diagnostic] = []
        self._diag_ranges: list[tuple[int, int, str]] = []  # (start_pos, end_pos, tooltip)

        # hover cache
        self._last_docpos = None
        self._last_hover_text = None

        # completions
        self._compl_popup = CompletionPopup(self)
        self._compl_popup.accepted.connect(self._insert_completion)
        self._compl_prefix = ""

        # initial
        QTimer.singleShot(0, self._rehighlight)
        QTimer.singleShot(0, self._refresh_diagnostics)
        QTimer.singleShot(0, self._highlight_current_line)

    # ---------- public API ----------

    def set_current_path(self, path: str | None):
        self._current_path = path

    def set_theme(self, theme_name: str | None):
        """Update syntax palette (QSS is applied at app level)."""
        self._theme_name = theme_name or DEFAULT_THEME_NAME
        self._palette = get_syntax_palette(self._theme_name)
        self._rehighlight()

    def get_selected_or_line(self) -> str:
        tc = self.textCursor()
        txt = tc.selectedText()
        if not txt.strip():
            tc.select(QTextCursor.LineUnderCursor)
            txt = tc.selectedText()
        return txt.replace("\u2029", "\n")

    # ---------- completions ----------

    def request_completions_now(self):
        code = self.toPlainText()
        pos = self.textCursor().position()
        before = code[:pos]

        line = before.count("\n") + 1
        col = len(before.split("\n")[-1])

        # prefix = fragment słowa przed kursorem (dla replace)
        last_line = before.split("\n")[-1]
        m = re.search(r"[A-Za-z0-9_]+$", last_line)
        self._compl_prefix = m.group(0) if m else ""

        try:
            script = jedi.Script(code, path=self._current_path or None)
            comps = script.complete(line, col)
            names = [c.name for c in comps]
        except Exception:
            names = []

        cr = self.cursorRect()
        gp = self.mapToGlobal(cr.bottomRight() + QPoint(6, 6))
        self._compl_popup.show_items(names, gp)

    def _insert_completion(self, text: str):
        tc = self.textCursor()

        # usuń prefix i wstaw pełny symbol
        if self._compl_prefix:
            for _ in range(len(self._compl_prefix)):
                tc.deletePreviousChar()

        tc.insertText(text)
        self.setTextCursor(tc)
        self.setFocus()

    # ---------- navigation (Jedi) ----------

    def _pos_to_line_col(self, pos: int) -> tuple[int, int]:
        code = self.toPlainText()
        before = code[:pos]
        line = before.count("\n") + 1
        col = len(before.split("\n")[-1])
        return line, col

    def go_to_definition(self):
        code = self.toPlainText()
        pos = self.textCursor().position()
        line, col = self._pos_to_line_col(pos)

        try:
            script = jedi.Script(code, path=self._current_path or None)
            defs = script.goto(line, col, follow_imports=True)
            if not defs:
                return None
            d = defs[0]
            return (d.module_path, d.line, d.column)
        except Exception:
            return None

    def find_references(self):
        code = self.toPlainText()
        pos = self.textCursor().position()
        line, col = self._pos_to_line_col(pos)

        try:
            script = jedi.Script(code, path=self._current_path or None)
            refs = script.get_references(line, col, include_builtins=False)
            out = []
            for r in refs:
                out.append((r.module_path, r.line, r.column, r.name))
            return out
        except Exception:
            return []

    # ---------- gutter ----------

    def line_number_area_width(self) -> int:
        digits = len(str(max(1, self.blockCount())))
        return 14 + self.fontMetrics().horizontalAdvance("9") * digits

    def _update_line_area_width(self, _):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)


    def _update_line_number_area_width(self, *args):
        # Compatibility alias (some code paths expect this name)
        return self._update_line_area_width(*args)

    def _update_line_area(self, rect: QRect, dy: int):
        if dy:
            self._line_area.scroll(0, dy)
        else:
            self._line_area.update(0, rect.y(), self._line_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._update_line_area_width(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self._line_area.setGeometry(QRect(cr.left(), cr.top(), self.line_number_area_width(), cr.height()))

    def paint_line_numbers(self, event):
        painter = QPainter(self._line_area)
        painter.fillRect(event.rect(), QColor("#0f1628"))

        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = int(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + int(self.blockBoundingRect(block).height())

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(block_number + 1)
                painter.setPen(QColor("#7f91aa"))
                painter.drawText(
                    0, top, self._line_area.width() - 6, self.fontMetrics().height(),
                    Qt.AlignRight, number
                )
            block = block.next()
            block_number += 1
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())

    # ---------- selections (current line + errors) ----------

    def _highlight_current_line(self):
        extra = []

        if not self.isReadOnly():
            sel = QTextEdit.ExtraSelection()
            fmt = sel.format
            fmt.setBackground(QColor("#111a33"))
            fmt.setProperty(QTextFormat.FullWidthSelection, True)
            sel.cursor = self.textCursor()
            sel.cursor.clearSelection()
            extra.append(sel)

        extra.extend(self._error_selections())
        self.setExtraSelections(extra)

    def _error_selections(self):
        selections = []
        self._diag_ranges = []

        if not self._diagnostics:
            return selections

        doc = self.document()
        for d in self._diagnostics:
            block = doc.findBlockByNumber(max(0, d.line - 1))
            if not block.isValid():
                continue

            line_start = block.position()
            start = line_start + max(0, d.col - 1)

            cur = QTextCursor(doc)
            cur.setPosition(start)
            cur.movePosition(QTextCursor.NextWord, QTextCursor.KeepAnchor)
            if cur.selectionEnd() == cur.selectionStart():
                cur.movePosition(QTextCursor.NextCharacter, QTextCursor.KeepAnchor)

            sel = QTextEdit.ExtraSelection()
            sel.cursor = cur

            fmt = QTextCharFormat()
            fmt.setUnderlineStyle(QTextCharFormat.WaveUnderline)
            fmt.setUnderlineColor(QColor("#ff4d6d"))
            sel.format = fmt

            tooltip = f"{d.severity.upper()}: {d.message}"
            self._diag_ranges.append((cur.selectionStart(), cur.selectionEnd(), tooltip))
            selections.append(sel)

        return selections

    # ---------- tooltips: errors + hover docs ----------

    def event(self, e):
        if e.type() == QEvent.Type.ToolTip:
            pos = self.cursorForPosition(e.pos()).position()

            # 1) error tooltip
            for a, b, tip in self._diag_ranges:
                if a <= pos <= b:
                    QToolTip.showText(e.globalPos(), tip, self)
                    return True

            # 2) hover docs
            tip = self._hover_text_for_pos(pos)
            if tip:
                QToolTip.showText(e.globalPos(), tip, self)
                return True

            QToolTip.hideText()
            return True

        return super().event(e)

    def _hover_text_for_pos(self, doc_pos: int) -> str | None:
        if self._last_docpos == doc_pos:
            return self._last_hover_text

        self._last_docpos = doc_pos
        code = self.toPlainText()

        before = code[:doc_pos]
        line = before.count("\n") + 1
        col = len(before.split("\n")[-1])

        try:
            script = jedi.Script(code, path=self._current_path or None)
            inf = script.infer(line, col)
            if not inf:
                self._last_hover_text = None
                return None

            obj = inf[0]
            sigs = script.get_signatures(line, col)
            sig_txt = sigs[0].to_string() if sigs else ""

            doc = (obj.docstring(raw=True) or "").strip()
            text = (sig_txt + "\n\n" + doc).strip() if (sig_txt or doc) else obj.name
            if not text:
                self._last_hover_text = None
                return None

            text = strip_ansi(text)[:1200]
            self._last_hover_text = text
            return text
        except Exception:
            self._last_hover_text = None
            return None

    # ---------- key handling ----------

    def keyPressEvent(self, event):
        # jeśli popup otwarty: oddaj mu nawigację
        if self._compl_popup.isVisible():
            if event.key() in (Qt.Key_Up, Qt.Key_Down, Qt.Key_PageUp, Qt.Key_PageDown, Qt.Key_Home, Qt.Key_End,
                               Qt.Key_Return, Qt.Key_Enter, Qt.Key_Escape):
                self._compl_popup.keyPressEvent(event)
                return

        # Ctrl+Space -> completions
        if event.key() == Qt.Key_Space and (event.modifiers() & Qt.ControlModifier):
            self.request_completions_now()
            return

        super().keyPressEvent(event)

        # auto-trigger po kropce
        if event.text() == ".":
            self.request_completions_now()

    # ---------- change handlers ----------

    def _on_text_changed(self):
        self._diag_timer.start()
        self._hl_timer.start()

    def _refresh_diagnostics(self):
        self._diagnostics = diagnostics_from_syntax(self.toPlainText())
        self._highlight_current_line()

    # ---------- syntax coloring ----------

    def _rehighlight(self):
        # Uwaga: formatowanie (setCharFormat) potrafi oznaczać dokument jako zmodyfikowany,
        # co psuje "dirty state" (gwiazdkę) nawet po zapisie.
        doc = self.document()
        prev_modified = doc.isModified()
        prev_undo = self.isUndoRedoEnabled()

        # Podświetlanie nie powinno wpływać na undo/redo ani modified.
        self.setUndoRedoEnabled(False)
        try:
            if PYGMENTS_OK:
                self._apply_pygments()
            else:
                self._apply_regex_fallback()
        finally:
            self.setUndoRedoEnabled(prev_undo)
            doc.setModified(prev_modified)

        self._highlight_current_line()

    def _apply_pygments(self):
        code = self.toPlainText()
        doc = self.document()

        # wyczyść formaty
        clear = QTextCharFormat()
        cur = QTextCursor(doc)
        cur.beginEditBlock()
        cur.select(QTextCursor.Document)
        cur.setCharFormat(clear)
        cur.clearSelection()
        cur.endEditBlock()

        def fmt_for(tok):
            f = QTextCharFormat()
            if tok in Token.Keyword:
                f.setForeground(QColor(self._palette.get("keyword")))
                f.setFontWeight(QFont.Bold)
            elif tok in Token.Name.Function:
                f.setForeground(QColor(self._palette.get("name")))
            elif tok in Token.Name.Class:
                f.setForeground(QColor(self._palette.get("name")))
            elif tok in Token.Literal.String:
                f.setForeground(QColor(self._palette.get("string")))
            elif tok in Token.Comment:
                f.setForeground(QColor(self._palette.get("comment")))
            elif tok in Token.Number:
                f.setForeground(QColor(self._palette.get("number")))
            else:
                f.setForeground(QColor(self._palette.get("name")))
            return f

        pos = 0
        cur = QTextCursor(doc)
        cur.beginEditBlock()
        for tok, val in lex(code, PythonLexer()):
            if not val:
                continue
            length = len(val)
            cur.setPosition(pos)
            cur.setPosition(pos + length, QTextCursor.KeepAnchor)
            cur.setCharFormat(fmt_for(tok))
            pos += length
        cur.endEditBlock()

    def _apply_regex_fallback(self):
        code = self.toPlainText()
        doc = self.document()

        clear = QTextCharFormat()
        cur = QTextCursor(doc)
        cur.beginEditBlock()
        cur.select(QTextCursor.Document)
        cur.setCharFormat(clear)
        cur.clearSelection()
        cur.endEditBlock()

        rules = [
            (r"\b(def|class|return|if|elif|else|for|while|try|except|finally|with|as|import|from|pass|break|continue|lambda|yield|raise|assert|global|nonlocal|True|False|None)\b", QColor(self._palette.get("keyword")), True),
            (r"#[^\n]*", QColor(self._palette.get("comment")), False),
            (r"('''.*?'''|\"\"\".*?\"\"\"|'[^'\n]*'|\"[^\"\n]*\")", QColor(self._palette.get("string")), False),
            (r"\b\d+(\.\d+)?\b", QColor(self._palette.get("number")), False),
        ]

        cur = QTextCursor(doc)
        cur.beginEditBlock()
        for pattern, color, bold in rules:
            rx = re.compile(pattern, re.DOTALL)
            for m in rx.finditer(code):
                f = QTextCharFormat()
                f.setForeground(color)
                if bold:
                    f.setFontWeight(QFont.Bold)
                cur.setPosition(m.start())
                cur.setPosition(m.end(), QTextCursor.KeepAnchor)
                cur.setCharFormat(f)
        cur.endEditBlock()
