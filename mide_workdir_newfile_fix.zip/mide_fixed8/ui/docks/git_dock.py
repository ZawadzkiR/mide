from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QPushButton, QPlainTextEdit, QLabel, QLineEdit, QMessageBox, QAbstractItemView
)


@dataclass
class GitItem:
    status: str
    path: str


def _run_git(repo: str, args: list[str]) -> tuple[int, str, str]:
    p = subprocess.Popen(
        ["git", "-C", repo, *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    out, err = p.communicate()
    return p.returncode, out, err


class GitDock(QDockWidget):
    file_open_requested = Signal(str)

    def __init__(self, parent=None):
        super().__init__("Git", parent)
        self.setObjectName("dock.git")

        self._repo_root: str | None = None

        root = QWidget()
        lay = QVBoxLayout(root)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(8)

        self.lbl_repo = QLabel("No repository")
        self.lbl_repo.setStyleSheet("color:#a9b6c7;")
        lay.addWidget(self.lbl_repo)

        btn_row = QHBoxLayout()
        self.btn_refresh = QPushButton("Refresh")
        self.btn_stage = QPushButton("Stage")
        self.btn_unstage = QPushButton("Unstage")
        btn_row.addWidget(self.btn_refresh)
        btn_row.addWidget(self.btn_stage)
        btn_row.addWidget(self.btn_unstage)
        lay.addLayout(btn_row)

        self.list = QListWidget()
        # Qt6/PySide6 uses QAbstractItemView.SelectionMode for selection mode enums.
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        lay.addWidget(self.list, 1)

        self.diff = QPlainTextEdit()
        self.diff.setReadOnly(True)
        self.diff.setPlaceholderText("Diff")
        lay.addWidget(self.diff, 1)

        commit_row = QHBoxLayout()
        self.ed_msg = QLineEdit()
        self.ed_msg.setPlaceholderText("Commit message")
        self.btn_commit = QPushButton("Commit")
        self.btn_pull = QPushButton("Pull")
        self.btn_push = QPushButton("Push")
        commit_row.addWidget(self.ed_msg, 1)
        commit_row.addWidget(self.btn_commit)
        commit_row.addWidget(self.btn_pull)
        commit_row.addWidget(self.btn_push)
        lay.addLayout(commit_row)

        self.setWidget(root)

        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_stage.clicked.connect(self.stage_selected)
        self.btn_unstage.clicked.connect(self.unstage_selected)
        self.btn_commit.clicked.connect(self.commit)
        self.btn_pull.clicked.connect(self.pull)
        self.btn_push.clicked.connect(self.push)
        self.list.currentItemChanged.connect(self._on_current_changed)
        self.list.itemDoubleClicked.connect(self._on_double_clicked)

    def set_repo_root(self, root: str | None):
        self._repo_root = os.path.abspath(root) if root else None
        if self._repo_root:
            self.lbl_repo.setText(self._repo_root)
        else:
            self.lbl_repo.setText("No repository")
        self.refresh()

    # ---- actions ----

    def refresh(self):
        self.list.clear()
        self.diff.setPlainText("")
        repo = self._repo_root
        if not repo:
            return

        code, out, err = _run_git(repo, ["rev-parse", "--is-inside-work-tree"])
        if code != 0 or "true" not in out:
            self.lbl_repo.setText(f"Not a git repo: {repo}")
            return

        code, out, err = _run_git(repo, ["status", "--porcelain"])
        if code != 0:
            self.diff.setPlainText(err or out)
            return

        for line in (out or "").splitlines():
            if not line.strip():
                continue
            status = line[:2]
            path = line[3:].strip()
            item = QListWidgetItem(f"{status}  {path}")
            item.setData(Qt.UserRole, GitItem(status=status, path=path))
            self.list.addItem(item)

    def _selected(self) -> GitItem | None:
        it = self.list.currentItem()
        if not it:
            return None
        return it.data(Qt.UserRole)

    def _on_current_changed(self, *_):
        repo = self._repo_root
        sel = self._selected()
        if not repo or not sel:
            return
        code, out, err = _run_git(repo, ["diff", "--", sel.path])
        if code != 0:
            self.diff.setPlainText(err or out)
        else:
            self.diff.setPlainText(out)

    def _on_double_clicked(self, item: QListWidgetItem):
        repo = self._repo_root
        if not repo:
            return
        sel: GitItem = item.data(Qt.UserRole)
        abs_path = os.path.join(repo, sel.path)
        if os.path.isfile(abs_path):
            self.file_open_requested.emit(abs_path)

    def stage_selected(self):
        repo = self._repo_root
        sel = self._selected()
        if not repo or not sel:
            return
        _run_git(repo, ["add", "--", sel.path])
        self.refresh()

    def unstage_selected(self):
        repo = self._repo_root
        sel = self._selected()
        if not repo or not sel:
            return
        _run_git(repo, ["restore", "--staged", "--", sel.path])
        self.refresh()

    def commit(self):
        repo = self._repo_root
        if not repo:
            return
        msg = (self.ed_msg.text() or "").strip()
        if not msg:
            QMessageBox.warning(self, "Commit", "Commit message is empty")
            return
        code, out, err = _run_git(repo, ["commit", "-m", msg])
        if code != 0:
            QMessageBox.warning(self, "Commit", err or out)
        self.ed_msg.setText("")
        self.refresh()

    def pull(self):
        repo = self._repo_root
        if not repo:
            return
        code, out, err = _run_git(repo, ["pull"])
        QMessageBox.information(self, "Pull", err or out)
        self.refresh()

    def push(self):
        repo = self._repo_root
        if not repo:
            return
        code, out, err = _run_git(repo, ["push"])
        QMessageBox.information(self, "Push", err or out)
        self.refresh()
