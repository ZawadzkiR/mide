from __future__ import annotations

import json
import re
import ast

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLineEdit,
    QToolButton, QTreeWidget, QTreeWidgetItem, QLabel, QCheckBox, QStyle
)

from services.kernel_service import KernelService
from ui.dialogs.variable_preview_dialog import VariablePreviewDialog


_MARK_LIST = "@@VARS@@"
_MARK_PREVIEW = "@@VARPREVIEW@@"


class VariablesDock(QDockWidget):
    """Variable Explorer (Python in-process kernel).

    R: brak trwałej sesji w obecnej architekturze (Runner odpala skrypt i kończy),
    więc tutaj pokazujemy tylko Python kernel.
    """

    def __init__(self, kernel_service: KernelService, parent=None):
        super().__init__("Variables", parent)
        self.kernel_service = kernel_service

        root = QWidget(self)
        self.setWidget(root)

        self.txt_filter = QLineEdit()
        self.txt_filter.setPlaceholderText("Filter (regex / substring)...")

        self.chk_auto = QCheckBox("Auto")
        self.chk_auto.setToolTip("Auto refresh")

        self.btn_refresh = QToolButton()
        self.btn_refresh.setIcon(self.style().standardIcon(QStyle.SP_BrowserReload))
        self.btn_refresh.setToolTip("Refresh variables")

        top = QHBoxLayout()
        top.setContentsMargins(6, 6, 6, 6)
        top.setSpacing(6)
        top.addWidget(QLabel("Filter:"), 0)
        top.addWidget(self.txt_filter, 1)
        top.addWidget(self.chk_auto, 0)
        top.addWidget(self.btn_refresh, 0)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(3)
        self.tree.setHeaderLabels(["Name", "Type", "Preview"])
        self.tree.setRootIsDecorated(False)
        self.tree.setAlternatingRowColors(True)
        self.tree.setSortingEnabled(True)
        self.tree.sortByColumn(0, Qt.AscendingOrder)

        lay = QVBoxLayout(root)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addLayout(top)
        lay.addWidget(self.tree, 1)

        self._auto_timer = QTimer(self)
        self._auto_timer.setInterval(2000)
        self._auto_timer.timeout.connect(self.refresh)

        self._pending = False
        self._raw_items: list[dict] = []

        self.btn_refresh.clicked.connect(self.refresh)
        self.txt_filter.textChanged.connect(self._apply_filter)
        self.chk_auto.toggled.connect(self._on_auto)
        self.tree.itemActivated.connect(self._on_item_activated)
        # initial refresh when dock is created
        QTimer.singleShot(0, self.refresh)

    def showEvent(self, event):
        super().showEvent(event)
        # refresh when user shows the dock
        QTimer.singleShot(0, self.refresh)


    def _on_auto(self, on: bool):
        if on:
            self._auto_timer.start()
            self.refresh()
        else:
            self._auto_timer.stop()

    def refresh(self):
        if self._pending:
            return
        self._pending = True

        # In-process kernel: najpewniejsze jest czytanie user_ns bezpośrednio.
        # Dzięki temu nic nie trafia do konsoli, a dane są zawsze dostępne.
        self.kernel_service.start_inprocess_python()
        ns = self.kernel_service.get_user_namespace() or {}

        def _safe_repr(v):
            try:
                s = repr(v)
            except Exception:
                s = "<unrepr>"
            if s is None:
                s = ""
            s = str(s)
            if len(s) > 220:
                s = s[:220] + "…"
            return s

        items: list[dict] = []
        try:
            import types

            for k, v in list(ns.items()):
                if not isinstance(k, str):
                    continue
                if k.startswith("_"):
                    continue
                if isinstance(v, types.ModuleType):
                    continue
                try:
                    t = type(v).__name__
                except Exception:
                    t = ""
                items.append({"name": k, "type": t, "repr": _safe_repr(v)})
        except Exception:
            items = []

        self._raw_items = items
        self._pending = False
        self._apply_filter()

    def _apply_filter(self):
        items = self._raw_items or []
        q = (self.txt_filter.text() or "").strip()

        rx = None
        if q:
            try:
                rx = re.compile(q, re.IGNORECASE)
            except Exception:
                rx = None

        self.tree.setSortingEnabled(False)
        self.tree.clear()

        for it in items:
            name = str(it.get("name", ""))
            typ = str(it.get("type", ""))
            rep = str(it.get("repr", ""))

            if q:
                hay = f"{name} {typ} {rep}"
                if rx:
                    if not rx.search(hay):
                        continue
                else:
                    if q.lower() not in hay.lower():
                        continue

            row = QTreeWidgetItem([name, typ, rep])
            self.tree.addTopLevelItem(row)

        self.tree.setSortingEnabled(True)
        for c in range(3):
            self.tree.resizeColumnToContents(c)

    def _on_item_activated(self, item, column):
        try:
            name = item.text(0)
            vtype = item.text(1)
        except Exception:
            return
        if not name:
            return

        # Preview również czytamy bezpośrednio z user_ns.
        ns = self.kernel_service.get_user_namespace() or {}
        v = ns.get(name)

        payload = {"repr": ""}
        try:
            r = repr(v)
            if r is None:
                r = ""
            if len(r) > 20000:
                r = r[:20000] + "…"
            payload["repr"] = r
        except Exception as e:
            payload["repr"] = str(e)

        try:
            import pandas as _pd

            if isinstance(v, _pd.DataFrame):
                head = v.head(500)
                # include index as first column for RStudio/Spyder-like browsing
                _cols = ["index"] + [str(c) for c in list(head.columns)]
                _vals = head.astype(object).where(head.notna(), None)
                _rows = []
                for idx, row in _vals.iterrows():
                    _rows.append([idx] + list(row.values.tolist()))
                payload["df"] = {"columns": _cols, "rows": _rows}
                try:
                    payload["html"] = head.to_html(index=True)
                except Exception:
                    pass
        except Exception:
            pass

        dlg = VariablePreviewDialog(name, vtype, payload, self)
        dlg.exec()
