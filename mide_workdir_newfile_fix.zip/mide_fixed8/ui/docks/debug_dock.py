from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QTextBrowser, QLineEdit, QPushButton, QLabel
)


class DebugDock(QDockWidget):
    """Minimalny dock debugowania: output + input (dla pdb / R interactive)."""

    sendCommandRequested = Signal(str)
    stopRequested = Signal()

    def __init__(self, parent=None):
        super().__init__("Debug", parent)
        self.setObjectName("dock_debug")

        w = QWidget(self)
        self.setWidget(w)

        root = QVBoxLayout(w)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(6)

        top = QHBoxLayout()
        self.lbl_title = QLabel("No debug session")
        self.lbl_title.setStyleSheet("color:#b7c7dd;")
        top.addWidget(self.lbl_title, 1)

        self.btn_stop = QPushButton("Stop")
        self.btn_stop.clicked.connect(lambda: self.stopRequested.emit())
        top.addWidget(self.btn_stop)

        root.addLayout(top)

        self.out = QTextBrowser()
        self.out.setOpenExternalLinks(False)
        self.out.setReadOnly(True)
        self.out.setStyleSheet(
            "QTextBrowser{background:#0b1220;color:#e6eefc;border:1px solid #1b2a44;border-radius:6px; padding:6px;}"
        )
        root.addWidget(self.out, 1)

        bottom = QHBoxLayout()
        self.inp = QLineEdit()
        self.inp.setPlaceholderText("Command (pdb: n/s/c/l/p var) …")
        self.inp.returnPressed.connect(self._send)
        bottom.addWidget(self.inp, 1)

        self.btn_send = QPushButton("Send")
        self.btn_send.clicked.connect(self._send)
        bottom.addWidget(self.btn_send)

        root.addLayout(bottom)

        self.btn_stop.setEnabled(False)

    def _send(self):
        txt = self.inp.text().strip()
        if not txt:
            return
        self.inp.clear()
        self.sendCommandRequested.emit(txt)

    def set_session_title(self, title: str):
        self.lbl_title.setText(title)
        self.btn_stop.setEnabled(True)

    def clear_session(self):
        self.lbl_title.setText("No debug session")
        self.btn_stop.setEnabled(False)

    def append_out(self, text: str):
        if not text:
            return
        # PySide6: używaj stałej z klasy QTextCursor (nie z instancji)
        self.out.moveCursor(QTextCursor.MoveOperation.End)
        self.out.insertPlainText(text)
        self.out.moveCursor(QTextCursor.MoveOperation.End)

    def append_err(self, text: str):
        if not text:
            return
        self.out.moveCursor(QTextCursor.MoveOperation.End)
        self.out.insertHtml(f"<span style='color:#ff6b6b; white-space:pre-wrap'>{text}</span>")
        self.out.moveCursor(QTextCursor.MoveOperation.End)
