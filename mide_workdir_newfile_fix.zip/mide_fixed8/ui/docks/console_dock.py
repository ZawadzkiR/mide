from PySide6.QtWidgets import QDockWidget, QTabWidget, QPlainTextEdit
from PySide6.QtGui import QFont

from qtconsole.rich_jupyter_widget import RichJupyterWidget
from services.kernel_service import KernelService


class ConsoleDock(QDockWidget):
    def __init__(self, kernel_service: KernelService, parent=None):
        super().__init__("Console", parent)
        self.setObjectName("dock.console")

        self.tabs = QTabWidget()

        self.console = RichJupyterWidget()
        self.console.setFont(QFont("Consolas", 11))
        self.console.banner = "Interaktywna konsola (Python kernel)\n"

        km = kernel_service.start_inprocess_python()
        kc = kernel_service.get_console_client()

        self.console.kernel_manager = km
        self.console.kernel_client = kc

        self.run_output = QPlainTextEdit()
        self.run_output.setReadOnly(True)
        self.run_output.setFont(QFont("Consolas", 10))
        self.run_output.setStyleSheet(
            "QPlainTextEdit { background:#060914; color:#e6f1ff; border:1px solid #1b2a4a; border-radius:10px; padding:10px; }"
        )

        self.tabs.addTab(self.console, "Kernel")
        self.tabs.addTab(self.run_output, "Run output")
        self.setWidget(self.tabs)

    def execute(self, code: str):
        code = (code or "").rstrip() + "\n"
        self.console.execute(code, hidden=False)

    def append_text(self, text: str):
        if text is None:
            return
        self.tabs.setCurrentWidget(self.run_output)
        self.run_output.appendPlainText(text)

    def clear_run_output(self):
        self.run_output.clear()
