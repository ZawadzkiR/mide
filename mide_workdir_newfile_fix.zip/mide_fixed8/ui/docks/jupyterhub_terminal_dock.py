from __future__ import annotations

import json
from typing import Optional

from PySide6.QtCore import QObject, QThread, Signal, Slot
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import QDockWidget, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QLabel, QHBoxLayout, QPushButton

from services.jupyterhub_client import JupyterHubClient, JupyterHubEnv


class _TerminalWorker(QObject):
    text = Signal(str)
    status = Signal(str)
    finished = Signal()

    def __init__(self, env: JupyterHubEnv):
        super().__init__()
        self.env = env
        self._ws = None
        self._term_name = ""
        self._stop = False

    @Slot()
    def run(self):
        try:
            client = JupyterHubClient(self.env)
            self.status.emit("[JupyterHub] starting user server...\n")
            client.start_user_server()
            client.wait_user_ready()

            self.status.emit("[JupyterHub] creating terminal...\n")
            name = client.terminals_create()
            if not name:
                raise RuntimeError("Terminal create failed")
            self._term_name = name

            import websocket  # websocket-client

            ws_url = client.terminal_ws_url(name)
            self.status.emit(f"[JupyterHub] terminal: {name}\n")
            self._ws = websocket.create_connection(ws_url)

            while not self._stop:
                raw = self._ws.recv()
                if raw is None:
                    break
                try:
                    msg = json.loads(raw)
                    # Jupyter terminal zwykle: {"type":"stdout","content":"..."}
                    if isinstance(msg, dict):
                        t = msg.get("type")
                        c = msg.get("content")
                        if c:
                            self.text.emit(str(c))
                        elif t and t != "stdout":
                            self.text.emit(str(msg) + "\n")
                    # czasem: ["stdout", "..."]
                    elif isinstance(msg, list) and len(msg) >= 2:
                        self.text.emit(str(msg[1]))
                    else:
                        self.text.emit(str(msg) + "\n")
                except Exception:
                    # jeśli to plain text
                    self.text.emit(str(raw))
        except Exception as e:
            self.status.emit(f"[JupyterHub] terminal error: {e}\n")
        finally:
            try:
                if self._ws:
                    self._ws.close()
            except Exception:
                pass
            try:
                if self._term_name:
                    JupyterHubClient(self.env).terminals_delete(self._term_name)
            except Exception:
                pass
            self.finished.emit()

    @Slot(str)
    def send(self, text: str):
        if not self._ws:
            return
        try:
            payload = {"type": "stdin", "content": text}
            self._ws.send(json.dumps(payload))
        except Exception:
            # fallback: surowy tekst
            try:
                self._ws.send(text)
            except Exception:
                pass

    @Slot()
    def stop(self):
        self._stop = True
        try:
            if self._ws:
                self._ws.close()
        except Exception:
            pass


class JupyterHubTerminalDock(QDockWidget):
    """Prosty terminal do JupyterHub (Jupyter Server /api/terminals + websocket)."""

    def __init__(self, parent=None):
        super().__init__("JupyterHub Terminal", parent)
        self.setObjectName("dock_jupyterhub_terminal")

        self._thread: Optional[QThread] = None
        self._worker: Optional[_TerminalWorker] = None
        self._env: Optional[JupyterHubEnv] = None

        root = QWidget(self)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        top = QHBoxLayout()
        self.lbl = QLabel("(Select JupyterHub environment)")
        self.lbl.setStyleSheet("color:#a9b6c7;")
        self.btn_connect = QPushButton("Connect")
        self.btn_disconnect = QPushButton("Disconnect")
        self.btn_disconnect.setEnabled(False)
        top.addWidget(self.lbl, 1)
        top.addWidget(self.btn_connect)
        top.addWidget(self.btn_disconnect)
        lay.addLayout(top)

        self.out = QTextEdit()
        self.out.setReadOnly(True)
        self.out.setStyleSheet("background:#05070f; color:#e6f1ff; border:1px solid #1b2a4a; border-radius:10px; padding:8px;")
        lay.addWidget(self.out, 1)

        self.inp = QLineEdit()
        self.inp.setPlaceholderText("Type command and press Enter...")
        self.inp.returnPressed.connect(self._send_line)
        self.inp.setEnabled(False)
        lay.addWidget(self.inp)

        self.setWidget(root)

        self.btn_connect.clicked.connect(self.connect_terminal)
        self.btn_disconnect.clicked.connect(self.disconnect_terminal)

    def set_env(self, hub_url: str, hub_user: str, hub_token: str, hub_kernel: str = ""):
        self._env = JupyterHubEnv(
            hub_url=str(hub_url or "").strip(),
            user=str(hub_user or "").strip(),
            token=str(hub_token or "").strip(),
            kernel_name=str(hub_kernel or "").strip(),
        )
        if self._env.hub_url and self._env.user:
            self.lbl.setText(f"{self._env.user}@{self._env.hub_url}")
        else:
            self.lbl.setText("(Select JupyterHub environment)")

    @Slot()
    def connect_terminal(self):
        if self._thread or not self._env or not self._env.hub_url or not self._env.user or not self._env.token:
            return
        self.out.append("[JupyterHub] connecting...\n")
        self._worker = _TerminalWorker(self._env)
        # Do not parent QThread if we also deleteLater() it (prevents double-delete warnings/crashes).
        self._thread = QThread()
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.text.connect(self._append)
        self._worker.status.connect(self._append)
        self._worker.finished.connect(self._on_finished)
        # Schedule deletion exactly once.
        self._thread.finished.connect(self._thread.deleteLater)
        self._thread.finished.connect(self._worker.deleteLater)
        self._thread.start()
        self.btn_connect.setEnabled(False)
        self.btn_disconnect.setEnabled(True)
        self.inp.setEnabled(True)

    @Slot()
    def disconnect_terminal(self):
        if self._worker:
            try:
                self._worker.stop()
            except Exception:
                pass

    def _on_finished(self):
        try:
            if self._thread:
                self._thread.quit()
                self._thread.wait(2000)
        except Exception:
            pass
        self._thread = None
        self._worker = None
        self.btn_connect.setEnabled(True)
        self.btn_disconnect.setEnabled(False)
        self.inp.setEnabled(False)

    def _append(self, text: str):
        if not text:
            return
        self.out.moveCursor(QTextCursor.MoveOperation.End)
        self.out.insertPlainText(text)
        self.out.moveCursor(QTextCursor.MoveOperation.End)

    def _send_line(self):
        line = self.inp.text()
        if not line:
            return
        self.inp.clear()
        if self._worker:
            # terminal expects newline
            self._worker.send(line + "\n")
