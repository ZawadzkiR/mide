"""UI themes.

This module provides QSS strings for a few curated themes and a tiny color
palette that can be used by syntax highlighters.
"""

from __future__ import annotations

DEFAULT_THEME_NAME = "Future Dark"


FUTURE_DARK_QSS = """
QWidget {
    background: #050812;
    color: #e6f1ff;
    selection-background-color: #132042;
    selection-color: #e6f1ff;
    font-family: Segoe UI, Inter, Arial;
    font-size: 10pt;
}
QMenuBar {
    background: #070b14;
    color: #e6f1ff;
    border-bottom: 1px solid #1b2a4a;
    padding: 4px;
}
QMenuBar::item {
    background: transparent;
    padding: 6px 10px;
    border-radius: 8px;
}
QMenuBar::item:selected {
    background: #132042;
    border: 1px solid #2b5cff;
}
QMenu {
    background: #070b14;
    color: #e6f1ff;
    border: 1px solid #1b2a4a;
    border-radius: 10px;
    padding: 6px;
}
QMenu::item {
    padding: 8px 18px;
    border-radius: 8px;
}
QMenu::item:selected {
    background: #132042;
    border: 1px solid #2b5cff;
}
QMenu::separator {
    height: 1px;
    background: #1b2a4a;
    margin: 6px 6px;
}
QToolBar {
    background: #070b14;
    border-bottom: 1px solid #1b2a4a;
    spacing: 6px;
    padding: 4px;
}
QToolButton {
    background: #070b14;
    color: #e6f1ff;
    border: 1px solid #1b2a4a;
    border-radius: 10px;
    padding: 6px 10px;
}
QToolButton:hover {
    background: #0b1224;
    border: 1px solid #2b5cff;
}
QDockWidget::title {
    background: #070b14;
    color: #b7c7dd;
    padding: 6px;
    border: 1px solid #1b2a4a;
    border-radius: 8px;
    margin: 4px;
}
QTabWidget::pane {
    border: 1px solid #1b2a4a;
    border-radius: 10px;
}
QTabBar::tab {
    background: #070b14;
    color: #b7c7dd;
    padding: 8px 12px;
    border: 1px solid #1b2a4a;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    margin-right: 4px;
}
QTabBar::tab:selected {
    color: #e6f1ff;
    background: #0b1224;
    border: 1px solid #2b5cff;
}
QLineEdit, QTextEdit, QPlainTextEdit {
    background: #070b14;
    color: #e6f1ff;
    border: 1px solid #1b2a4a;
    border-radius: 10px;
    padding: 8px;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border: 1px solid #2b5cff;
}
QPushButton {
    background: #070b14;
    color: #e6f1ff;
    border: 1px solid #1b2a4a;
    border-radius: 10px;
    padding: 8px 12px;
}
QPushButton:hover {
    background: #0b1224;
    border: 1px solid #2b5cff;
}
QStatusBar {
    background: #070b14;
    border-top: 1px solid #1b2a4a;
    color: #b7c7dd;
}
"""


NORD_DARK_QSS = """
QWidget {
    background: #2E3440;
    color: #ECEFF4;
    selection-background-color: #4C566A;
    selection-color: #ECEFF4;
    font-family: Segoe UI, Inter, Arial;
    font-size: 10pt;
}
QMenuBar, QToolBar, QMenu {
    background: #3B4252;
    color: #ECEFF4;
    border-bottom: 1px solid #4C566A;
}
QMenu { border: 1px solid #4C566A; border-radius: 10px; padding: 6px; }
QToolButton, QPushButton {
    background: #3B4252;
    color: #ECEFF4;
    border: 1px solid #4C566A;
    border-radius: 10px;
    padding: 6px 10px;
}
QToolButton:hover, QPushButton:hover { border: 1px solid #88C0D0; }
QDockWidget::title {
    background: #3B4252;
    color: #D8DEE9;
    padding: 6px;
    border: 1px solid #4C566A;
    border-radius: 8px;
    margin: 4px;
}
QLineEdit, QTextEdit, QPlainTextEdit {
    background: #3B4252;
    color: #ECEFF4;
    border: 1px solid #4C566A;
    border-radius: 10px;
    padding: 8px;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus { border: 1px solid #88C0D0; }
QStatusBar { background: #3B4252; border-top: 1px solid #4C566A; color: #D8DEE9; }
"""


LIGHT_MINIMAL_QSS = """
QWidget {
    background: #FAFAFA;
    color: #111827;
    selection-background-color: #BFDBFE;
    selection-color: #111827;
    font-family: Segoe UI, Inter, Arial;
    font-size: 10pt;
}
QMenuBar, QToolBar, QMenu {
    background: #FFFFFF;
    color: #111827;
    border-bottom: 1px solid #E5E7EB;
}
QMenu { border: 1px solid #E5E7EB; border-radius: 10px; padding: 6px; }
QToolButton, QPushButton {
    background: #FFFFFF;
    color: #111827;
    border: 1px solid #E5E7EB;
    border-radius: 10px;
    padding: 6px 10px;
}
QToolButton:hover, QPushButton:hover { border: 1px solid #3B82F6; }
QDockWidget::title {
    background: #FFFFFF;
    color: #374151;
    padding: 6px;
    border: 1px solid #E5E7EB;
    border-radius: 8px;
    margin: 4px;
}
QLineEdit, QTextEdit, QPlainTextEdit {
    background: #FFFFFF;
    color: #111827;
    border: 1px solid #E5E7EB;
    border-radius: 10px;
    padding: 8px;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus { border: 1px solid #3B82F6; }
QStatusBar { background: #FFFFFF; border-top: 1px solid #E5E7EB; color: #374151; }
"""


THEMES = {
    "Future Dark": FUTURE_DARK_QSS,
    "Nord Dark": NORD_DARK_QSS,
    "Light Minimal": LIGHT_MINIMAL_QSS,
}


SYNTAX_PALETTES = {
    "Future Dark": {
        "keyword": "#7aa2ff",
        "string": "#a6e3a1",
        "comment": "#6b7a99",
        "number": "#f2d97d",
        "name": "#e6f1ff",
        "operator": "#cba6f7",
        "error": "#ff6b6b",
    },
    "Nord Dark": {
        "keyword": "#81A1C1",
        "string": "#A3BE8C",
        "comment": "#616E88",
        "number": "#EBCB8B",
        "name": "#ECEFF4",
        "operator": "#B48EAD",
        "error": "#BF616A",
    },
    "Light Minimal": {
        "keyword": "#1D4ED8",
        "string": "#047857",
        "comment": "#6B7280",
        "number": "#B45309",
        "name": "#111827",
        "operator": "#7C3AED",
        "error": "#B91C1C",
    },
}


def get_theme_qss(name: str | None) -> str:
    name = name or DEFAULT_THEME_NAME
    return THEMES.get(name, THEMES[DEFAULT_THEME_NAME])


def get_syntax_palette(name: str | None) -> dict:
    name = name or DEFAULT_THEME_NAME
    return SYNTAX_PALETTES.get(name, SYNTAX_PALETTES[DEFAULT_THEME_NAME])
